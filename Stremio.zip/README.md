# VFlixPrime Stremio - Content Management & Addon

A comprehensive web application for managing movies and series with automatic TMDB/IMDB import and a built-in Stremio addon.

## Features

### Admin Panel
- 🔐 **Secure Login System** - Authentication with session management
- 📊 **Dashboard** - Overview of all content with statistics
- 🎬 **Movies Management** - Add, edit, and delete movies
- 📺 **Series Management** - Add, edit, and delete TV series
- 🎨 **Modern UI** - Beautiful glassmorphism design with animations

### Content Management
- **Auto Import** - Fetch movie/series details from TMDB or IMDB
- **Edit Capabilities** - Modify existing content details
- **Poster & Metadata** - Automatic fetching of posters, ratings, cast, etc.
- **Separate Pages** - Dedicated pages for movies and series

### Stremio Addon
- **Catalog Support** - Browse movies and series in Stremio
- **Meta Information** - Rich metadata display
- **Stream Handler** - Ready for stream URL integration

## Installation

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn

### Setup

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Configure API Keys**
   
   Edit `server.js` and add your API keys:
   
   - **TMDB API Key**: Get from [https://www.themoviedb.org/settings/api](https://www.themoviedb.org/settings/api)
     ```javascript
     const TMDB_API_KEY = 'YOUR_TMDB_API_KEY';
     ```
   
   - **OMDB API Key** (for IMDB): Get from [http://www.omdbapi.com/apikey.aspx](http://www.omdbapi.com/apikey.aspx)
     ```javascript
     const OMDB_API_KEY = 'YOUR_OMDB_API_KEY';
     ```

3. **Start the Server**
   ```bash
   npm start
   ```

4. **Access the Application**
   - Open your browser and go to: `http://localhost:3000`
   - Default credentials:
     - Username: `admin`
     - Password: `admin123`

## Usage

### Adding Movies

1. Navigate to the **Movies** page
2. Click **"+ Add Movie"**
3. Select source (TMDB or IMDB)
4. Enter the movie ID:
   - **TMDB**: Numeric ID (e.g., `550` for Fight Club)
   - **IMDB**: Full ID (e.g., `tt0137523` for Fight Club)
5. Click **"Fetch & Add"**

The system will automatically fetch:
- Title and original title
- Overview/plot
- Poster and backdrop images
- Release date
- Rating
- Genres
- Runtime
- Cast and director
- Trailer (TMDB only)

### Adding Series

1. Navigate to the **Series** page
2. Click **"+ Add Series"**
3. Select source (TMDB or IMDB)
4. Enter the series ID:
   - **TMDB**: Numeric ID (e.g., `1399` for Game of Thrones)
   - **IMDB**: Full ID (e.g., `tt0944947` for Game of Thrones)
5. Click **"Fetch & Add"**

### Editing Content

1. Click the **"Edit"** button on any movie or series
2. Modify the fields as needed
3. Click **"Save Changes"**

### Installing Stremio Addon

1. Go to the **Dashboard** page
2. Copy the addon URL
3. Open Stremio
4. Go to Addons → Community Addons
5. Paste the URL and install

## API Endpoints

### Authentication
- `POST /api/login` - Login
- `POST /api/logout` - Logout
- `GET /api/check-auth` - Check authentication status

### Dashboard
- `GET /api/dashboard` - Get dashboard statistics

### Movies
- `GET /api/movies` - Get all movies
- `POST /api/movies` - Add new movie
- `PUT /api/movies/:id` - Update movie
- `DELETE /api/movies/:id` - Delete movie

### Series
- `GET /api/series` - Get all series
- `POST /api/series` - Add new series
- `PUT /api/series/:id` - Update series
- `DELETE /api/series/:id` - Delete series

### Stremio Addon
- `GET /stremio/manifest.json` - Addon manifest
- `GET /stremio/catalog/:type/:id.json` - Catalog
- `GET /stremio/meta/:type/:id.json` - Metadata
- `GET /stremio/stream/:type/:id.json` - Streams

## Finding TMDB/IMDB IDs

### TMDB
1. Go to [themoviedb.org](https://www.themoviedb.org/)
2. Search for your movie/series
3. The ID is in the URL: `https://www.themoviedb.org/movie/550-fight-club` → ID is `550`

### IMDB
1. Go to [imdb.com](https://www.imdb.com/)
2. Search for your movie/series
3. The ID is in the URL: `https://www.imdb.com/title/tt0137523/` → ID is `tt0137523`

## Production Deployment

For production use:

1. **Use a Database**: Replace in-memory storage with MongoDB, PostgreSQL, etc.
2. **Environment Variables**: Store API keys in `.env` file
3. **HTTPS**: Use SSL certificates
4. **Authentication**: Implement stronger password hashing and JWT tokens
5. **Stream URLs**: Configure actual streaming server URLs in `addon.js`

## Troubleshooting

### API Key Issues
- Make sure your TMDB API key is valid and has proper permissions
- OMDB free tier has limited requests (1000/day)

### CORS Issues
- If accessing from different domain, configure CORS in `server.js`

### Content Not Showing
- Check browser console for errors
- Verify API keys are correctly set
- Ensure the ID format matches the source (numeric for TMDB, tt-prefix for IMDB)

## Technology Stack

- **Backend**: Node.js, Express
- **Frontend**: Vanilla JavaScript, HTML5, CSS3
- **APIs**: TMDB API, OMDB API
- **Addon**: Stremio Addon SDK
- **Design**: Glassmorphism, CSS Animations

## License

MIT License

## Support

For issues and questions, please check the troubleshooting section or create an issue in the repository.

---

**Note**: This application is for educational purposes. Make sure you have the rights to stream any content you add to the system.
