const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
const ANALYTICS_FILE = path.join(DATA_DIR, 'analytics.json');

// Ensure analytics file exists
if (!fs.existsSync(ANALYTICS_FILE)) {
    fs.writeFileSync(ANALYTICS_FILE, JSON.stringify({
        totalViews: 0,
        uniqueUsers: [],
        views: [], // { type, id, title, timestamp, ip }
        activeNow: {} // ip: { type, id, title, lastActive }
    }, null, 2));
}

function loadAnalytics() {
    try {
        return JSON.parse(fs.readFileSync(ANALYTICS_FILE, 'utf8'));
    } catch (e) {
        return { totalViews: 0, uniqueUsers: [], views: [], activeNow: {} };
    }
}

function saveAnalytics(data) {
    try {
        fs.writeFileSync(ANALYTICS_FILE, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('Error saving analytics:', e);
    }
}

const analytics = {
    trackView: (type, id, title, req, username) => {
        const data = loadAnalytics();
        const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
        const timestamp = new Date();

        // Update total views
        data.totalViews++;

        // Update unique users
        if (!data.uniqueUsers.includes(ip)) {
            data.uniqueUsers.push(ip);
        }

        // Add to historical views
        data.views.push({
            type,
            id,
            title,
            timestamp: timestamp.toISOString(),
            ip,
            username: username || 'anonymous'
        });

        // Limit views history to last 1000Entry entries to avoid file bloat
        if (data.views.length > 10000) {
            data.views.shift();
        }

        // Update active now
        data.activeNow[ip] = {
            type,
            id,
            title,
            username: username || 'anonymous',
            lastActive: timestamp.getTime()
        };

        saveAnalytics(data);
    },

    getActiveNow: () => {
        const data = loadAnalytics();
        const now = Date.now();
        const activeLimit = 15 * 60 * 1000; // 15 minutes

        const active = [];
        for (const [ip, info] of Object.entries(data.activeNow)) {
            if (now - info.lastActive < activeLimit) {
                active.push({ ip, ...info });
            } else {
                delete data.activeNow[ip];
            }
        }

        saveAnalytics(data); // Cleanup expired sessions
        return active;
    },

    getStats: () => {
        const data = loadAnalytics();
        const now = new Date();

        const dayLimit = 24 * 60 * 60 * 1000;
        const weekLimit = 7 * dayLimit;
        const monthLimit = 30 * dayLimit;

        const stats = {
            day: 0,
            week: 0,
            month: 0,
            totalUsers: data.uniqueUsers.length,
            totalViews: data.totalViews
        };

        const userStats = {};

        data.views.forEach(view => {
            const viewTime = new Date(view.timestamp).getTime();
            const diff = now.getTime() - viewTime;

            if (diff < dayLimit) stats.day++;
            if (diff < weekLimit) stats.week++;
            if (diff < monthLimit) stats.month++;

            const user = view.username || 'anonymous';
            userStats[user] = (userStats[user] || 0) + 1;
        });

        // Convert userStats to sorted array
        stats.topUsers = Object.entries(userStats)
            .map(([username, count]) => ({ username, count }))
            .sort((a, b) => b.count - a.count)
            .slice(0, 10); // Top 10 users

        return stats;
    }
};

module.exports = analytics;
