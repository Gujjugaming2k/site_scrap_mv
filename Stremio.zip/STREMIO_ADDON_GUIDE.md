# Stremio Addon Integration Guide

## What is the VFlixPrime Stremio Addon?

The VFlixPrime Stremio Addon allows you to browse and access all the movies and series you've added to your VFlixPrime content management system directly within the Stremio application.

## Features

✅ **Automatic Catalog Sync** - All movies and series from your admin panel appear in Stremio  
✅ **Rich Metadata** - Posters, descriptions, ratings, cast, and more  
✅ **Separate Catalogs** - Movies and Series are organized separately  
✅ **Real-time Updates** - Content updates when you add/edit in the admin panel  

## Installing the Addon in Stremio

### Method 1: Direct URL (Recommended)

1. **Get Your Addon URL**
   - Login to VFlixPrime admin panel
   - Go to Dashboard
   - Copy the addon URL (should be: `http://localhost:3000/stremio/manifest.json`)

2. **Install in Stremio**
   - Open Stremio application
   - Click on the **puzzle piece icon** (Addons) in the top right
   - Click **Community Addons** at the top
   - Paste your addon URL in the search box
   - Click **Install**

3. **Verify Installation**
   - Go to **Discover** or **Board**
   - You should see "VFlixPrime Movies" and "VFlixPrime Series" catalogs
   - Browse your content!

### Method 2: Manual Installation

If you're running VFlixPrime on a server (not localhost):

1. Replace `localhost:3000` with your server's IP or domain
2. Example: `http://192.168.1.100:3000/stremio/manifest.json`
3. Or: `https://your-domain.com/stremio/manifest.json`

## Using the Addon

### Browsing Content

1. **Movies Catalog**
   - Open Stremio
   - Go to **Discover** → **Movies**
   - Scroll to find "VFlixPrime Movies" section
   - Browse all movies you've added

2. **Series Catalog**
   - Go to **Discover** → **Series**
   - Find "VFlixPrime Series" section
   - Browse all series you've added

### Viewing Details

Click on any movie or series to see:
- Full description
- Release date
- Rating
- Cast and crew
- Genres
- Trailer (if available from TMDB)

### Streaming (Advanced)

⚠️ **Note**: The current implementation is a **catalog addon** only. To enable actual streaming:

1. **Set Up a Streaming Server**
   - You need a media server (e.g., Plex, Jellyfin, or custom solution)
   - Or use a CDN to host your video files

2. **Update Stream URLs**
   - Edit `addon.js`
   - Find the `defineStreamHandler` function (around line 100)
   - Replace the placeholder URL with your actual stream URLs:

   ```javascript
   builder.defineStreamHandler(({ type, id }) => {
       const vflixId = id.replace('vflix:', '');
       
       // Example: Link to your streaming server
       return Promise.resolve({
           streams: [
               {
                   title: 'VFlixPrime HD',
                   url: `https://your-server.com/stream/${vflixId}/master.m3u8`,
                   behaviorHints: {
                       notWebReady: false
                   }
               },
               {
                   title: 'VFlixPrime SD',
                   url: `https://your-server.com/stream/${vflixId}/sd.mp4`,
                   behaviorHints: {
                       notWebReady: false
                   }
               }
           ]
       });
   });
   ```

3. **Restart the Server**
   ```bash
   npm start
   ```

## Addon Manifest

The addon manifest defines what your addon can do. Current configuration:

```json
{
    "id": "com.vflixprime.addon",
    "version": "1.0.0",
    "name": "VFlixPrime",
    "description": "Stream movies and series from VFlixPrime",
    "resources": ["catalog", "meta", "stream"],
    "types": ["movie", "series"],
    "catalogs": [
        {
            "type": "movie",
            "id": "vflixprime-movies",
            "name": "VFlixPrime Movies"
        },
        {
            "type": "series",
            "id": "vflixprime-series",
            "name": "VFlixPrime Series"
        }
    ]
}
```

## Troubleshooting

### Addon Not Appearing in Stremio

1. **Check Server is Running**
   ```bash
   # Should show: VFlixPrime server running on http://localhost:3000
   ```

2. **Verify Addon URL**
   - Open in browser: `http://localhost:3000/stremio/manifest.json`
   - Should show JSON manifest

3. **Check Firewall**
   - Ensure port 3000 is not blocked
   - If using remote server, check firewall rules

### Content Not Showing

1. **Add Content First**
   - Make sure you've added movies/series in the admin panel
   - Addon only shows content you've added

2. **Refresh Stremio**
   - Close and reopen Stremio
   - Or reinstall the addon

### "No Streams Available"

This is expected! The current version is a **catalog addon**. To enable streaming:
- Follow the "Streaming (Advanced)" section above
- Set up actual video hosting
- Update stream URLs in `addon.js`

## Remote Access

To access your addon from other devices:

1. **Find Your Local IP**
   ```bash
   # Windows
   ipconfig
   # Look for IPv4 Address (e.g., 192.168.1.100)
   ```

2. **Update Addon URL**
   - Use: `http://192.168.1.100:3000/stremio/manifest.json`
   - Install this URL in Stremio on other devices

3. **For Internet Access**
   - Set up port forwarding on your router (port 3000)
   - Or use a service like ngrok:
     ```bash
     npx ngrok http 3000
     ```
   - Use the ngrok URL for your addon

## Advanced: HTTPS Setup

For production deployment with HTTPS:

1. **Get SSL Certificate**
   - Use Let's Encrypt (free)
   - Or use a reverse proxy (nginx, Apache)

2. **Update Server**
   ```javascript
   const https = require('https');
   const fs = require('fs');
   
   const options = {
       key: fs.readFileSync('path/to/private.key'),
       cert: fs.readFileSync('path/to/certificate.crt')
   };
   
   https.createServer(options, app).listen(443);
   ```

3. **Use HTTPS URL**
   - `https://your-domain.com/stremio/manifest.json`

## Testing Your Addon

Test the addon endpoints directly:

```bash
# Manifest
curl http://localhost:3000/stremio/manifest.json

# Movies Catalog
curl http://localhost:3000/stremio/catalog/movie/vflixprime-movies.json

# Series Catalog
curl http://localhost:3000/stremio/catalog/series/vflixprime-series.json

# Movie Meta (replace ID with actual movie ID)
curl http://localhost:3000/stremio/meta/movie/vflix:123456.json
```

## Resources

- [Stremio Addon SDK Documentation](https://github.com/Stremio/stremio-addon-sdk)
- [Stremio Addon Examples](https://github.com/Stremio/stremio-addon-sdk/tree/master/docs)
- [VFlixPrime GitHub](https://github.com/your-repo) (if applicable)

## Support

If you encounter issues:
1. Check the server console for errors
2. Verify your content is added in the admin panel
3. Test the addon endpoints with curl
4. Check Stremio's addon logs

---

**Happy Streaming! 🎬📺**
