const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const bcrypt = require('bcryptjs');
const axios = require('axios');
const https = require('https');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Configure axios to handle SSL certificates (for corporate environments)
const httpsAgent = new https.Agent({
    rejectUnauthorized: false // Bypass SSL certificate verification
});

// Create axios instance with SSL configuration
const axiosInstance = axios.create({
    httpsAgent: httpsAgent
});

// Middleware
// CORS - Allow Stremio to access the addon
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    if (req.method === 'OPTIONS') {
        return res.sendStatus(200);
    }
    next();
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(session({
    secret: 'vflixprime-secret-key-2024',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 24 * 60 * 60 * 1000 } // 24 hours
}));

// User storage (in-memory for simplicity)
const users = [
    {
        id: 1,
        username: 'admin',
        password: bcrypt.hashSync('admin123', 10) // Default password: admin123
    }
];

// ============================================
// PERSISTENT FILE-BASED STORAGE
// ============================================

const DATA_DIR = path.join(__dirname, 'data');
const MOVIES_FILE = path.join(DATA_DIR, 'movies.json');
const SERIES_FILE = path.join(DATA_DIR, 'series.json');
const CATALOGS_FILE = path.join(DATA_DIR, 'catalogs.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Helper function to load data from file
function loadData(filePath) {
    try {
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(data);
        }
        return [];
    } catch (error) {
        console.error(`Error loading data from ${filePath}:`, error.message);
        return [];
    }
}

// Helper function to save data to file
function saveData(filePath, data) {
    try {
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error(`Error saving data to ${filePath}:`, error.message);
        return false;
    }
}

// Load existing data on server start
let movies = loadData(MOVIES_FILE);
let series = loadData(SERIES_FILE);
let catalogs = loadData(CATALOGS_FILE);

// Initialize default catalogs if none exist
if (catalogs.length === 0) {
    catalogs = [
        { id: 'vflixprime-movies', name: 'VFlixPrime Movies', type: 'movie' },
        { id: 'vflixprime-series', name: 'VFlixPrime Series', type: 'series' }
    ];
    saveData(CATALOGS_FILE, catalogs);
}

console.log(`📚 Loaded ${movies.length} movies, ${series.length} series, and ${catalogs.length} catalogs from storage`);

// ============================================
// TMDB API KEY ROTATION
// ============================================

// Multiple TMDB API keys for load distribution
const TMDB_API_KEYS = [
    'e3c47f86a8cecb8721f9cc45a1e1ba8f', // Key 1
    'ea7b1fc3807d8a53d4227a80a15aeed1', // Key 2 - Replace with your second key
    'abf4d0f9cf2c7ad4990823215af63543',
    '83aa53347a84d73e55c6ada9e5d537fe'  // Key 3 - Replace with your third key
];

let currentKeyIndex = 0;

// Get next API key in rotation
function getNextApiKey() {
    const key = TMDB_API_KEYS[currentKeyIndex];
    currentKeyIndex = (currentKeyIndex + 1) % TMDB_API_KEYS.length;
    return key;
}

// ============================================
// TMDB FETCH FUNCTIONS
// ============================================

// TMDB Fetch Function middleware
const isAuthenticated = (req, res, next) => {
    if (req.session.userId) {
        next();
    } else {
        res.status(401).json({ error: 'Unauthorized' });
    }
};

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Auth API
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username);

    if (user && bcrypt.compareSync(password, user.password)) {
        req.session.userId = user.id;
        res.json({ success: true, message: 'Login successful' });
    } else {
        res.status(401).json({ error: 'Invalid credentials' });
    }
});

app.post('/api/logout', (req, res) => {
    req.session.destroy();
    res.json({ success: true });
});

app.get('/api/check-auth', (req, res) => {
    res.json({ authenticated: !!req.session.userId });
});

// Dashboard API
app.get('/api/dashboard', isAuthenticated, (req, res) => {
    res.json({
        totalMovies: movies.length,
        totalSeries: series.length,
        recentMovies: movies.slice(-10).reverse(),
        recentSeries: series.slice(-10).reverse()
    });
});

// Movies API
// Movies API
app.get('/api/movies', isAuthenticated, (req, res) => {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;

    // Use reverse to show newest first, but we need to slice correctly
    // Let's behave like a normal database:
    // If user wants newest first, we should probably reverse the whole array then slice, 
    // OR just return the slice of the array as is (which is insertion order usually).
    // The previous implementation returned all movies, and the frontend didn't sort them explicitly?
    // Let's assume the array order is insertion order (oldest first). 
    // If we want newest first on page 1, we should reverse.
    // However, for simplicity and consistency with standard APIs, let's keep array order (oldest -> newest)
    // UNLESS the user explicitly requested sorting. 
    // ACTUALLY, usually people want to see what they just added.
    // Let's reverse for the response so page 1 has the newest items.

    const reversedMovies = [...movies].reverse();
    const results = reversedMovies.slice(startIndex, endIndex);

    res.json({
        movies: results,
        total: movies.length,
        page: page,
        totalPages: Math.ceil(movies.length / limit)
    });
});

app.post('/api/movies', isAuthenticated, async (req, res) => {
    try {
        const { id, source, catalogId } = req.body; // id is TMDB or IMDB id, source is 'tmdb' or 'imdb'

        // Check for duplicates
        const existingMovie = movies.find(m => m.externalId === id && m.source === source);
        if (existingMovie) {
            return res.status(409).json({
                error: 'Movie already exists',
                message: `"${existingMovie.title}" is already in your library`,
                movie: existingMovie
            });
        }

        let movieData;
        if (source === 'tmdb') {
            movieData = await fetchFromTMDB('movie', id);
        } else if (source === 'imdb') {
            movieData = await fetchFromIMDB(id);
        }

        const movie = {
            id: Date.now().toString(),
            externalId: id,
            source: source,
            catalogId: catalogId || 'vflixprime-movies', // Use provided or default catalog
            ...movieData,
            addedAt: new Date().toISOString()
        };

        movies.push(movie);
        saveData(MOVIES_FILE, movies); // Save to file
        res.json({ success: true, movie });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.put('/api/movies/:id', isAuthenticated, (req, res) => {
    const { id } = req.params;
    const index = movies.findIndex(m => m.id === id);

    if (index !== -1) {
        movies[index] = { ...movies[index], ...req.body, updatedAt: new Date().toISOString() };
        saveData(MOVIES_FILE, movies); // Save to file
        res.json({ success: true, movie: movies[index] });
    } else {
        res.status(404).json({ error: 'Movie not found' });
    }
});

app.delete('/api/movies/:id', isAuthenticated, (req, res) => {
    const { id } = req.params;
    movies = movies.filter(m => m.id !== id);
    saveData(MOVIES_FILE, movies); // Save to file
    res.json({ success: true });
});

// Series API
// Series API
app.get('/api/series', isAuthenticated, (req, res) => {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;

    const reversedSeries = [...series].reverse();
    const results = reversedSeries.slice(startIndex, endIndex);

    res.json({
        series: results,
        total: series.length,
        page: page,
        totalPages: Math.ceil(series.length / limit)
    });
});

app.post('/api/series', isAuthenticated, async (req, res) => {
    try {
        const { id, source, catalogId } = req.body;

        // Check for duplicates
        const existingSeries = series.find(s => s.externalId === id && s.source === source);
        if (existingSeries) {
            return res.status(409).json({
                error: 'Series already exists',
                message: `"${existingSeries.title}" is already in your library`,
                series: existingSeries
            });
        }

        let seriesData;
        if (source === 'tmdb') {
            seriesData = await fetchFromTMDB('tv', id);
        } else if (source === 'imdb') {
            seriesData = await fetchFromIMDB(id);
        }

        const serie = {
            id: Date.now().toString(),
            externalId: id,
            source: source,
            catalogId: catalogId || 'vflixprime-series', // Use provided or default catalog
            ...seriesData,
            addedAt: new Date().toISOString()
        };

        series.push(serie);
        saveData(SERIES_FILE, series); // Save to file
        res.json({ success: true, series: serie });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.put('/api/series/:id', isAuthenticated, (req, res) => {
    const { id } = req.params;
    const index = series.findIndex(s => s.id === id);

    if (index !== -1) {
        series[index] = { ...series[index], ...req.body, updatedAt: new Date().toISOString() };
        saveData(SERIES_FILE, series); // Save to file
        res.json({ success: true, series: series[index] });
    } else {
        res.status(404).json({ error: 'Series not found' });
    }
});

app.delete('/api/series/:id', isAuthenticated, (req, res) => {
    const { id } = req.params;
    series = series.filter(s => s.id !== id);
    saveData(SERIES_FILE, series); // Save to file
    res.json({ success: true });
});

// Bulk Import API
app.post('/api/import', isAuthenticated, async (req, res) => {
    try {
        const { id, source, catalogId } = req.body;
        // Currently only supporting IMDB for bulk import as per request
        if (source !== 'imdb') {
            return res.status(400).json({ error: 'Only IMDB source supported for bulk import' });
        }

        // Check if already exists in either database
        const existingMovie = movies.find(m => m.externalId === id || m.imdbId === id);
        if (existingMovie) {
            return res.json({
                success: true,
                action: 'skipped',
                message: 'Already exists in movies',
                title: existingMovie.title,
                type: 'movie'
            });
        }

        const existingSeries = series.find(s => s.externalId === id || s.imdbId === id);
        if (existingSeries) {
            return res.json({
                success: true,
                action: 'skipped',
                message: 'Already exists in series',
                title: existingSeries.title,
                type: 'series'
            });
        }

        // Fetch data
        const data = await fetchFromIMDB(id);

        if (data.type === 'movie') {
            const movie = {
                id: Date.now().toString(),
                externalId: data.tmdbId,
                imdbId: id,
                source: 'tmdb',
                catalogId: catalogId || 'vflixprime-movies', // Use provided or default catalog
                ...data,
                addedAt: new Date().toISOString()
            };
            movies.push(movie);
            saveData(MOVIES_FILE, movies);
            return res.json({ success: true, action: 'added', title: movie.title, type: 'movie' });
        } else if (data.type === 'tv' || data.type === 'series') {
            const serie = {
                id: Date.now().toString(),
                externalId: data.tmdbId,
                imdbId: id,
                source: 'tmdb',
                catalogId: catalogId || 'vflixprime-series', // Use provided or default catalog
                ...data,
                addedAt: new Date().toISOString()
            };
            series.push(serie);
            saveData(SERIES_FILE, series);
            return res.json({ success: true, action: 'added', title: serie.title, type: 'series' });
        } else {
            return res.status(400).json({ error: 'Unknown content type' });
        }

    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
});

// TMDB Fetch Function
async function fetchFromTMDB(type, id) {
    const TMDB_API_KEY = getNextApiKey(); // Use rotating API key
    const url = `https://api.themoviedb.org/3/${type}/${id}?api_key=${TMDB_API_KEY}&append_to_response=credits,videos`;

    try {
        const response = await axiosInstance.get(url);
        const data = response.data;

        // Base metadata
        const metadata = {
            type: type === 'tv' ? 'series' : 'movie', // Normalize type
            tmdbId: data.id, // Store explicit TMDB ID
            title: data.title || data.name,
            originalTitle: data.original_title || data.original_name,
            overview: data.overview,
            poster: data.poster_path ? `https://image.tmdb.org/t/p/w500${data.poster_path}` : null,
            backdrop: data.backdrop_path ? `https://image.tmdb.org/t/p/original${data.backdrop_path}` : null,
            releaseDate: data.release_date || data.first_air_date,
            rating: data.vote_average,
            genres: data.genres.map(g => g.name),
            runtime: data.runtime || data.episode_run_time?.[0],
            cast: data.credits?.cast?.slice(0, 10).map(c => c.name) || [],
            director: data.credits?.crew?.find(c => c.job === 'Director')?.name || '',
            trailer: data.videos?.results?.find(v => v.type === 'Trailer')?.key || '',
            seasons: data.seasons?.length || 0,
            episodes: data.number_of_episodes || 0,
            imdbId: null // Will be fetched separately
        };

        // Fetch IMDB ID from external_ids
        try {
            const externalIdsUrl = `https://api.themoviedb.org/3/${type}/${id}/external_ids?api_key=${TMDB_API_KEY}`;
            const externalIdsResponse = await axiosInstance.get(externalIdsUrl);
            metadata.imdbId = externalIdsResponse.data.imdb_id || null;
        } catch (error) {
            console.log(`Could not fetch IMDB ID: ${error.message}`);
        }

        // For TV series, fetch detailed season and episode information
        if (type === 'tv' && data.seasons && data.seasons.length > 0) {
            const seasonsData = [];

            // Fetch details for each season (limit to first 10 seasons to avoid too many requests)
            const seasonsToFetch = data.seasons.filter(s => s.season_number > 0).slice(0, 10);

            for (const season of seasonsToFetch) {
                try {
                    const seasonUrl = `https://api.themoviedb.org/3/tv/${id}/season/${season.season_number}?api_key=${TMDB_API_KEY}`;
                    const seasonResponse = await axiosInstance.get(seasonUrl);
                    const seasonData = seasonResponse.data;

                    seasonsData.push({
                        number: season.season_number,
                        name: seasonData.name,
                        overview: seasonData.overview,
                        episodeCount: seasonData.episodes.length,
                        airDate: seasonData.air_date,
                        episodes: seasonData.episodes.map(ep => ({
                            number: ep.episode_number,
                            name: ep.name,
                            overview: ep.overview,
                            airDate: ep.air_date,
                            runtime: ep.runtime,
                            stillPath: ep.still_path ? `https://image.tmdb.org/t/p/w300${ep.still_path}` : null
                        }))
                    });
                } catch (seasonError) {
                    console.error(`Error fetching season ${season.season_number}:`, seasonError.message);
                    // Continue with other seasons even if one fails
                }
            }

            metadata.seasonsData = seasonsData;
        }

        return metadata;
    } catch (error) {
        throw new Error('Failed to fetch from TMDB: ' + error.message);
    }
}

// IMDB Fetch Function (using TMDB's Find by External ID)
async function fetchFromIMDB(imdbId) {
    const TMDB_API_KEY = getNextApiKey(); // Use rotating API key

    // First, find the TMDB ID using the IMDB ID
    const findUrl = `https://api.themoviedb.org/3/find/${imdbId}?api_key=${TMDB_API_KEY}&external_source=imdb_id`;

    try {
        const findResponse = await axiosInstance.get(findUrl);
        const findData = findResponse.data;

        // Check if we found a movie or TV show
        let tmdbId, type;
        if (findData.movie_results && findData.movie_results.length > 0) {
            tmdbId = findData.movie_results[0].id;
            type = 'movie';
        } else if (findData.tv_results && findData.tv_results.length > 0) {
            tmdbId = findData.tv_results[0].id;
            type = 'tv';
        } else {
            throw new Error('No results found for this IMDB ID');
        }

        // Now fetch the full details from TMDB
        return await fetchFromTMDB(type, tmdbId);

    } catch (error) {
        throw new Error('Failed to fetch from IMDB: ' + error.message);
    }
}

// ============================================
// CATALOG MANAGEMENT API
// ============================================

// Get all catalogs
app.get('/api/catalogs', isAuthenticated, (req, res) => {
    res.json(catalogs);
});

// Create catalog
app.post('/api/catalogs', isAuthenticated, (req, res) => {
    try {
        const { name, type } = req.body;

        if (!name || !type) {
            return res.status(400).json({ error: 'Name and type are required' });
        }

        if (type !== 'movie' && type !== 'series') {
            return res.status(400).json({ error: 'Type must be movie or series' });
        }

        // Generate ID from name
        const id = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');

        // Check for duplicates
        if (catalogs.find(c => c.id === id)) {
            return res.status(409).json({ error: 'Catalog with this name already exists' });
        }

        const catalog = {
            id,
            name,
            type,
            createdAt: new Date().toISOString()
        };

        catalogs.push(catalog);
        saveData(CATALOGS_FILE, catalogs);

        res.json({ success: true, catalog });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update catalog
app.put('/api/catalogs/:id', isAuthenticated, (req, res) => {
    try {
        const { id } = req.params;
        const { name } = req.body;

        const index = catalogs.findIndex(c => c.id === id);
        if (index === -1) {
            return res.status(404).json({ error: 'Catalog not found' });
        }

        // Don't allow renaming default catalogs
        if (id === 'vflixprime-movies' || id === 'vflixprime-series') {
            return res.status(403).json({ error: 'Cannot rename default catalogs' });
        }

        catalogs[index].name = name;
        catalogs[index].updatedAt = new Date().toISOString();
        saveData(CATALOGS_FILE, catalogs);

        res.json({ success: true, catalog: catalogs[index] });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Delete catalog
app.delete('/api/catalogs/:id', isAuthenticated, (req, res) => {
    try {
        const { id } = req.params;

        // Don't allow deleting default catalogs
        if (id === 'vflixprime-movies' || id === 'vflixprime-series') {
            return res.status(403).json({ error: 'Cannot delete default catalogs' });
        }

        const catalog = catalogs.find(c => c.id === id);
        if (!catalog) {
            return res.status(404).json({ error: 'Catalog not found' });
        }

        // Move content to default catalog
        const defaultCatalogId = catalog.type === 'movie' ? 'vflixprime-movies' : 'vflixprime-series';

        if (catalog.type === 'movie') {
            movies.forEach(m => {
                if (m.catalogId === id) {
                    m.catalogId = defaultCatalogId;
                }
            });
            saveData(MOVIES_FILE, movies);
        } else {
            series.forEach(s => {
                if (s.catalogId === id) {
                    s.catalogId = defaultCatalogId;
                }
            });
            saveData(SERIES_FILE, series);
        }

        catalogs = catalogs.filter(c => c.id !== id);
        saveData(CATALOGS_FILE, catalogs);

        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Stremio Addon will be in separate file
app.use('/stremio', require('./addon'));

app.listen(PORT, () => {
    console.log(`VFlixPrime server running on http://localhost:${PORT}`);
});
