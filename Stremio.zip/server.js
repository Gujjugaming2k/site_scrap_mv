const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const bcrypt = require('bcryptjs');
const axios = require('axios');
const https = require('https');
const analytics = require('./analytics');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Configure axios to handle SSL certificates (for corporate environments)
const httpsAgent = new https.Agent({
    rejectUnauthorized: false // Bypass SSL certificate verification
});

// Create axios instance with SSL configuration
const axiosInstance = axios.create({
    httpsAgent: httpsAgent
});

// Middleware
// CORS - Allow Stremio to access the addon
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    if (req.method === 'OPTIONS') {
        return res.sendStatus(200);
    }
    next();
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(session({
    secret: 'vflixprime-secret-key-2024',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 24 * 60 * 60 * 1000 } // 24 hours
}));

app.set('trust proxy', true);

// ============================================
// PERSISTENT FILE-BASED STORAGE
// ============================================

const DATA_DIR = path.join(__dirname, 'data');
const MOVIES_FILE = path.join(DATA_DIR, 'movies.json');
const SERIES_FILE = path.join(DATA_DIR, 'series.json');
const CATALOGS_FILE = path.join(DATA_DIR, 'catalogs.json');
const PROVIDERS_FILE = path.join(DATA_DIR, 'providers.json');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json'); // Global Settings

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Helper function to load data from file
function loadData(filePath, defaultValue = []) {
    try {
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf8');
            console.log(`Debug: Reading ${path.basename(filePath)}, Content: ${data.substring(0, 50)}...`);
            const parsed = JSON.parse(data);

            // Fix for settings corruption: if expecting object but got empty array, use default
            if (!Array.isArray(defaultValue) && Array.isArray(parsed) && parsed.length === 0) {
                console.log(`Debug: Detected empty array for object file ${path.basename(filePath)}, using default.`);
                return defaultValue;
            }
            return parsed;
        }
        console.log(`Debug: File not found ${filePath}, using default.`);
        return defaultValue;
    } catch (error) {
        console.error(`Error loading data from ${filePath}:`, error.message);
        console.log(`Debug: Default value used due to error:`, JSON.stringify(defaultValue));
        return defaultValue;
    }
}

// Helper function to save data to file
function saveData(filePath, data) {
    try {
        console.log(`Debug: Saving to ${filePath}...`);
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
        console.log(`Debug: Successfully saved to ${path.basename(filePath)}`);
        return true;
    } catch (error) {
        console.error(`Error saving data to ${filePath}:`, error.message);
        return false;
    }
}

// Load existing data on server start
let movies = loadData(MOVIES_FILE);
let series = loadData(SERIES_FILE);
let catalogs = loadData(CATALOGS_FILE);
let providers = loadData(PROVIDERS_FILE);
let users = loadData(USERS_FILE);

// Initialize default catalogs if none exist
if (catalogs.length === 0) {
    catalogs = [
        { id: 'vflixprime-movies', name: 'VFlixPrime Movies', type: 'movie' },
        { id: 'vflixprime-series', name: 'VFlixPrime Series', type: 'series' }
    ];
    saveData(CATALOGS_FILE, catalogs);
}

// Initialize default admin user if none exist
if (users.length === 0) {
    users = [
        {
            id: '1',
            username: 'admin',
            password: bcrypt.hashSync('admin123', 10),
            role: 'admin',
            catalogAccess: [],
            createdAt: new Date().toISOString(),
            createdBy: 'system'
        }
    ];
    saveData(USERS_FILE, users);
}

if (!Array.isArray(providers)) {
    providers = [];
    saveData(PROVIDERS_FILE, providers);
}

// Load Settings
// Load Settings
let settings = loadData(SETTINGS_FILE, {
    masterTimeout: 8000,
    cacheDuration: 3600
});

// Guard against settings being an array (from old loadData behavior)
if (Array.isArray(settings)) {
    settings = {
        masterTimeout: 8000,
        cacheDuration: 3600
    };
}
// saveData(SETTINGS_FILE, settings); // Disabled to prevent overwriting on startup

console.log(`📚 Loaded ${movies.length} movies, ${series.length} series, ${catalogs.length} catalogs, ${providers.length} providers, and ${users.length} users from storage`);

// ============================================
// TMDB API KEY ROTATION
// ============================================

// Multiple TMDB API keys for load distribution
const TMDB_API_KEYS = [
    'e3c47f86a8cecb8721f9cc45a1e1ba8f', // Key 1
    'ea7b1fc3807d8a53d4227a80a15aeed1', // Key 2 - Replace with your second key
    'abf4d0f9cf2c7ad4990823215af63543',
    '83aa53347a84d73e55c6ada9e5d537fe'  // Key 3 - Replace with your third key
];

let currentKeyIndex = 0;

// Get next API key in rotation
function getNextApiKey() {
    const key = TMDB_API_KEYS[currentKeyIndex];
    currentKeyIndex = (currentKeyIndex + 1) % TMDB_API_KEYS.length;
    return key;
}

// ============================================
// TMDB FETCH FUNCTIONS
// ============================================

// TMDB Fetch Function middleware
const isAuthenticated = (req, res, next) => {
    if (req.session.userId) {
        next();
    } else {
        res.status(401).json({ error: 'Unauthorized' });
    }
};

// Admin only middleware
const isAdmin = (req, res, next) => {
    if (req.session.userId && req.session.role === 'admin') {
        next();
    } else {
        res.status(403).json({ error: 'Forbidden: Admin access required' });
    }
};

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Auth API
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username);

    if (user && bcrypt.compareSync(password, user.password)) {
        req.session.userId = user.id;
        req.session.username = user.username;
        req.session.role = user.role;
        req.session.catalogAccess = user.catalogAccess || [];
        res.json({
            success: true,
            message: 'Login successful',
            user: {
                id: user.id,
                username: user.username,
                role: user.role,
                catalogAccess: user.catalogAccess
            }
        });
    } else {
        res.status(401).json({ error: 'Invalid credentials' });
    }
});

app.post('/api/logout', (req, res) => {
    req.session.destroy();
    res.json({ success: true });
});

app.get('/api/check-auth', (req, res) => {
    if (req.session.userId) {
        const user = users.find(u => u.id === req.session.userId);
        res.json({
            authenticated: true,
            user: {
                id: user.id,
                username: user.username,
                role: user.role,
                catalogAccess: user.catalogAccess || []
            }
        });
    } else {
        res.json({ authenticated: false });
    }
});

// Stremio Configure Redirect
app.get('/configure', (req, res) => {
    res.redirect('/');
});

app.get('/stremio/configure', (req, res) => {
    res.redirect('/');
});

// App Dashboard API
app.get('/api/dashboard', isAuthenticated, (req, res) => {
    let DashboardMovies = movies;
    let DashboardSeries = series;

    // Filter by catalog access for uploaders
    if (req.session.role === 'uploader') {
        DashboardMovies = movies.filter(m =>
            req.session.catalogAccess.includes(m.catalogId || 'vflixprime-movies')
        );
        DashboardSeries = series.filter(s =>
            req.session.catalogAccess.includes(s.catalogId || 'vflixprime-series')
        );
    }

    res.json({
        totalMovies: DashboardMovies.length,
        totalSeries: DashboardSeries.length,
        recentMovies: [...DashboardMovies].reverse().slice(0, 5),
        recentSeries: [...DashboardSeries].reverse().slice(0, 5)
    });
});



// Movies API
app.get('/api/movies', isAuthenticated, (req, res) => {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;

    // Filter by catalog access for uploaders
    let filteredMovies = movies;
    if (req.session.role === 'uploader') {
        filteredMovies = movies.filter(m =>
            req.session.catalogAccess.includes(m.catalogId || 'vflixprime-movies')
        );
    }

    const reversedMovies = [...filteredMovies].reverse();
    const results = reversedMovies.slice(startIndex, endIndex);

    res.json({
        movies: results,
        total: filteredMovies.length,
        page: page,
        totalPages: Math.ceil(filteredMovies.length / limit)
    });
});

app.post('/api/movies', isAuthenticated, async (req, res) => {
    try {
        const { id, source, catalogId } = req.body; // id is TMDB or IMDB id, source is 'tmdb' or 'imdb'

        // Check catalog access for uploaders
        if (req.session.role === 'uploader') {
            const requestedCatalog = catalogId || 'vflixprime-movies';
            if (!req.session.catalogAccess.includes(requestedCatalog)) {
                return res.status(403).json({ error: 'You do not have access to this catalog' });
            }
        }

        // Check for duplicates
        const existingMovie = movies.find(m => m.externalId === id && m.source === source);
        if (existingMovie) {
            return res.status(409).json({
                error: 'Movie already exists',
                message: `"${existingMovie.title}" is already in your library`,
                movie: existingMovie
            });
        }

        let movieData;
        if (source === 'tmdb') {
            movieData = await fetchFromTMDB('movie', id);
        } else if (source === 'imdb') {
            movieData = await fetchFromIMDB(id);
        }

        const movie = {
            id: Date.now().toString(),
            externalId: id,
            source: source,
            catalogId: catalogId || 'vflixprime-movies', // Use provided or default catalog
            uploadedBy: req.session.userId, // Track who uploaded
            uploadedByUsername: req.session.username,
            ...movieData,
            addedAt: new Date().toISOString()
        };

        movies.push(movie);
        saveData(MOVIES_FILE, movies); // Save to file
        res.json({ success: true, movie });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.put('/api/movies/:id', isAuthenticated, (req, res) => {
    const { id } = req.params;
    const index = movies.findIndex(m => m.id === id);

    if (index !== -1) {
        movies[index] = { ...movies[index], ...req.body, updatedAt: new Date().toISOString() };
        saveData(MOVIES_FILE, movies); // Save to file
        res.json({ success: true, movie: movies[index] });
    } else {
        res.status(404).json({ error: 'Movie not found' });
    }
});

app.delete('/api/movies/:id', isAuthenticated, (req, res) => {
    const { id } = req.params;
    const movie = movies.find(m => m.id === id);

    if (!movie) {
        return res.status(404).json({ error: 'Movie not found' });
    }

    // Check ownership for uploaders
    if (req.session.role === 'uploader' && movie.uploadedBy !== req.session.userId) {
        return res.status(403).json({ error: 'You can only delete content you uploaded' });
    }

    movies = movies.filter(m => m.id !== id);
    saveData(MOVIES_FILE, movies); // Save to file
    res.json({ success: true });
});

// Series API
app.get('/api/series', isAuthenticated, (req, res) => {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;

    // Filter by catalog access for uploaders
    let filteredSeries = series;
    if (req.session.role === 'uploader') {
        filteredSeries = series.filter(s =>
            req.session.catalogAccess.includes(s.catalogId || 'vflixprime-series')
        );
    }

    const reversedSeries = [...filteredSeries].reverse();
    const results = reversedSeries.slice(startIndex, endIndex);

    res.json({
        series: results,
        total: filteredSeries.length,
        page: page,
        totalPages: Math.ceil(filteredSeries.length / limit)
    });
});

app.post('/api/series', isAuthenticated, async (req, res) => {
    try {
        const { id, source, catalogId } = req.body;

        // Check catalog access for uploaders
        if (req.session.role === 'uploader') {
            const requestedCatalog = catalogId || 'vflixprime-series';
            if (!req.session.catalogAccess.includes(requestedCatalog)) {
                return res.status(403).json({ error: 'You do not have access to this catalog' });
            }
        }

        // Check for duplicates
        const existingSeries = series.find(s => s.externalId === id && s.source === source);
        if (existingSeries) {
            return res.status(409).json({
                error: 'Series already exists',
                message: `"${existingSeries.title}" is already in your library`,
                series: existingSeries
            });
        }

        let seriesData;
        if (source === 'tmdb') {
            seriesData = await fetchFromTMDB('tv', id);
        } else if (source === 'imdb') {
            seriesData = await fetchFromIMDB(id);
        }

        const serie = {
            id: Date.now().toString(),
            externalId: id,
            source: source,
            catalogId: catalogId || 'vflixprime-series', // Use provided or default catalog
            uploadedBy: req.session.userId, // Track who uploaded
            uploadedByUsername: req.session.username,
            ...seriesData,
            addedAt: new Date().toISOString()
        };

        series.push(serie);
        saveData(SERIES_FILE, series); // Save to file
        res.json({ success: true, series: serie });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.put('/api/series/:id', isAuthenticated, (req, res) => {
    const { id } = req.params;
    const index = series.findIndex(s => s.id === id);

    if (index !== -1) {
        series[index] = { ...series[index], ...req.body, updatedAt: new Date().toISOString() };
        saveData(SERIES_FILE, series); // Save to file
        res.json({ success: true, series: series[index] });
    } else {
        res.status(404).json({ error: 'Series not found' });
    }
});

app.delete('/api/series/:id', isAuthenticated, (req, res) => {
    const { id } = req.params;
    const serie = series.find(s => s.id === id);

    if (!serie) {
        return res.status(404).json({ error: 'Series not found' });
    }

    // Check ownership for uploaders
    if (req.session.role === 'uploader' && serie.uploadedBy !== req.session.userId) {
        return res.status(403).json({ error: 'You can only delete content you uploaded' });
    }

    series = series.filter(s => s.id !== id);
    saveData(SERIES_FILE, series); // Save to file
    res.json({ success: true });
});

// Bulk Delete Movies
app.post('/api/movies/bulk-delete', isAuthenticated, (req, res) => {
    try {
        const { ids } = req.body;

        if (!ids || !Array.isArray(ids) || ids.length === 0) {
            return res.status(400).json({ error: 'IDs array is required' });
        }

        let deletedCount = 0;
        let deniedCount = 0;

        ids.forEach(id => {
            const movie = movies.find(m => m.id === id);
            if (movie) {
                // Check ownership for uploaders
                if (req.session.role === 'admin' || movie.uploadedBy === req.session.userId) {
                    movies = movies.filter(m => m.id !== id);
                    deletedCount++;
                } else {
                    deniedCount++;
                }
            }
        });

        saveData(MOVIES_FILE, movies);
        res.json({
            success: true,
            deletedCount,
            deniedCount,
            message: `Deleted ${deletedCount} movies${deniedCount > 0 ? `, ${deniedCount} denied (not owned by you)` : ''}`
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Bulk Delete Series
app.post('/api/series/bulk-delete', isAuthenticated, (req, res) => {
    try {
        const { ids } = req.body;

        if (!ids || !Array.isArray(ids) || ids.length === 0) {
            return res.status(400).json({ error: 'IDs array is required' });
        }

        let deletedCount = 0;
        let deniedCount = 0;

        ids.forEach(id => {
            const serie = series.find(s => s.id === id);
            if (serie) {
                // Check ownership for uploaders
                if (req.session.role === 'admin' || serie.uploadedBy === req.session.userId) {
                    series = series.filter(s => s.id !== id);
                    deletedCount++;
                } else {
                    deniedCount++;
                }
            }
        });

        saveData(SERIES_FILE, series);
        res.json({
            success: true,
            deletedCount,
            deniedCount,
            message: `Deleted ${deletedCount} series${deniedCount > 0 ? `, ${deniedCount} denied (not owned by you)` : ''}`
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Bulk Import API
app.post('/api/import', isAuthenticated, async (req, res) => {
    try {
        const { id, source, catalogId } = req.body;
        // Currently only supporting IMDB for bulk import as per request
        if (source !== 'imdb') {
            return res.status(400).json({ error: 'Only IMDB source supported for bulk import' });
        }

        // Check catalog access for uploaders
        if (req.session.role === 'uploader' && catalogId) {
            if (!req.session.catalogAccess.includes(catalogId)) {
                return res.status(403).json({ error: 'You do not have access to this catalog' });
            }
        }

        // Check if already exists in either database
        const existingMovie = movies.find(m => m.externalId === id || m.imdbId === id);
        if (existingMovie) {
            return res.json({
                success: true,
                action: 'skipped',
                message: 'Already exists in movies',
                title: existingMovie.title,
                type: 'movie'
            });
        }

        const existingSeries = series.find(s => s.externalId === id || s.imdbId === id);
        if (existingSeries) {
            return res.json({
                success: true,
                action: 'skipped',
                message: 'Already exists in series',
                title: existingSeries.title,
                type: 'series'
            });
        }

        // Fetch data
        const data = await fetchFromIMDB(id);

        if (data.type === 'movie') {
            const targetCatalog = catalogId || 'vflixprime-movies';
            // Check catalog access for uploaders
            if (req.session.role === 'uploader' && !req.session.catalogAccess.includes(targetCatalog)) {
                return res.status(403).json({ error: 'You do not have access to this catalog' });
            }

            const movie = {
                id: Date.now().toString(),
                externalId: data.tmdbId,
                imdbId: id,
                source: 'tmdb',
                catalogId: targetCatalog,
                uploadedBy: req.session.userId,
                uploadedByUsername: req.session.username,
                ...data,
                addedAt: new Date().toISOString()
            };
            movies.push(movie);
            saveData(MOVIES_FILE, movies);
            return res.json({ success: true, action: 'added', title: movie.title, type: 'movie' });
        } else if (data.type === 'tv' || data.type === 'series') {
            const targetCatalog = catalogId || 'vflixprime-series';
            // Check catalog access for uploaders
            if (req.session.role === 'uploader' && !req.session.catalogAccess.includes(targetCatalog)) {
                return res.status(403).json({ error: 'You do not have access to this catalog' });
            }

            const serie = {
                id: Date.now().toString(),
                externalId: data.tmdbId,
                imdbId: id,
                source: 'tmdb',
                catalogId: targetCatalog,
                uploadedBy: req.session.userId,
                uploadedByUsername: req.session.username,
                ...data,
                addedAt: new Date().toISOString()
            };
            series.push(serie);
            saveData(SERIES_FILE, series);
            return res.json({ success: true, action: 'added', title: serie.title, type: 'series' });
        } else {
            return res.status(400).json({ error: 'Unknown content type' });
        }

    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
});

// TMDB Fetch Function
async function fetchFromTMDB(type, id) {
    const TMDB_API_KEY = getNextApiKey(); // Use rotating API key
    const url = `https://api.themoviedb.org/3/${type}/${id}?api_key=${TMDB_API_KEY}&append_to_response=credits,videos`;

    try {
        const response = await axiosInstance.get(url);
        const data = response.data;

        // Base metadata
        const metadata = {
            type: type === 'tv' ? 'series' : 'movie', // Normalize type
            tmdbId: data.id, // Store explicit TMDB ID
            title: data.title || data.name,
            originalTitle: data.original_title || data.original_name,
            overview: data.overview,
            poster: data.poster_path ? `https://image.tmdb.org/t/p/w500${data.poster_path}` : null,
            backdrop: data.backdrop_path ? `https://image.tmdb.org/t/p/original${data.backdrop_path}` : null,
            releaseDate: data.release_date || data.first_air_date,
            rating: data.vote_average,
            genres: data.genres.map(g => g.name),
            runtime: data.runtime || data.episode_run_time?.[0],
            cast: data.credits?.cast?.slice(0, 10).map(c => c.name) || [],
            director: data.credits?.crew?.find(c => c.job === 'Director')?.name || '',
            trailer: data.videos?.results?.find(v => v.type === 'Trailer')?.key || '',
            seasons: data.seasons?.length || 0,
            episodes: data.number_of_episodes || 0,
            imdbId: null // Will be fetched separately
        };

        // Fetch IMDB ID from external_ids
        try {
            const externalIdsUrl = `https://api.themoviedb.org/3/${type}/${id}/external_ids?api_key=${TMDB_API_KEY}`;
            const externalIdsResponse = await axiosInstance.get(externalIdsUrl);
            metadata.imdbId = externalIdsResponse.data.imdb_id || null;
        } catch (error) {
            console.log(`Could not fetch IMDB ID: ${error.message}`);
        }

        // For TV series, fetch detailed season and episode information
        if (type === 'tv' && data.seasons && data.seasons.length > 0) {
            const seasonsData = [];

            // Fetch details for each season (limit to first 10 seasons to avoid too many requests)
            const seasonsToFetch = data.seasons.filter(s => s.season_number > 0).slice(0, 10);

            for (const season of seasonsToFetch) {
                try {
                    const seasonUrl = `https://api.themoviedb.org/3/tv/${id}/season/${season.season_number}?api_key=${TMDB_API_KEY}`;
                    const seasonResponse = await axiosInstance.get(seasonUrl);
                    const seasonData = seasonResponse.data;

                    seasonsData.push({
                        number: season.season_number,
                        name: seasonData.name,
                        overview: seasonData.overview,
                        episodeCount: seasonData.episodes.length,
                        airDate: seasonData.air_date,
                        episodes: seasonData.episodes.map(ep => ({
                            number: ep.episode_number,
                            name: ep.name,
                            overview: ep.overview,
                            airDate: ep.air_date,
                            runtime: ep.runtime,
                            stillPath: ep.still_path ? `https://image.tmdb.org/t/p/w300${ep.still_path}` : null
                        }))
                    });
                } catch (seasonError) {
                    console.error(`Error fetching season ${season.season_number}:`, seasonError.message);
                    // Continue with other seasons even if one fails
                }
            }

            metadata.seasonsData = seasonsData;
        }

        return metadata;
    } catch (error) {
        throw new Error('Failed to fetch from TMDB: ' + error.message);
    }
}

// IMDB Fetch Function (using TMDB's Find by External ID)
async function fetchFromIMDB(imdbId) {
    const TMDB_API_KEY = getNextApiKey(); // Use rotating API key

    // First, find the TMDB ID using the IMDB ID
    const findUrl = `https://api.themoviedb.org/3/find/${imdbId}?api_key=${TMDB_API_KEY}&external_source=imdb_id`;

    try {
        const findResponse = await axiosInstance.get(findUrl);
        const findData = findResponse.data;

        // Check if we found a movie or TV show
        let tmdbId, type;
        if (findData.movie_results && findData.movie_results.length > 0) {
            tmdbId = findData.movie_results[0].id;
            type = 'movie';
        } else if (findData.tv_results && findData.tv_results.length > 0) {
            tmdbId = findData.tv_results[0].id;
            type = 'tv';
        } else {
            throw new Error('No results found for this IMDB ID');
        }

        // Now fetch the full details from TMDB
        return await fetchFromTMDB(type, tmdbId);

    } catch (error) {
        throw new Error('Failed to fetch from IMDB: ' + error.message);
    }
}

// ============================================
// CATALOG MANAGEMENT API
// ============================================

// Get all catalogs
app.get('/api/catalogs', isAuthenticated, (req, res) => {
    res.json(catalogs);
});

// Create catalog
app.post('/api/catalogs', isAuthenticated, (req, res) => {
    try {
        const { name, type, externalMetaUrl } = req.body;

        if (!name || !type) {
            return res.status(400).json({ error: 'Name and type are required' });
        }

        if (type !== 'movie' && type !== 'series') {
            return res.status(400).json({ error: 'Type must be movie or series' });
        }

        // Generate ID from name
        const id = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');

        // Check for duplicates
        if (catalogs.find(c => c.id === id)) {
            return res.status(409).json({ error: 'Catalog with this name already exists' });
        }

        const catalog = {
            id,
            name,
            type,
            externalMetaUrl: externalMetaUrl || null,
            createdAt: new Date().toISOString()
        };

        catalogs.push(catalog);
        saveData(CATALOGS_FILE, catalogs);

        res.json({ success: true, catalog });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update catalog
app.put('/api/catalogs/:id', isAuthenticated, (req, res) => {
    try {
        const { id } = req.params;
        const { name, externalMetaUrl } = req.body;

        const index = catalogs.findIndex(c => c.id === id);
        if (index === -1) {
            return res.status(404).json({ error: 'Catalog not found' });
        }

        // Don't allow renaming default catalogs
        if (id === 'vflixprime-movies' || id === 'vflixprime-series') {
            return res.status(403).json({ error: 'Cannot rename default catalogs' });
        }

        catalogs[index].name = name;
        if (externalMetaUrl !== undefined) {
            catalogs[index].externalMetaUrl = externalMetaUrl || null;
        }
        catalogs[index].updatedAt = new Date().toISOString();
        saveData(CATALOGS_FILE, catalogs);

        res.json({ success: true, catalog: catalogs[index] });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Delete catalog
app.delete('/api/catalogs/:id', isAuthenticated, (req, res) => {
    try {
        const { id } = req.params;

        // Don't allow deleting default catalogs
        if (id === 'vflixprime-movies' || id === 'vflixprime-series') {
            return res.status(403).json({ error: 'Cannot delete default catalogs' });
        }

        const catalog = catalogs.find(c => c.id === id);
        if (!catalog) {
            return res.status(404).json({ error: 'Catalog not found' });
        }

        // Move content to default catalog
        const defaultCatalogId = catalog.type === 'movie' ? 'vflixprime-movies' : 'vflixprime-series';

        if (catalog.type === 'movie') {
            movies.forEach(m => {
                if (m.catalogId === id) {
                    m.catalogId = defaultCatalogId;
                }
            });
            saveData(MOVIES_FILE, movies);
        } else {
            series.forEach(s => {
                if (s.catalogId === id) {
                    s.catalogId = defaultCatalogId;
                }
            });
            saveData(SERIES_FILE, series);
        }

        catalogs = catalogs.filter(c => c.id !== id);
        saveData(CATALOGS_FILE, catalogs);

        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ============================================
// PROVIDER MANAGEMENT API
// ============================================

// Get all providers
app.get('/api/providers', isAuthenticated, (req, res) => {
    res.json(providers);
});

// Create provider
app.post('/api/providers', isAuthenticated, (req, res) => {
    try {
        const { name, movieUrl, seriesUrl } = req.body;

        if (!name || (!movieUrl && !seriesUrl)) {
            return res.status(400).json({ error: 'Name and at least one URL (movie or series) are required' });
        }

        const id = Date.now().toString();
        const provider = {
            id,
            name,
            movieUrl: movieUrl || '',
            seriesUrl: seriesUrl || '',
            timeout: parseInt(req.body.timeout) || 10000,
            priority: parseInt(req.body.priority) || 10,
            enabled: true,
            createdAt: new Date().toISOString()
        };

        providers.push(provider);
        saveData(PROVIDERS_FILE, providers);

        res.json({ success: true, provider });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update provider
app.put('/api/providers/:id', isAuthenticated, (req, res) => {
    try {
        const { id } = req.params;
        const index = providers.findIndex(p => p.id === id);

        if (index === -1) {
            return res.status(404).json({ error: 'Provider not found' });
        }

        providers[index] = { ...providers[index], ...req.body, updatedAt: new Date().toISOString() };
        saveData(PROVIDERS_FILE, providers);

        res.json({ success: true, provider: providers[index] });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Delete provider
app.delete('/api/providers/:id', isAuthenticated, (req, res) => {
    try {
        const { id } = req.params;
        const index = providers.findIndex(p => p.id === id);

        if (index === -1) {
            return res.status(404).json({ error: 'Provider not found' });
        }

        providers = providers.filter(p => p.id !== id);
        saveData(PROVIDERS_FILE, providers);

        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ============================================
// USER MANAGEMENT API
// ============================================

// Get all users (admin only)
app.get('/api/users', isAdmin, (req, res) => {
    // Don't send passwords to frontend
    const safeUsers = users.map(u => ({
        id: u.id,
        username: u.username,
        role: u.role,
        catalogAccess: u.catalogAccess,
        createdAt: u.createdAt,
        createdBy: u.createdBy
    }));
    res.json(safeUsers);
});

// Create user (admin only)
app.post('/api/users', isAdmin, (req, res) => {
    try {
        const { username, password, role, catalogAccess } = req.body;

        if (!username || !role) {
            return res.status(400).json({ error: 'Username and role are required' });
        }

        if (role !== 'streaming' && !password) {
            return res.status(400).json({ error: 'Password is required' });
        }

        if (role !== 'admin' && role !== 'uploader' && role !== 'streaming') {
            return res.status(400).json({ error: 'Role must be admin, uploader, or streaming' });
        }

        // Check for duplicate username
        if (users.find(u => u.username === username)) {
            return res.status(409).json({ error: 'Username already exists' });
        }

        const newUser = {
            id: Date.now().toString(),
            username,
            password: password ? bcrypt.hashSync(password, 10) : null,
            role,
            catalogAccess: catalogAccess || [],
            createdAt: new Date().toISOString(),
            createdBy: req.session.username
        };

        users.push(newUser);
        saveData(USERS_FILE, users);

        // Return user without password
        const { password: _, ...safeUser } = newUser;
        res.json({ success: true, user: safeUser });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update user (admin only)
app.put('/api/users/:id', isAdmin, (req, res) => {
    try {
        const { id } = req.params;
        const { username, password, role, catalogAccess } = req.body;

        const index = users.findIndex(u => u.id === id);
        if (index === -1) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Don't allow changing the default admin user's role
        if (users[index].id === '1' && role !== 'admin') {
            return res.status(403).json({ error: 'Cannot change default admin role' });
        }

        // Update fields
        if (username) users[index].username = username;
        if (password) {
            users[index].password = bcrypt.hashSync(password, 10);
        } else if (role !== 'streaming' && !users[index].password) {
            return res.status(400).json({ error: 'Password is required for this role' });
        }
        if (role) users[index].role = role;
        if (catalogAccess !== undefined) users[index].catalogAccess = catalogAccess;
        users[index].updatedAt = new Date().toISOString();

        saveData(USERS_FILE, users);

        const { password: _, ...safeUser } = users[index];
        res.json({ success: true, user: safeUser });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Delete user (admin only)
app.delete('/api/users/:id', isAdmin, (req, res) => {
    try {
        const { id } = req.params;

        // Don't allow deleting the default admin
        if (id === '1') {
            return res.status(403).json({ error: 'Cannot delete default admin user' });
        }

        const userIndex = users.findIndex(u => u.id === id);
        if (userIndex === -1) {
            return res.status(404).json({ error: 'User not found' });
        }

        users.splice(userIndex, 1);
        saveData(USERS_FILE, users);

        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Public Invite API
app.post('/api/public/invite', (req, res) => {
    console.log('Debug: Received invite request for username:', req.body.username);
    try {
        let { username } = req.body;

        if (!username) {
            return res.status(400).json({ error: 'Username is required' });
        }

        // Clean username (telegram handles usually start with @)
        username = username.trim().toLowerCase();
        if (username.startsWith('@')) {
            username = username.substring(1);
        }

        // Basic validation
        if (username.length < 3) {
            return res.status(400).json({ error: 'Username too short' });
        }

        // Check for duplicate username
        const existingUser = users.find(u => u.username === username);

        const protocol = req.headers['x-forwarded-proto'] || req.protocol;
        const host = req.get('host');
        // If port is not 80/443, include it
        const manifestUrl = `${protocol}://${host}/stremio/${username}/manifest.json`;

        if (existingUser) {
            // For streaming role, we can just return the URL if they already exist
            return res.json({ success: true, message: 'Welcome back!', manifestUrl });
        }

        const newUser = {
            id: Date.now().toString(),
            username,
            password: null,
            role: 'streaming',
            catalogAccess: [],
            createdAt: new Date().toISOString(),
            createdBy: 'self-invite'
        };

        users.push(newUser);
        saveData(USERS_FILE, users);

        res.json({ success: true, message: 'Account created successfully!', manifestUrl });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ============================================
// SETTINGS
// ============================================

app.get('/api/settings', isAuthenticated, (req, res) => {
    res.json(settings);
});

app.post('/api/settings', isAuthenticated, (req, res) => {
    try {
        console.log('Debug: Received settings update:', req.body);
        const { masterTimeout, cacheDuration } = req.body;

        settings.masterTimeout = parseInt(masterTimeout);
        if (isNaN(settings.masterTimeout)) settings.masterTimeout = 8000;

        settings.cacheDuration = parseInt(cacheDuration);
        if (isNaN(settings.cacheDuration)) settings.cacheDuration = 3600;

        const saved = saveData(SETTINGS_FILE, settings);
        console.log(`Debug: Settings save operation result: ${saved}`);
        if (!saved) {
            console.error('Debug: Failed to write settings file');
            throw new Error('Failed to persist settings to disk');
        }

        console.log(`⚙️ Global Settings Updated: Timeout=${settings.masterTimeout}ms, Cache=${settings.cacheDuration}s`);

        res.json({
            success: true,
            settings,
            debug: {
                received: req.body,
                parsed: {
                    masterTimeout: settings.masterTimeout,
                    cacheDuration: settings.cacheDuration
                }
            }
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Analytics API
app.get('/api/analytics', isAuthenticated, (req, res) => {
    try {
        const stats = analytics.getStats();
        const activeNow = analytics.getActiveNow();
        res.json({
            ...stats,
            activeNow
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Stremio Addon Routing
const addonRouter = require('./addon');

// 1. Handle default paths (teaser mode - no username)
// This catches /stremio/manifest.json, /stremio/catalog/..., etc.
app.use('/stremio', (req, res, next) => {
    // If there's no username (path is /manifest.json, /catalog/..., etc.)
    const parts = req.path.split('/').filter(Boolean);
    const reserved = ['manifest.json', 'catalog', 'meta', 'stream', 'img'];

    if (parts.length > 0 && reserved.includes(parts[0])) {
        // Forward as a default path (username will be null/undefined in addon.js)
        return addonRouter(req, res, next);
    }
    next();
});

// 2. Handle username-prefixed paths (/stremio/username/...)
app.use('/stremio/:username', addonRouter);

app.listen(PORT, () => {
    console.log(`VFlixPrime server running on http://localhost:${PORT}`);
});
