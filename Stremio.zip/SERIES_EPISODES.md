# TV Series - Seasons & Episodes Support ✅

## Fixed: Series Now Show Seasons and Episodes!

Your addon now properly displays seasons and episodes for TV series in Stremio instead of showing a direct streaming option.

## How It Works

### Series Meta Response

When Stremio requests metadata for a TV series, the addon now returns a `videos` array containing all seasons and episodes:

```json
{
  "meta": {
    "id": "vflix:1733734678901",
    "type": "series",
    "name": "Game of Thrones",
    "videos": [
      {
        "id": "vflix:1733734678901:1:1",
        "title": "S1E1",
        "season": 1,
        "episode": 1
      },
      {
        "id": "vflix:1733734678901:1:2",
        "title": "S1E2",
        "season": 1,
        "episode": 2
      },
      ...
    ]
  }
}
```

### Episode ID Format

**Format**: `vflix:seriesId:season:episode`

**Examples**:
- `vflix:1733734678901:1:1` - Season 1, Episode 1
- `vflix:1733734678901:2:5` - Season 2, Episode 5
- `vflix:1733734678901:8:6` - Season 8, Episode 6

### Stream URLs

When a user clicks on an episode, Stremio requests:
```
GET /stream/series/vflix:1733734678901:1:1.json
```

The addon parses this and returns:
```json
{
  "streams": [
    {
      "title": "VFlixPrime - S1E1",
      "url": "https://your-stream-server.com/series/1733734678901/s1e1"
    }
  ]
}
```

## Episode Generation

### How Episodes Are Generated

The addon automatically generates episodes based on the series data:

```javascript
const numSeasons = serie.seasons || 1;  // Number of seasons from TMDB
const episodesPerSeason = serie.episodes 
    ? Math.ceil(serie.episodes / numSeasons)  // Distribute total episodes
    : 10;  // Default 10 episodes if not specified
```

### Example: Game of Thrones

**From TMDB Data:**
- Total Seasons: 8
- Total Episodes: 73

**Generated Episodes:**
- Season 1: 10 episodes (73 / 8 ≈ 9.1, rounded up)
- Season 2: 10 episodes
- Season 3: 10 episodes
- ...
- Season 8: 10 episodes

**Note**: This is an estimation. For accurate episode counts per season, you would need to fetch detailed season data from TMDB.

## User Experience in Stremio

### Before (Wrong):
1. User clicks on series
2. Sees direct "Stream" button ❌
3. No season/episode selection

### After (Correct):
1. User clicks on series ✅
2. Sees list of seasons
3. Clicks on a season
4. Sees list of episodes
5. Clicks on an episode
6. Sees stream options

## Testing

### Test with Your Series

1. **Add a series** (e.g., Game of Thrones - TMDB: 1399)
2. **Install addon** in Stremio
3. **Open the series** in Stremio
4. **You should see**:
   - Series information
   - Seasons listed
   - Episodes within each season

### Meta URL to Test

**Get series metadata:**
```
http://localhost:3000/stremio/meta/series/vflix:[YOUR_SERIES_ID].json
```

**Example:**
```
http://localhost:3000/stremio/meta/series/vflix:1733734678901.json
```

**Should return** `videos` array with all episodes.

### Stream URL to Test

**Get episode stream:**
```
http://localhost:3000/stremio/stream/series/vflix:[SERIES_ID]:[SEASON]:[EPISODE].json
```

**Example:**
```
http://localhost:3000/stremio/stream/series/vflix:1733734678901:1:1.json
```

**Should return** stream with title "VFlixPrime - S1E1".

## Improving Episode Accuracy

### Current Limitation

The addon estimates episodes per season by dividing total episodes by number of seasons. This means all seasons have the same number of episodes.

### For Accurate Episode Counts

You can enhance the addon to fetch detailed season information from TMDB:

```javascript
// Fetch season details
const seasonUrl = `https://api.themoviedb.org/3/tv/${tmdbId}/season/${seasonNumber}`;
const seasonData = await fetch(seasonUrl);
const actualEpisodes = seasonData.episodes.length;
```

### Future Enhancement

Store season-specific data when adding a series:

```javascript
{
  "id": "1733734678901",
  "title": "Game of Thrones",
  "seasons": [
    { "number": 1, "episodes": 10 },
    { "number": 2, "episodes": 10 },
    { "number": 3, "episodes": 10 },
    ...
  ]
}
```

## Stream Server Integration

### Placeholder URLs

Currently, the addon returns placeholder URLs:

```
https://your-stream-server.com/series/[ID]/s[SEASON]e[EPISODE]
```

### For Production

Replace with your actual streaming server:

**Option 1: Direct File URLs**
```javascript
url: `https://cdn.example.com/series/${contentId}/s${season}e${episode}.mp4`
```

**Option 2: HLS Streaming**
```javascript
url: `https://stream.example.com/series/${contentId}/s${season}e${episode}/master.m3u8`
```

**Option 3: Torrent Magnet Links**
```javascript
url: `magnet:?xt=urn:btih:${torrentHash}&dn=${encodeURIComponent(title)}`
```

## Summary

### What Changed:

✅ **Series meta** now includes `videos` array
✅ **Episodes** are generated for each season
✅ **Episode IDs** include season and episode numbers
✅ **Stream handler** parses season/episode from ID
✅ **Stream titles** show "S1E1" format

### Result:

- ✅ Stremio shows seasons and episodes
- ✅ Users can select specific episodes
- ✅ Proper TV series navigation
- ✅ Better user experience

### Next Steps:

1. **Restart server** to apply changes
2. **Test with a series** in Stremio
3. **Verify** seasons and episodes appear
4. **Configure** actual stream URLs when ready

---

**TV series now work properly in Stremio! 🎉**

Users can browse seasons and select individual episodes.
