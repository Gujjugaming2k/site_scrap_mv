// Check authentication
async function checkAuth() {
    try {
        const response = await fetch('/api/check-auth');
        const data = await response.json();

        if (!data.authenticated) {
            window.location.href = '/';
        } else if (data.user.role !== 'admin') {
            // Only admins can access user management
            window.location.href = '/admin';
        }
    } catch (error) {
        console.error('Auth check failed:', error);
        window.location.href = '/';
    }
}

// Initialize
checkAuth();
loadUsers();

// Logout
document.getElementById('logoutBtn').addEventListener('click', async () => {
    try {
        await fetch('/api/logout', { method: 'POST' });
        window.location.href = '/';
    } catch (error) {
        console.error('Logout failed:', error);
    }
});

// Load users
async function loadUsers() {
    try {
        const response = await fetch('/api/users');
        const users = await response.json();

        const tableHtml = users.map(user => `
            <tr>
                <td>${user.username}</td>
                <td><span style="text-transform: capitalize; color: ${user.role === 'admin' ? 'var(--primary)' : 'var(--secondary)'};">${user.role}</span></td>
                <td>${user.catalogAccess && user.catalogAccess.length > 0 ? user.catalogAccess.join(', ') : '<span style="color: var(--gray);">All (Admin)</span>'}</td>
                <td>${new Date(user.createdAt).toLocaleDateString()}</td>
                <td>
                    <div class="action-btns">
                        ${user.id !== '1' ? `<button class="btn btn-secondary btn-sm" onclick="editUser('${user.id}')">Edit</button>` : ''}
                        ${user.id !== '1' ? `<button class="btn btn-danger btn-sm" onclick="deleteUser('${user.id}', '${user.username}')">Delete</button>` : '<span style="color: var(--gray); font-size: 0.85rem;">System Admin</span>'}
                    </div>
                </td>
            </tr>
        `).join('') || '<tr><td colspan="5" style="text-align: center; color: var(--gray);">No users found</td></tr>';

        document.getElementById('users-table').innerHTML = tableHtml;
    } catch (error) {
        showAlert('Failed to load users', 'error');
    }
}

// Open add user modal
async function openAddUserModal() {
    await loadCatalogCheckboxes('catalog-checkboxes');
    toggleCatalogAccess();
    document.getElementById('add-user-modal').classList.add('active');
}

// Toggle catalog access visibility based on role
function toggleCatalogAccess() {
    const role = document.getElementById('user-role').value;
    const catalogGroup = document.getElementById('catalog-access-group');
    const passwordGroup = document.getElementById('user-password').closest('.input-group');

    catalogGroup.style.display = role === 'uploader' ? 'block' : 'none';
    passwordGroup.style.display = role === 'streaming' ? 'none' : 'block';
    document.getElementById('user-password').required = role !== 'streaming';
}

function toggleEditCatalogAccess() {
    const role = document.getElementById('edit-user-role').value;
    const catalogGroup = document.getElementById('edit-catalog-access-group');
    const passwordGroup = document.getElementById('edit-user-password').closest('.input-group');

    catalogGroup.style.display = role === 'uploader' ? 'block' : 'none';
    passwordGroup.style.display = role === 'streaming' ? 'none' : 'block';
}

// Load catalog checkboxes
async function loadCatalogCheckboxes(containerId, selectedCatalogs = []) {
    try {
        const response = await fetch('/api/catalogs');
        const catalogs = await response.json();

        const container = document.getElementById(containerId);
        container.innerHTML = catalogs.map(catalog => `
            <div class="catalog-checkbox">
                <input type="checkbox" id="${containerId}-${catalog.id}" value="${catalog.id}" ${selectedCatalogs.includes(catalog.id) ? 'checked' : ''}>
                <label for="${containerId}-${catalog.id}">${catalog.name} (${catalog.type})</label>
            </div>
        `).join('');
    } catch (error) {
        console.error('Failed to load catalogs:', error);
    }
}

// Get selected catalogs from checkboxes
function getSelectedCatalogs(containerId) {
    const checkboxes = document.querySelectorAll(`#${containerId} input[type="checkbox"]:checked`);
    return Array.from(checkboxes).map(cb => cb.value);
}

// Add user form submission
document.getElementById('add-user-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const username = document.getElementById('user-username').value;
    const password = document.getElementById('user-password').value;
    const role = document.getElementById('user-role').value;
    const catalogAccess = role === 'uploader' ? getSelectedCatalogs('catalog-checkboxes') : [];

    if (role !== 'streaming' && !password) {
        showAlert('Please enter a password', 'error');
        return;
    }

    if (role === 'uploader' && catalogAccess.length === 0) {
        showAlert('Please select at least one catalog for uploader', 'error');
        return;
    }

    try {
        const response = await fetch('/api/users', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password, role, catalogAccess })
        });

        const data = await response.json();

        if (response.ok) {
            showAlert('User created successfully!', 'success');
            closeModal('add-user-modal');
            document.getElementById('add-user-form').reset();
            loadUsers();
        } else {
            showAlert(data.error || 'Failed to create user', 'error');
        }
    } catch (error) {
        showAlert('Network error. Please try again.', 'error');
    }
});

// Edit user
async function editUser(id) {
    try {
        const response = await fetch('/api/users');
        const users = await response.json();
        const user = users.find(u => u.id === id);

        if (user) {
            document.getElementById('edit-user-id').value = user.id;
            document.getElementById('edit-user-username').value = user.username;
            document.getElementById('edit-user-password').value = '';
            document.getElementById('edit-user-role').value = user.role;

            await loadCatalogCheckboxes('edit-catalog-checkboxes', user.catalogAccess || []);
            toggleEditCatalogAccess();

            document.getElementById('edit-user-modal').classList.add('active');
        }
    } catch (error) {
        showAlert('Failed to load user for editing', 'error');
    }
}

// Edit user form submission
document.getElementById('edit-user-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const id = document.getElementById('edit-user-id').value;
    const username = document.getElementById('edit-user-username').value;
    const password = document.getElementById('edit-user-password').value;
    const role = document.getElementById('edit-user-role').value;
    const catalogAccess = role === 'uploader' ? getSelectedCatalogs('edit-catalog-checkboxes') : [];

    if (role === 'uploader' && catalogAccess.length === 0) {
        showAlert('Please select at least one catalog for uploader', 'error');
        return;
    }

    const updateData = { username, role, catalogAccess };
    if (password) {
        updateData.password = password;
    }

    try {
        const response = await fetch(`/api/users/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updateData)
        });

        const data = await response.json();

        if (response.ok) {
            showAlert('User updated successfully!', 'success');
            closeModal('edit-user-modal');
            loadUsers();
        } else {
            showAlert(data.error || 'Failed to update user', 'error');
        }
    } catch (error) {
        showAlert('Network error. Please try again.', 'error');
    }
});

// Delete user
async function deleteUser(id, username) {
    if (!confirm(`Are you sure you want to delete user "${username}"?`)) {
        return;
    }

    try {
        const response = await fetch(`/api/users/${id}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            showAlert('User deleted successfully!', 'success');
            loadUsers();
        } else {
            const data = await response.json();
            showAlert(data.error || 'Failed to delete user', 'error');
        }
    } catch (error) {
        showAlert('Network error. Please try again.', 'error');
    }
}

// Modal Functions
function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

// Close modal on background click
document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('active');
        }
    });
});

// Alert Function
function showAlert(message, type) {
    const alertContainer = document.getElementById('alert-container');
    alertContainer.innerHTML = `
        <div class="alert alert-${type}">
            ${message}
        </div>
    `;

    setTimeout(() => {
        alertContainer.innerHTML = '';
    }, 5000);
}
