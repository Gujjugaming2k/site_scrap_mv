// Global user info
let currentUser = null;

// Check authentication
async function checkAuth() {
    try {
        const response = await fetch('/api/check-auth');
        const data = await response.json();

        if (!data.authenticated) {
            window.location.href = '/';
        } else {
            currentUser = data.user;

            // Role-based UI updates
            if (currentUser.role === 'admin') {
                document.getElementById('users-nav-item').style.display = 'block';
            } else if (currentUser.role === 'uploader') {
                // Hide Catalogs and API Docs for uploaders
                document.querySelector('a[data-page="catalogs"]').parentElement.style.display = 'none';
                document.querySelector('a[data-page="api-docs"]').parentElement.style.display = 'none';
            }
        }
    } catch (error) {
        console.error('Auth check failed:', error);
        window.location.href = '/';
    }
}


let currentMoviePage = 1;
let currentSeriesPage = 1;

// Initialize
checkAuth();
loadDashboard();


// Set addon URL
document.getElementById('addon-url').value = `${window.location.origin}/stremio/manifest.json`;

// Navigation
document.querySelectorAll('.navbar-menu a[data-page]').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const page = e.target.dataset.page;
        switchPage(page);
    });
});

function switchPage(pageName) {
    // Update active nav link
    document.querySelectorAll('.navbar-menu a').forEach(link => {
        link.classList.remove('active');
    });
    document.querySelector(`[data-page="${pageName}"]`).classList.add('active');

    // Show page
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    document.getElementById(`${pageName}-page`).classList.add('active');

    // Load page data
    if (pageName === 'dashboard') {
        loadDashboard();
    } else if (pageName === 'movies') {
        loadMovies();
    } else if (pageName === 'series') {
        loadSeries();
    } else if (pageName === 'catalogs') {
        loadCatalogs();
    } else if (pageName === 'providers') {
        loadProviders();
    }
}

// Logout
document.getElementById('logoutBtn').addEventListener('click', async () => {
    try {
        await fetch('/api/logout', { method: 'POST' });
        window.location.href = '/';
    } catch (error) {
        console.error('Logout failed:', error);
    }
});

// Dashboard
async function loadDashboard() {
    try {
        const response = await fetch('/api/dashboard');
        const data = await response.json();

        document.getElementById('total-movies').textContent = data.totalMovies;
        document.getElementById('total-series').textContent = data.totalSeries;

        // Recent movies
        const recentMoviesHtml = data.recentMovies.map(movie => `
            <div class="recent-item">
                <img src="${movie.poster || 'https://via.placeholder.com/40x60?text=No+Image'}" alt="${movie.title}">
                <div class="recent-item-info">
                    <h4>${movie.title}</h4>
                    <p>⭐ ${movie.rating || 'N/A'} • ${movie.releaseDate || 'N/A'}</p>
                </div>
            </div>
        `).join('') || '<p style="color: var(--gray);">No movies added yet</p>';

        document.getElementById('recent-movies').innerHTML = recentMoviesHtml;

        // Recent series
        const recentSeriesHtml = data.recentSeries.map(serie => `
            <div class="recent-item">
                <img src="${serie.poster || 'https://via.placeholder.com/40x60?text=No+Image'}" alt="${serie.title}">
                <div class="recent-item-info">
                    <h4>${serie.title}</h4>
                    <p>⭐ ${serie.rating || 'N/A'} • ${serie.seasons || 0} seasons</p>
                </div>
            </div>
        `).join('') || '<p style="color: var(--gray);">No series added yet</p>';

        document.getElementById('recent-series').innerHTML = recentSeriesHtml;

    } catch (error) {
        showAlert('Failed to load dashboard', 'error');
    }
}

// Movies
async function loadMovies(page = 1) {
    try {
        const response = await fetch(`/api/movies?page=${page}&limit=10`);
        const data = await response.json();
        const movies = data.movies;

        const tableHtml = movies.map(movie => `
            <tr>
                <td><input type="checkbox" class="movie-checkbox" value="${movie.id}" onchange="updateBulkDeleteButton('movies')"></td>
                <td><img src="${movie.poster || 'https://via.placeholder.com/50x75?text=No+Image'}" alt="${movie.title}" class="poster-thumb"></td>
                <td>${movie.title}</td>
                <td>${movie.releaseDate || 'N/A'}</td>
                <td>⭐ ${movie.rating || 'N/A'}</td>
                <td><span style="text-transform: uppercase; color: var(--primary);">${movie.source}</span></td>
                <td>
                    <div class="action-btns">
                        <button class="btn btn-secondary btn-sm" onclick="editContent('${movie.id}', 'movie')">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="deleteContent('${movie.id}', 'movie')">Delete</button>
                    </div>
                </td>
            </tr>
        `).join('') || '<tr><td colspan="7" style="text-align: center; color: var(--gray);">No movies found</td></tr>';

        document.getElementById('movies-table').innerHTML = tableHtml;

        // Update pagination
        currentMoviePage = data.page;
        updatePaginationHelper('movies', data.page, data.totalPages);

    } catch (error) {
        showAlert('Failed to load movies', 'error');
    }
}

// Series
async function loadSeries(page = 1) {
    try {
        const response = await fetch(`/api/series?page=${page}&limit=10`);
        const data = await response.json();
        const series = data.series;

        const tableHtml = series.map(serie => `
            <tr>
                <td><input type="checkbox" class="series-checkbox" value="${serie.id}" onchange="updateBulkDeleteButton('series')"></td>
                <td><img src="${serie.poster || 'https://via.placeholder.com/50x75?text=No+Image'}" alt="${serie.title}" class="poster-thumb"></td>
                <td>${serie.title}</td>
                <td>${serie.releaseDate || 'N/A'}</td>
                <td>⭐ ${serie.rating || 'N/A'}</td>
                <td>${serie.seasons || 0}</td>
                <td><span style="text-transform: uppercase; color: var(--primary);">${serie.source}</span></td>
                <td>
                    <div class="action-btns">
                        <button class="btn btn-secondary btn-sm" onclick="editContent('${serie.id}', 'series')">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="deleteContent('${serie.id}', 'series')">Delete</button>
                    </div>
                </td>
            </tr>
        `).join('') || '<tr><td colspan="8" style="text-align: center; color: var(--gray);">No series found</td></tr>';

        document.getElementById('series-table').innerHTML = tableHtml;

        // Update pagination
        currentSeriesPage = data.page;
        updatePaginationHelper('series', data.page, data.totalPages);

    } catch (error) {
        showAlert('Failed to load series', 'error');
    }
}

// Pagination helper
function updatePaginationHelper(type, currentPage, totalPages) {
    const prevBtn = document.getElementById(`prev-${type}`);
    const nextBtn = document.getElementById(`next-${type}`);
    const pageInfo = document.getElementById(`page-info-${type}`);

    pageInfo.textContent = `Page ${currentPage} of ${totalPages || 1}`;

    prevBtn.disabled = currentPage <= 1;
    nextBtn.disabled = currentPage >= (totalPages || 1);

    // Remove existing event listeners (to prevent duplicate listeners)
    // A better approach is to set onclick handlers directly
    prevBtn.onclick = () => {
        if (currentPage > 1) {
            if (type === 'movies') loadMovies(currentPage - 1);
            else loadSeries(currentPage - 1);
        }
    };

    nextBtn.onclick = () => {
        if (currentPage < totalPages) {
            if (type === 'movies') loadMovies(currentPage + 1);
            else loadSeries(currentPage + 1);
        }
    };
}

// Add Movie
function openAddMovieModal() {
    loadCatalogDropdown('movie', 'movie-catalog');
    document.getElementById('add-movie-modal').classList.add('active');
}

document.getElementById('add-movie-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const source = document.getElementById('movie-source').value;
    const id = document.getElementById('movie-id').value;
    const catalogId = document.getElementById('movie-catalog').value;

    try {
        showAlert('Fetching movie data...', 'warning');

        const response = await fetch('/api/movies', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ source, id, catalogId })
        });

        const data = await response.json();

        if (response.ok) {
            showAlert('Movie added successfully!', 'success');
            closeModal('add-movie-modal');
            document.getElementById('add-movie-form').reset();
            loadMovies();
            loadDashboard();
        } else if (response.status === 409) {
            // Duplicate movie
            showAlert(data.message || 'This movie is already in your library', 'warning');
        } else {
            showAlert(data.error || 'Failed to add movie', 'error');
        }
    } catch (error) {
        showAlert('Network error. Please try again.', 'error');
    }
});

// Add Series
function openAddSeriesModal() {
    loadCatalogDropdown('series', 'series-catalog');
    document.getElementById('add-series-modal').classList.add('active');
}

document.getElementById('add-series-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const source = document.getElementById('series-source').value;
    const id = document.getElementById('series-id').value;
    const catalogId = document.getElementById('series-catalog').value;

    try {
        showAlert('Fetching series data...', 'warning');

        const response = await fetch('/api/series', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ source, id, catalogId })
        });

        const data = await response.json();

        if (response.ok) {
            showAlert('Series added successfully!', 'success');
            closeModal('add-series-modal');
            document.getElementById('add-series-form').reset();
            loadSeries();
            loadDashboard();
        } else if (response.status === 409) {
            // Duplicate series
            showAlert(data.message || 'This series is already in your library', 'warning');
        } else {
            showAlert(data.error || 'Failed to add series', 'error');
        }
    } catch (error) {
        showAlert('Network error. Please try again.', 'error');
    }
});

// Edit Content
async function editContent(id, type) {
    try {
        const endpoint = type === 'movie' ? '/api/movies' : '/api/series';
        const response = await fetch(endpoint);
        const data = await response.json();

        // Handle paginated response
        const items = type === 'movie' ? data.movies : data.series;
        const item = items.find(i => i.id === id);

        if (item) {
            document.getElementById('edit-id').value = id;
            document.getElementById('edit-type').value = type;
            document.getElementById('edit-title').value = item.title;
            document.getElementById('edit-overview').value = item.overview;
            document.getElementById('edit-rating').value = item.rating;
            document.getElementById('edit-poster').value = item.poster;

            // Load custom stream data if exists
            document.getElementById('edit-stream-url').value = item.customStream?.url || '';
            document.getElementById('edit-stream-title').value = item.customStream?.title || '';
            document.getElementById('edit-referer').value = item.customStream?.referer || '';
            document.getElementById('edit-user-agent').value = item.customStream?.userAgent || '';

            document.getElementById('edit-modal-title').textContent = `Edit ${type === 'movie' ? 'Movie' : 'Series'}`;

            document.getElementById('edit-modal').classList.add('active');
        }
    } catch (error) {
        showAlert('Failed to load content for editing', 'error');
    }
}

document.getElementById('edit-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const id = document.getElementById('edit-id').value;
    const type = document.getElementById('edit-type').value;
    const endpoint = type === 'movie' ? '/api/movies' : '/api/series';

    const updatedData = {
        title: document.getElementById('edit-title').value,
        overview: document.getElementById('edit-overview').value,
        rating: parseFloat(document.getElementById('edit-rating').value),
        poster: document.getElementById('edit-poster').value
    };

    // Add custom stream if URL is provided
    const streamUrl = document.getElementById('edit-stream-url').value.trim();
    if (streamUrl) {
        updatedData.customStream = {
            url: streamUrl,
            title: document.getElementById('edit-stream-title').value || '1080p',
            referer: document.getElementById('edit-referer').value,
            userAgent: document.getElementById('edit-user-agent').value
        };
    } else {
        updatedData.customStream = null; // Remove custom stream if URL is empty
    }

    try {
        const response = await fetch(`${endpoint}/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updatedData)
        });

        const data = await response.json();

        if (response.ok) {
            showAlert('Updated successfully!', 'success');
            closeModal('edit-modal');
            if (type === 'movie') {
                loadMovies();
            } else {
                loadSeries();
            }
            loadDashboard();
        } else {
            showAlert(data.error || 'Failed to update', 'error');
        }
    } catch (error) {
        showAlert('Network error. Please try again.', 'error');
    }
});

// Bulk Import
async function openBulkImportModal() {
    document.getElementById('bulk-import-modal').classList.add('active');
    document.getElementById('import-log').innerHTML = '<div style="color: var(--gray);">Ready to start...</div>';
    document.getElementById('bulk-ids').value = '';
    document.getElementById('start-import-btn').disabled = false;
    document.getElementById('close-import-btn').disabled = false;

    // Load all catalogs for selection
    try {
        const response = await fetch('/api/catalogs');
        const catalogs = await response.json();
        const select = document.getElementById('bulk-catalog');
        select.innerHTML = '<option value="">Auto-detect (Movie/Series default)</option>' +
            catalogs.map(c => `<option value="${c.id}">${c.name} (${c.type})</option>`).join('');
    } catch (error) {
        console.error('Failed to load catalogs:', error);
    }
}

async function startBulkImport() {
    const input = document.getElementById('bulk-ids').value.trim();
    const catalogId = document.getElementById('bulk-catalog').value;

    if (!input) {
        alert('Please enter at least one ID');
        return;
    }

    const ids = input.split('\n').map(id => id.trim()).filter(id => id.length > 0);
    if (ids.length === 0) return;

    const logContainer = document.getElementById('import-log');
    const progressContainer = document.getElementById('import-progress');
    const startBtn = document.getElementById('start-import-btn');
    const closeBtn = document.getElementById('close-import-btn');

    startBtn.disabled = true;
    closeBtn.disabled = true;
    logContainer.innerHTML = '';
    progressContainer.innerHTML = '';

    let successCount = 0;
    let skipCount = 0;
    let failCount = 0;

    // Show progress in separate container
    progressContainer.innerHTML = `<span style="color: #4facfe;">📦 Processing ${ids.length} items (10 at a time)...</span>`;

    // Create log lines for all IDs
    const logLines = {};
    ids.forEach(id => {
        const logLine = document.createElement('div');
        logLine.innerHTML = `<span style="color: #888;">⏳ Waiting: ${id}</span>`;
        logContainer.appendChild(logLine);
        logLines[id] = logLine;
    });
    logContainer.scrollTop = logContainer.scrollHeight;

    // Process single ID with retry logic
    async function processId(id, retryCount = 0) {
        const maxRetries = 3;
        const retryDelay = (attempt) => Math.min(1000 * Math.pow(2, attempt), 5000); // Exponential backoff: 1s, 2s, 4s, max 5s

        if (retryCount === 0) {
            logLines[id].innerHTML = `<span style="color: #4facfe;">⏳ Processing ${id}...</span>`;
        } else {
            logLines[id].innerHTML = `<span style="color: #ffa500;">🔄 Retry ${retryCount}/${maxRetries}: ${id}...</span>`;
        }

        try {
            const response = await fetch('/api/import', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id, source: 'imdb', catalogId: catalogId || undefined })
            });

            const data = await response.json();

            if (response.ok && data.success) {
                if (data.action === 'added') {
                    successCount++;
                    logLines[id].innerHTML = `<span style="color: #00f2c3;">✅ Added: ${data.title} (${data.type})</span>`;
                } else {
                    skipCount++;
                    logLines[id].innerHTML = `<span style="color: #f39c12;">⚠️ Skipped: ${data.title}</span>`;
                }
            } else {
                // Check if error is retryable
                const isRetryable = data.error && (
                    data.error.includes('ECONNRESET') ||
                    data.error.includes('ETIMEDOUT') ||
                    data.error.includes('ENOTFOUND') ||
                    data.error.includes('timeout')
                );

                if (isRetryable && retryCount < maxRetries) {
                    // Wait before retry
                    await new Promise(resolve => setTimeout(resolve, retryDelay(retryCount)));
                    return await processId(id, retryCount + 1);
                } else {
                    failCount++;
                    const retryInfo = retryCount > 0 ? ` (after ${retryCount} retries)` : '';
                    logLines[id].innerHTML = `<span style="color: #ff6b6b;">❌ Failed: ${id}${retryInfo} - ${data.error || 'Error'}</span>`;
                }
            }
        } catch (error) {
            // Network error - retry
            if (retryCount < maxRetries) {
                await new Promise(resolve => setTimeout(resolve, retryDelay(retryCount)));
                return await processId(id, retryCount + 1);
            } else {
                failCount++;
                logLines[id].innerHTML = `<span style="color: #ff6b6b;">❌ Failed: ${id} (after ${retryCount} retries) - Network error</span>`;
            }
        }

        const completed = successCount + skipCount + failCount;
        progressContainer.innerHTML = `<span style="color: #4facfe;">📦 Progress: ${completed}/${ids.length} | ✅ ${successCount} | ⚠️ ${skipCount} | ❌ ${failCount}</span>`;
        logContainer.scrollTop = logContainer.scrollHeight;
    }

    // Process in batches of 10
    const BATCH_SIZE = 5;
    for (let i = 0; i < ids.length; i += BATCH_SIZE) {
        const batch = ids.slice(i, i + BATCH_SIZE);
        await Promise.all(batch.map(id => processId(id)));
    }

    // Final summary
    const summaryLine = document.createElement('div');
    summaryLine.style.marginTop = '1rem';
    summaryLine.style.borderTop = '1px solid rgba(255,255,255,0.1)';
    summaryLine.style.paddingTop = '0.5rem';
    summaryLine.innerHTML = `<strong>Done!</strong> Added: ${successCount} | Skipped: ${skipCount} | Failed: ${failCount}`;
    logContainer.appendChild(summaryLine);
    logContainer.scrollTop = logContainer.scrollHeight;

    startBtn.disabled = false;
    closeBtn.disabled = false;

    loadDashboard();
    loadMovies();
    loadSeries();
}

// ============================================
// CATALOG MANAGEMENT
// ============================================

// Load catalogs
async function loadCatalogs() {
    try {
        const response = await fetch('/api/catalogs');
        const catalogs = await response.json();

        const tableHtml = catalogs.map(catalog => {
            const isDefault = catalog.id === 'vflixprime-movies' || catalog.id === 'vflixprime-series';
            return `
            <tr>
                <td>${catalog.name}</td>
                <td><span style="text-transform: capitalize; color: var(--primary);">${catalog.type}</span></td>
                <td><code style="font-size: 0.85rem; color: var(--gray);">${catalog.id}</code></td>
                <td>
                    <div class="action-btns">
                        ${!isDefault ? `<button class="btn btn-secondary btn-sm" onclick="editCatalog('${catalog.id}')">Edit</button>` : ''}
                        ${!isDefault ? `<button class="btn btn-danger btn-sm" onclick="deleteCatalog('${catalog.id}')">Delete</button>` : '<span style="color: var(--gray); font-size: 0.85rem;">Default</span>'}
                    </div>
                </td>
            </tr>
        `}).join('') || '<tr><td colspan="4" style="text-align: center; color: var(--gray);">No catalogs found</td></tr>';

        document.getElementById('catalogs-table').innerHTML = tableHtml;
    } catch (error) {
        showAlert('Failed to load catalogs', 'error');
    }
}

// Load catalog dropdown
async function loadCatalogDropdown(type, selectId) {
    try {
        const response = await fetch('/api/catalogs');
        const catalogs = await response.json();

        // Filter by access for uploaders
        let filteredCatalogs = catalogs.filter(c => c.type === type);

        if (currentUser && currentUser.role === 'uploader') {
            filteredCatalogs = filteredCatalogs.filter(c => currentUser.catalogAccess.includes(c.id));
        }

        const select = document.getElementById(selectId);
        select.innerHTML = filteredCatalogs.map(c =>
            `<option value="${c.id}">${c.name}</option>`
        ).join('');
    } catch (error) {
        console.error('Failed to load catalogs:', error);
    }
}

// Add catalog
function openAddCatalogModal() {
    document.getElementById('add-catalog-modal').classList.add('active');
}

document.getElementById('add-catalog-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = document.getElementById('catalog-name').value;
    const type = document.getElementById('catalog-type').value;
    const externalMetaUrl = document.getElementById('catalog-external-url').value;

    try {
        const response = await fetch('/api/catalogs', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, type, externalMetaUrl })
        });

        const data = await response.json();

        if (response.ok) {
            showAlert('Catalog created successfully!', 'success');
            closeModal('add-catalog-modal');
            document.getElementById('add-catalog-form').reset();
            loadCatalogs();
        } else {
            showAlert(data.error || 'Failed to create catalog', 'error');
        }
    } catch (error) {
        showAlert('Network error. Please try again.', 'error');
    }
});

// Edit catalog
async function editCatalog(id) {
    try {
        const response = await fetch('/api/catalogs');
        const catalogs = await response.json();
        const catalog = catalogs.find(c => c.id === id);

        if (catalog) {
            document.getElementById('edit-catalog-id').value = id;
            document.getElementById('edit-catalog-name').value = catalog.name;
            document.getElementById('edit-catalog-external-url').value = catalog.externalMetaUrl || '';
            document.getElementById('edit-catalog-modal').classList.add('active');
        }
    } catch (error) {
        showAlert('Failed to load catalog for editing', 'error');
    }
}

document.getElementById('edit-catalog-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const id = document.getElementById('edit-catalog-id').value;
    const name = document.getElementById('edit-catalog-name').value;
    const externalMetaUrl = document.getElementById('edit-catalog-external-url').value;

    try {
        const response = await fetch(`/api/catalogs/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, externalMetaUrl })
        });

        const data = await response.json();

        if (response.ok) {
            showAlert('Catalog updated successfully!', 'success');
            closeModal('edit-catalog-modal');
            loadCatalogs();
        } else {
            showAlert(data.error || 'Failed to update catalog', 'error');
        }
    } catch (error) {
        showAlert('Network error. Please try again.', 'error');
    }
});

// Delete catalog
async function deleteCatalog(id) {
    if (!confirm('Are you sure you want to delete this catalog? Content will be moved to the default catalog.')) {
        return;
    }

    try {
        const response = await fetch(`/api/catalogs/${id}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            showAlert('Catalog deleted successfully!', 'success');
            loadCatalogs();
        } else {
            const data = await response.json();
            showAlert(data.error || 'Failed to delete catalog', 'error');
        }
    } catch (error) {
        showAlert('Network error. Please try again.', 'error');
    }
}

// Delete Content
async function deleteContent(id, type) {
    if (!confirm(`Are you sure you want to delete this ${type}?`)) {
        return;
    }

    try {
        const endpoint = type === 'movie' ? '/api/movies' : '/api/series';
        const response = await fetch(`${endpoint}/${id}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            showAlert('Deleted successfully!', 'success');
            if (type === 'movie') {
                loadMovies();
            } else {
                loadSeries();
            }
            loadDashboard();
        } else {
            showAlert('Failed to delete', 'error');
        }
    } catch (error) {
        showAlert('Network error. Please try again.', 'error');
    }
}

// Modal Functions
function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

// Close modal on background click
document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('active');
        }
    });
});

// Copy Addon URL
function copyAddonUrl() {
    const input = document.getElementById('addon-url');
    input.select();
    document.execCommand('copy');
    showAlert('Addon URL copied to clipboard!', 'success');
}

// Alert Function
function showAlert(message, type) {
    const alertContainer = document.getElementById('alert-container');
    alertContainer.innerHTML = `
        <div class="alert alert-${type}">
            ${message}
        </div>
    `;

    setTimeout(() => {
        alertContainer.innerHTML = '';
    }, 5000);
}

// ============================================
// BULK DELETE FUNCTIONALITY
// ============================================

// Bulk Import
async function openBulkImportModal() {
    try {
        const response = await fetch('/api/catalogs');
        const catalogs = await response.json();
        const select = document.getElementById('bulk-catalog');

        // Filter by access for uploaders
        let availableCatalogs = catalogs;
        if (currentUser && currentUser.role === 'uploader') {
            availableCatalogs = catalogs.filter(c => currentUser.catalogAccess.includes(c.id));
        }

        select.innerHTML = `
            <option value="">Auto-detect (Movie/Series default)</option>
            ${availableCatalogs.map(c => `<option value="${c.id}">${c.name} (${c.type})</option>`).join('')}
        `;

        document.getElementById('bulk-import-modal').classList.add('active');
    } catch (error) {
        console.error('Failed to load catalogs:', error);
    }
}

// Toggle select all checkboxes
function toggleSelectAllMovies(checkbox) {
    const checkboxes = document.querySelectorAll('.movie-checkbox');
    checkboxes.forEach(cb => cb.checked = checkbox.checked);
    updateBulkDeleteButton('movies');
}

function toggleSelectAllSeries(checkbox) {
    const checkboxes = document.querySelectorAll('.series-checkbox');
    checkboxes.forEach(cb => cb.checked = checkbox.checked);
    updateBulkDeleteButton('series');
}

// Update bulk delete button visibility
function updateBulkDeleteButton(type) {
    const checkboxes = document.querySelectorAll(`.${type}-checkbox:checked`);
    const button = document.getElementById(`bulk-delete-${type}-btn`);
    button.style.display = checkboxes.length > 0 ? 'block' : 'none';
}

// Bulk delete movies
async function bulkDeleteMovies() {
    const checkboxes = document.querySelectorAll('.movie-checkbox:checked');
    const ids = Array.from(checkboxes).map(cb => cb.value);

    if (ids.length === 0) {
        showAlert('No movies selected', 'warning');
        return;
    }

    if (!confirm(`Are you sure you want to delete ${ids.length} movie(s)?`)) {
        return;
    }

    try {
        const response = await fetch('/api/movies/bulk-delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids })
        });

        const data = await response.json();

        if (response.ok) {
            showAlert(data.message || `Deleted ${data.deletedCount} movie(s)`, 'success');
            document.getElementById('select-all-movies').checked = false;
            loadMovies(currentMoviePage);
            loadDashboard();
        } else {
            showAlert(data.error || 'Failed to delete movies', 'error');
        }
    } catch (error) {
        showAlert('Network error. Please try again.', 'error');
    }
}

// Bulk delete series
async function bulkDeleteSeries() {
    const checkboxes = document.querySelectorAll('.series-checkbox:checked');
    const ids = Array.from(checkboxes).map(cb => cb.value);

    if (ids.length === 0) {
        showAlert('No series selected', 'warning');
        return;
    }

    if (!confirm(`Are you sure you want to delete ${ids.length} series?`)) {
        return;
    }

    try {
        const response = await fetch('/api/series/bulk-delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids })
        });

        const data = await response.json();

        if (response.ok) {
            showAlert(data.message || `Deleted ${data.deletedCount} series`, 'success');
            document.getElementById('select-all-series').checked = false;
            loadSeries(currentSeriesPage);
            loadDashboard();
        } else {
            showAlert(data.error || 'Failed to delete series', 'error');
        }
    } catch (error) {
        showAlert('Network error. Please try again.', 'error');
    }
}

// ============================================
// PROVIDER MANAGEMENT
// ============================================

async function loadProviders() {
    try {
        const response = await fetch('/api/providers');
        const providers = await response.json();

        // Ensure providers is an array (handle legacy data)
        const providersList = Array.isArray(providers) ? providers : [];

        const tableHtml = providersList.map(provider => {
            const statusClass = provider.enabled ? 'status-active' : 'status-processing';
            const statusText = provider.enabled ? 'Active' : 'Disabled';
            const simCount = Math.floor(Math.random() * 50) + 1; // Simulated usage count

            return `
                <tr>
                    <td>
                        <div style="font-weight: bold;">${provider.name}</div>
                        <div style="font-size: 0.8rem; color: var(--gray);">ID: ${provider.id}</div>
                    </td>
                    <td><span class="status-badge ${statusClass}">${statusText}</span></td>
                    <td>${simCount} fetches/hr</td>
                    <td>
                        <button class="btn btn-secondary btn-sm" onclick="editProvider('${provider.id}')">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="deleteProvider('${provider.id}')">Delete</button>
                    </td>
                </tr>
            `;
        }).join('');

        const tableBody = document.getElementById('providers-table');
        if (tableBody) {
            if (providersList.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="4" style="text-align:center; padding: 2rem;">No providers configured. Click "Add Provider" to add one.</td></tr>';
            } else {
                tableBody.innerHTML = tableHtml;
            }
        }
    } catch (error) {
        console.error('Failed to load providers:', error);
        showAlert('Failed to load providers', 'error');
    }
}

window.openAddProviderModal = function () {
    document.getElementById('add-provider-form').reset();
    document.getElementById('add-provider-modal').classList.add('active');
}

// Add Provider Submit
const addProviderForm = document.getElementById('add-provider-form');
if (addProviderForm) {
    addProviderForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = document.getElementById('provider-name').value;
        const movieUrl = document.getElementById('provider-movie-url').value;
        const seriesUrl = document.getElementById('provider-series-url').value;

        try {
            const response = await fetch('/api/providers', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, movieUrl, seriesUrl })
            });

            const data = await response.json();
            if (response.ok) {
                showAlert('Provider added successfully!', 'success');
                closeModal('add-provider-modal');
                loadProviders();
            } else {
                showAlert(data.error || 'Failed to add provider', 'error');
            }
        } catch (error) {
            showAlert('Network error. Please try again.', 'error');
        }
    });
}

async function editProvider(id) {
    try {
        const response = await fetch('/api/providers');
        const providers = await response.json();
        const provider = providers.find(p => p.id === id);

        if (provider) {
            document.getElementById('edit-provider-id').value = id;
            document.getElementById('edit-provider-name').value = provider.name;
            document.getElementById('edit-provider-movie-url').value = provider.movieUrl || '';
            document.getElementById('edit-provider-series-url').value = provider.seriesUrl || '';
            document.getElementById('edit-provider-enabled').checked = provider.enabled !== false; // Default to true if undefined

            document.getElementById('edit-provider-modal').classList.add('active');
        }
    } catch (error) {
        showAlert('Failed to load provider details', 'error');
    }
}

// Edit Provider Submit
const editProviderForm = document.getElementById('edit-provider-form');
if (editProviderForm) {
    editProviderForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = document.getElementById('edit-provider-id').value;
        const name = document.getElementById('edit-provider-name').value;
        const movieUrl = document.getElementById('edit-provider-movie-url').value;
        const seriesUrl = document.getElementById('edit-provider-series-url').value;
        const enabled = document.getElementById('edit-provider-enabled').checked;

        try {
            const response = await fetch(`/api/providers/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, movieUrl, seriesUrl, enabled })
            });

            const data = await response.json();
            if (response.ok) {
                showAlert('Provider updated successfully!', 'success');
                closeModal('edit-provider-modal');
                loadProviders();
            } else {
                showAlert(data.error || 'Failed to update provider', 'error');
            }
        } catch (error) {
            showAlert('Network error. Please try again.', 'error');
        }
    });
}

async function deleteProvider(id) {
    if (!confirm('Are you sure you want to delete this provider?')) {
        return;
    }

    try {
        const response = await fetch(`/api/providers/${id}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            showAlert('Provider deleted successfully!', 'success');
            loadProviders();
        } else {
            showAlert('Failed to delete provider', 'error');
        }
    } catch (error) {
        showAlert('Network error. Please try again.', 'error');
    }
}
