# Data Storage System - Complete Guide

## 📦 Storage Location

Your movies and series data is now stored **persistently** in JSON files:

```
Addon1/
└── data/
    ├── movies.json    # All your movies
    └── series.json    # All your series
```

## ✅ Persistent Storage (NEW!)

### Before (In-Memory):
- ❌ Data lost when server restarts
- ❌ No persistence
- ❌ Not suitable for production

### After (File-Based):
- ✅ Data saved automatically to files
- ✅ Survives server restarts
- ✅ Easy to backup
- ✅ Human-readable JSON format

## 🔄 How It Works

### Automatic Saving
Every time you:
- **Add** a movie/series → Automatically saved to file
- **Edit** a movie/series → Automatically saved to file
- **Delete** a movie/series → Automatically saved to file

### Automatic Loading
When the server starts:
- Loads all movies from `data/movies.json`
- Loads all series from `data/series.json`
- Shows count in console: `📚 Loaded X movies and Y series from storage`

## 📁 Data Format

### movies.json
```json
[
  {
    "id": "1733734567890",
    "externalId": "550",
    "source": "tmdb",
    "title": "Fight Club",
    "originalTitle": "Fight Club",
    "overview": "A ticking-time-bomb insomniac...",
    "poster": "https://image.tmdb.org/t/p/w500/pB8BM7pdSp6B6Ih7QZ4DrQ3PmJK.jpg",
    "backdrop": "https://image.tmdb.org/t/p/original/hZkgoQYus5vegHoetLkCJzb17zJ.jpg",
    "releaseDate": "1999-10-15",
    "rating": 8.4,
    "genres": ["Drama"],
    "runtime": 139,
    "cast": ["Edward Norton", "Brad Pitt", "Helena Bonham Carter"],
    "director": "David Fincher",
    "trailer": "BdJKm16Co6M",
    "seasons": 0,
    "episodes": 0,
    "addedAt": "2024-12-09T08:42:47.890Z"
  }
]
```

### series.json
```json
[
  {
    "id": "1733734678901",
    "externalId": "1399",
    "source": "tmdb",
    "title": "Game of Thrones",
    "originalTitle": "Game of Thrones",
    "overview": "Seven noble families fight...",
    "poster": "https://image.tmdb.org/t/p/w500/u3bZgnGQ9T01sWNhyveQz0wH0Hl.jpg",
    "backdrop": "https://image.tmdb.org/t/p/original/suopoADq0k8YZr4dQXcU6pToj6s.jpg",
    "releaseDate": "2011-04-17",
    "rating": 8.4,
    "genres": ["Sci-Fi & Fantasy", "Drama", "Action & Adventure"],
    "runtime": 60,
    "cast": ["Emilia Clarke", "Peter Dinklage", "Kit Harington"],
    "director": "",
    "trailer": "KPLWWIOCOOQ",
    "seasons": 8,
    "episodes": 73,
    "addedAt": "2024-12-09T08:44:38.901Z"
  }
]
```

## 💾 Backup Your Data

### Manual Backup
Simply copy the `data` folder:
```bash
# Windows
xcopy data data_backup /E /I

# Or just copy the folder in File Explorer
```

### Restore from Backup
Replace the `data` folder with your backup:
```bash
# Stop the server first
Ctrl + C

# Replace the data folder
# Then restart
npm start
```

## 🔧 Advanced Operations

### View Your Data
Open the JSON files in any text editor:
- `data/movies.json`
- `data/series.json`

### Export Data
The files are already in JSON format - just copy them!

### Import Data
1. Stop the server
2. Replace `movies.json` or `series.json` with your file
3. Restart the server

### Clear All Data
```bash
# Stop the server
Ctrl + C

# Delete the data files
del data\movies.json
del data\series.json

# Restart - will create empty files
npm start
```

## 📊 Storage Statistics

### File Size Estimates
- **Empty**: ~2 bytes per file (`[]`)
- **Per Movie**: ~500-1000 bytes (0.5-1 KB)
- **Per Series**: ~600-1200 bytes (0.6-1.2 KB)
- **100 Movies**: ~50-100 KB
- **1000 Movies**: ~500 KB - 1 MB

Very efficient! Even with thousands of items, files stay small.

## 🔐 Data Security

### Current Setup
- Files stored locally on your machine
- Only accessible by the server
- Not encrypted (plain JSON)

### For Production
Consider:
- Encrypting sensitive data
- Regular automated backups
- Database migration (MongoDB, PostgreSQL)
- Cloud storage backup

## 🚀 Migration Path

### Current: JSON Files
✅ Perfect for:
- Development
- Small to medium libraries (< 10,000 items)
- Single server deployment
- Easy backup and restore

### Future: Database
Consider migrating to a database when:
- You have > 10,000 items
- Need multi-user access
- Want advanced search/filtering
- Need better performance
- Require data relationships

### Easy Database Migration
The current structure makes it easy to migrate:

```javascript
// MongoDB example
const Movie = require('./models/Movie');

// Instead of:
movies.push(movie);
saveData(MOVIES_FILE, movies);

// You would do:
await Movie.create(movie);
```

## 📝 Data Fields Explained

### Common Fields (Movies & Series)
- `id`: Unique internal ID (timestamp-based)
- `externalId`: TMDB or IMDB ID
- `source`: "tmdb" or "imdb"
- `title`: Display title
- `originalTitle`: Original language title
- `overview`: Description/plot
- `poster`: Poster image URL
- `backdrop`: Background image URL
- `releaseDate`: Release/air date
- `rating`: Average rating (0-10)
- `genres`: Array of genre names
- `runtime`: Duration in minutes
- `cast`: Array of actor names
- `director`: Director name
- `trailer`: YouTube video ID
- `addedAt`: When added to your library

### Series-Specific Fields
- `seasons`: Number of seasons
- `episodes`: Total episode count

### Auto-Generated Fields
- `id`: Created automatically
- `addedAt`: Timestamp when added
- `updatedAt`: Timestamp when edited (if edited)

## 🛠️ Troubleshooting

### "Error loading data from file"
- Check if `data` folder exists
- Verify JSON files are valid
- Look for syntax errors in JSON

### Data not persisting
- Check file permissions
- Ensure disk space available
- Verify server has write access

### Corrupted JSON file
1. Stop the server
2. Open the JSON file
3. Fix syntax errors (use a JSON validator)
4. Or restore from backup
5. Restart server

### Lost data after restart
- Check if files exist in `data/` folder
- Look for error messages in console
- Verify file paths are correct

## 📈 Performance

### Read Performance
- **Fast**: Files loaded once on startup
- **In-Memory**: All operations use RAM
- **No Disk I/O**: During normal operation

### Write Performance
- **Instant**: Saves happen in background
- **Synchronous**: Ensures data is written
- **Small Files**: Quick write operations

### Scalability
- **< 1,000 items**: Excellent performance
- **1,000 - 10,000 items**: Good performance
- **> 10,000 items**: Consider database

## 🎯 Best Practices

1. **Regular Backups**
   - Copy `data` folder weekly
   - Store backups in different location
   - Test restore process

2. **Monitor File Size**
   - Check file sizes periodically
   - Consider cleanup if too large
   - Archive old data if needed

3. **Validate Data**
   - Occasionally check JSON validity
   - Remove duplicate entries
   - Clean up orphaned data

4. **Version Control**
   - `data/` is in `.gitignore`
   - Don't commit personal data
   - Keep backups separately

## 📚 Summary

### Storage System Features
✅ **Automatic persistence** - No manual saving needed
✅ **Survives restarts** - Data always preserved
✅ **Easy backup** - Just copy the folder
✅ **Human-readable** - JSON format
✅ **Fast performance** - In-memory operations
✅ **Simple migration** - Easy to upgrade to database

### File Locations
- **Movies**: `c:\Users\1042340\Downloads\Addon1\data\movies.json`
- **Series**: `c:\Users\1042340\Downloads\Addon1\data\series.json`

### When to Restart
You **don't need to restart** the server for the storage changes to work. However, if you want to see the "Loaded X movies" message, restart with:
```bash
Ctrl + C
npm start
```

---

**Your data is now safe and persistent! 🎉**

Every movie and series you add will be automatically saved and will survive server restarts.
