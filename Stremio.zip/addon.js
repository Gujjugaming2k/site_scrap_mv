const { addonBuilder, serveHTTP } = require('stremio-addon-sdk');
const express = require('express');
const fs = require('fs');
const path = require('path');
const axios = require('axios');


// Data file paths
const DATA_DIR = path.join(__dirname, 'data');
const MOVIES_FILE = path.join(DATA_DIR, 'movies.json');
const SERIES_FILE = path.join(DATA_DIR, 'series.json');
const CATALOGS_FILE = path.join(DATA_DIR, 'catalogs.json');

// Helper function to load data from file
function loadData(filePath) {
    try {
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(data);
        }
        return [];
    } catch (error) {
        console.error(`Error loading data from ${filePath}:`, error.message);
        return [];
    }
}

// Function to get current movies and series
function getMovies() {
    return loadData(MOVIES_FILE);
}

function getSeries() {
    return loadData(SERIES_FILE);
}

function getCatalogs() {
    return loadData(CATALOGS_FILE);
}

// Build manifest with dynamic catalogs
function buildManifest() {
    const catalogs = getCatalogs();
    // Use timestamp-based version to force Stremio to always check for updates
    // This ensures new catalogs appear without reinstalling
    const timestamp = Date.now();
    const version = `1.${Math.floor(timestamp / 1000000)}.${timestamp % 1000000}`;

    return {
        id: 'com.vflixprime.addon',
        version: version,
        name: 'VFlixPrime',
        description: 'Stream movies and series from VFlixPrime',
        resources: ['catalog', 'meta', 'stream'],
        types: ['movie', 'series'],
        catalogs: catalogs.map(c => ({
            type: c.type,
            id: c.id,
            name: c.name
        })),
        idPrefixes: ['vflix', 'tt']
    };
}

// Get current manifest
const manifest = buildManifest();
const builder = new addonBuilder(manifest);


// Catalog handler
builder.defineCatalogHandler(({ type, id }) => {
    const catalogs = getCatalogs();
    const catalog = catalogs.find(c => c.id === id);

    if (!catalog || catalog.type !== type) {
        return Promise.resolve({ metas: [] });
    }

    if (type === 'movie') {
        const movies = getMovies();
        const filteredMovies = movies.filter(m => (m.catalogId || 'vflixprime-movies') === id);
        return Promise.resolve({
            metas: filteredMovies.reverse().map(movie => ({ // Reverse to show latest first
                id: movie.imdbId || movie.externalId || `vflix:${movie.id}`, // Prefer IMDB ID
                type: 'movie',
                name: movie.title,
                poster: movie.poster,
                background: movie.backdrop,
                description: movie.overview,
                releaseInfo: movie.releaseDate,
                imdbRating: movie.rating
            }))
        });
    }

    if (type === 'series') {
        const series = getSeries();
        const filteredSeries = series.filter(s => (s.catalogId || 'vflixprime-series') === id);
        return Promise.resolve({
            metas: filteredSeries.reverse().map(serie => ({ // Reverse to show latest first
                id: serie.imdbId || serie.externalId || `vflix:${serie.id}`, // Prefer IMDB ID
                type: 'series',
                name: serie.title,
                poster: serie.poster,
                background: serie.backdrop,
                description: serie.overview,
                releaseInfo: serie.releaseDate,
                imdbRating: serie.rating
            }))
        });
    }

    return Promise.resolve({ metas: [] });
});

// Meta handler
builder.defineMetaHandler(({ type, id }) => {
    const vflixId = id.replace('vflix:', '');

    if (type === 'movie') {
        const movies = getMovies();
        const movie = movies.find(m => m.id === vflixId);
        if (movie) {
            return Promise.resolve({
                meta: {
                    id: `vflix:${movie.id}`,
                    type: 'movie',
                    name: movie.title,
                    poster: movie.poster,
                    background: movie.backdrop,
                    description: movie.overview,
                    releaseInfo: movie.releaseDate,
                    imdbRating: movie.rating,
                    runtime: movie.runtime ? `${movie.runtime} min` : '',
                    cast: movie.cast || [],
                    director: movie.director || '',
                    genre: movie.genres || [],
                    trailerStreams: movie.trailer ? [{
                        title: 'Trailer',
                        ytId: movie.trailer
                    }] : []
                }
            });
        }
    }

    if (type === 'series') {
        const series = getSeries();
        const serie = series.find(s => s.id === vflixId);
        if (serie) {
            return Promise.resolve({
                meta: {
                    id: `vflix:${serie.id}`,
                    type: 'series',
                    name: serie.title,
                    poster: serie.poster,
                    background: serie.backdrop,
                    description: serie.overview,
                    releaseInfo: serie.releaseDate,
                    imdbRating: serie.rating,
                    cast: serie.cast || [],
                    director: serie.director || '',
                    genre: serie.genres || [],
                    trailerStreams: serie.trailer ? [{
                        title: 'Trailer',
                        ytId: serie.trailer
                    }] : []
                }
            });
        }
    }

    return Promise.resolve({ meta: null });
});

// Stream handler
builder.defineStreamHandler(({ type, id }) => {
    const vflixId = id.replace('vflix:', '');

    // In production, you would return actual stream URLs
    // This is a placeholder implementation
    return Promise.resolve({
        streams: [
            {
                title: 'VFlixPrime Stream',
                url: `https://your-stream-server.com/stream/${vflixId}`,
                behaviorHints: {
                    notWebReady: true
                }
            }
        ]
    });
});

// Export for use in main server
const router = express.Router();

router.get('/manifest.json', (req, res) => {
    // Rebuild manifest to get latest catalogs
    res.json(buildManifest());
});

router.get('/catalog/:type/:id.json', (req, res) => {
    const { type, id } = req.params;
    const catalogs = getCatalogs();
    const catalog = catalogs.find(c => c.id === id);

    if (!catalog || catalog.type !== type) {
        return res.json({ metas: [] });
    }

    if (type === 'movie') {
        const movies = getMovies();
        const filteredMovies = movies.filter(m => (m.catalogId || 'vflixprime-movies') === id);
        res.json({
            metas: filteredMovies.reverse().map(movie => ({ // Reverse to show latest first
                id: movie.imdbId || movie.externalId || `vflix:${movie.id}`, // Prefer IMDB ID
                type: 'movie',
                name: movie.title,
                poster: movie.poster,
                background: movie.backdrop,
                description: movie.overview,
                releaseInfo: movie.releaseDate,
                imdbRating: movie.rating
            }))
        });
    } else if (type === 'series') {
        const series = getSeries();
        const filteredSeries = series.filter(s => (s.catalogId || 'vflixprime-series') === id);
        console.log(`📋 Series catalog requested - Found ${filteredSeries.length} series in ${id}`);
        res.json({
            metas: filteredSeries.reverse().map(serie => ({ // Reverse to show latest first
                id: serie.imdbId || serie.externalId || `vflix:${serie.id}`, // Prefer IMDB ID
                type: 'series',
                name: serie.title,
                poster: serie.poster,
                background: serie.backdrop,
                description: serie.overview,
                releaseInfo: serie.releaseDate,
                imdbRating: serie.rating
            }))
        });
    } else {
        res.json({ metas: [] });
    }
});

router.get('/meta/:type/:id.json', (req, res) => {
    const { type, id } = req.params;
    console.log(`📺 Meta request - Type: ${type}, ID: ${id}`);

    const vflixId = id.replace('vflix:', '').replace('vflix%3A', '');

    if (type === 'movie') {
        const movies = getMovies();
        const movie = movies.find(m => m.id === vflixId);
        if (movie) {
            res.json({
                meta: {
                    id: `vflix:${movie.id}`,
                    type: 'movie',
                    name: movie.title,
                    poster: movie.poster,
                    background: movie.backdrop,
                    description: movie.overview,
                    releaseInfo: movie.releaseDate,
                    imdbRating: movie.rating,
                    runtime: movie.runtime ? `${movie.runtime} min` : '',
                    cast: movie.cast || [],
                    director: movie.director || '',
                    genre: movie.genres || [],
                    trailerStreams: movie.trailer ? [{
                        title: 'Trailer',
                        ytId: movie.trailer
                    }] : []
                }
            });
        } else {
            res.status(404).json({ meta: null });
        }
    } else if (type === 'series') {
        const series = getSeries();
        // Try to find by IMDB ID first, then fall back to internal ID
        const serie = series.find(s => s.imdbId === id || s.id === vflixId || `vflix:${s.id}` === id);
        if (serie) {
            // Generate videos array for seasons and episodes
            const videos = [];
            const seriesId = serie.imdbId || `vflix:${serie.id}`; // Use IMDB ID if available

            // Use detailed season data if available, otherwise generate generic episodes
            if (serie.seasonsData && serie.seasonsData.length > 0) {
                // Use actual episode data from TMDB
                serie.seasonsData.forEach(season => {
                    season.episodes.forEach(episode => {
                        videos.push({
                            id: `${seriesId}:${season.number}:${episode.number}`,
                            title: episode.name || `Episode ${episode.number}`,
                            season: season.number,
                            episode: episode.number,
                            released: episode.airDate || new Date().toISOString(),
                            overview: episode.overview,
                            thumbnail: episode.stillPath
                        });
                    });
                });
            } else {
                // Fallback: Generate generic episodes
                const numSeasons = serie.seasons || 1;
                for (let season = 1; season <= numSeasons; season++) {
                    const episodesPerSeason = serie.episodes ? Math.ceil(serie.episodes / numSeasons) : 10;
                    for (let episode = 1; episode <= episodesPerSeason; episode++) {
                        videos.push({
                            id: `${seriesId}:${season}:${episode}`,
                            title: `Episode ${episode}`,
                            season: season,
                            episode: episode,
                            released: new Date().toISOString()
                        });
                    }
                }
            }

            console.log(`✅ Series meta found - ${serie.title} (${seriesId}) with ${videos.length} episodes`);

            res.json({
                meta: {
                    id: seriesId,
                    type: 'series',
                    name: serie.title,
                    poster: serie.poster,
                    background: serie.backdrop,
                    description: serie.overview,
                    releaseInfo: serie.releaseDate,
                    imdbRating: serie.rating,
                    cast: serie.cast || [],
                    director: serie.director || '',
                    genre: serie.genres || [],
                    videos: videos,
                    trailerStreams: serie.trailer ? [{
                        title: 'Trailer',
                        ytId: serie.trailer
                    }] : []
                }
            });
        } else {
            res.status(404).json({ meta: null });
        }
    } else {
        res.status(404).json({ meta: null });
    }
});

router.get('/stream/:type/:id.json', async (req, res) => {
    const { type, id } = req.params;
    let streamId = id;

    // Check for custom streams with IMDB/TMDB IDs first
    if (type === 'movie' && (id.startsWith('tt') || !isNaN(id))) {
        const movies = getMovies();
        const movie = movies.find(m => m.imdbId === id || m.externalId == id || m.tmdbId == id);
        if (movie && movie.customStream && movie.customStream.url) {
            const stream = {
                url: movie.customStream.url,
                title: movie.customStream.title || '1080p'
            };

            if (movie.customStream.referer || movie.customStream.userAgent) {
                stream.behaviorHints = {
                    proxyHeaders: {
                        request: {}
                    }
                };
                if (movie.customStream.referer) {
                    stream.behaviorHints.proxyHeaders.request.Referer = movie.customStream.referer;
                }
                if (movie.customStream.userAgent) {
                    stream.behaviorHints.proxyHeaders.request['User-Agent'] = movie.customStream.userAgent;
                }
            }

            return res.json({ streams: [stream] });
        }
    }

    // Handle vflix: IDs by resolving to external ID
    if (id.startsWith('vflix:')) {
        const vflixId = id.replace('vflix:', '');
        if (type === 'movie') {
            const movies = getMovies();
            const movie = movies.find(m => m.id === vflixId);
            if (movie) {
                // Check if movie has custom stream
                if (movie.customStream && movie.customStream.url) {
                    const stream = {
                        url: movie.customStream.url,
                        title: movie.customStream.title || '1080p'
                    };

                    // Add proxy headers if provided
                    if (movie.customStream.referer || movie.customStream.userAgent) {
                        stream.behaviorHints = {
                            proxyHeaders: {
                                request: {}
                            }
                        };
                        if (movie.customStream.referer) {
                            stream.behaviorHints.proxyHeaders.request.Referer = movie.customStream.referer;
                        }
                        if (movie.customStream.userAgent) {
                            stream.behaviorHints.proxyHeaders.request['User-Agent'] = movie.customStream.userAgent;
                        }
                    }

                    return res.json({ streams: [stream] });
                }

                // Use external ID for upstream fetch
                if (movie.externalId) {
                    streamId = movie.externalId;
                }
            }
        } else if (type === 'series') {
            const series = getSeries();
            // ID format: vflix:internalId:season:episode
            const parts = vflixId.split(':');
            const internalId = parts[0];
            const season = parts[1];
            const episode = parts[2];

            const serie = series.find(s => s.id === internalId);
            if (serie) {
                // Check if series has custom stream
                if (serie.customStream && serie.customStream.url) {
                    const stream = {
                        url: serie.customStream.url,
                        title: serie.customStream.title || '1080p'
                    };

                    // Add proxy headers if provided
                    if (serie.customStream.referer || serie.customStream.userAgent) {
                        stream.behaviorHints = {
                            proxyHeaders: {
                                request: {}
                            }
                        };
                        if (serie.customStream.referer) {
                            stream.behaviorHints.proxyHeaders.request.Referer = serie.customStream.referer;
                        }
                        if (serie.customStream.userAgent) {
                            stream.behaviorHints.proxyHeaders.request['User-Agent'] = serie.customStream.userAgent;
                        }
                    }

                    return res.json({ streams: [stream] });
                }

                // Use external ID for upstream fetch
                if (serie.externalId) {
                    // Reconstruct ID with external ID: externalId:season:episode
                    streamId = season && episode
                        ? `${serie.externalId}:${season}:${episode}`
                        : serie.externalId;
                }
            }
        }
    }

    // Construct upstream URL
    const url = `https://webstreamr.hayd.uk/stream/${type}/${streamId}.json`;

    try {
        console.log(`Fetching streams from: ${url}`);
        const response = await axios.get(url);
        const data = response.data;

        if (data.streams) {
            data.streams.forEach(stream => {
                // Replace "WebStreamr | Hayduk" with "VFlixPrime"
                if (stream.name) {
                    stream.name = stream.name.replace('WebStreamr | Hayduk', 'VFlixPrime')
                        .replace('WebStreamr', 'VFlixPrime');
                }
            });
        }

        res.json(data);
    } catch (error) {
        console.error(`Error fetching streams from ${url}:`, error.message);
        res.json({ streams: [] });
    }
});

module.exports = router;
