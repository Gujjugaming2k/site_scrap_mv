const { addonBuilder, serveHTTP } = require('stremio-addon-sdk');
const express = require('express');
const fs = require('fs');
const path = require('path');
const axios = require('axios');


// Data file paths
const DATA_DIR = path.join(__dirname, 'data');
const MOVIES_FILE = path.join(DATA_DIR, 'movies.json');
const SERIES_FILE = path.join(DATA_DIR, 'series.json');
const CATALOGS_FILE = path.join(DATA_DIR, 'catalogs.json');
const PROVIDERS_FILE = path.join(DATA_DIR, 'providers.json');

// Helper function to load data from file
function loadData(filePath) {
    try {
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(data);
        }
        return [];
    } catch (error) {
        console.error(`Error loading data from ${filePath}:`, error.message);
        return [];
    }
}

// Function to get current movies and series
function getMovies() {
    return loadData(MOVIES_FILE);
}

function getSeries() {
    return loadData(SERIES_FILE);
}

function getCatalogs() {
    return loadData(CATALOGS_FILE);
}

function getProviders() {
    return loadData(PROVIDERS_FILE);
}

// Build manifest with dynamic catalogs
function buildManifest() {
    const catalogs = getCatalogs();
    // Use timestamp-based version to force Stremio to always check for updates
    // Use modification time of catalogs.json so version only changes when catalogs change
    let timestamp = Date.now();
    try {
        if (fs.existsSync(CATALOGS_FILE)) {
            timestamp = fs.statSync(CATALOGS_FILE).mtimeMs;
        }
    } catch (e) {
        console.error('Error getting catalog mtime:', e);
    }
    const version = `1.${Math.floor(timestamp / 1000000)}.${Math.floor(timestamp % 1000000)}`;

    return {
        id: 'com.vflixprime.addon',
        version: version,
        name: 'VFlixPrime',
        description: 'Stream movies and series from VFlixPrime',
        resources: ['catalog', 'meta', 'stream'],
        types: ['movie', 'series'],
        catalogs: catalogs.map(c => ({
            type: c.type,
            id: c.id,
            name: c.name
        })),
        idPrefixes: ['vflix', 'tt'],
        behaviorHints: {
            configurable: true
        }
    };
}

// Get current manifest
const manifest = buildManifest();
const builder = new addonBuilder(manifest);


// Catalog handler
builder.defineCatalogHandler(async ({ type, id }) => {
    const catalogs = getCatalogs();
    const catalog = catalogs.find(c => c.id === id);

    if (!catalog || catalog.type !== type) {
        return { metas: [] };
    }

    // Initialize metas array
    let metas = [];

    // 1. Fetch external metas if URL exists
    if (catalog.externalMetaUrl) {
        try {
            console.log(`🌐 Fetching external catalog from: ${catalog.externalMetaUrl}`);
            const response = await axios.get(catalog.externalMetaUrl);
            const data = response.data;

            if (Array.isArray(data)) {
                metas = [...metas, ...data];
            } else if (data.metas && Array.isArray(data.metas)) {
                metas = [...metas, ...data.metas];
            }
        } catch (error) {
            console.error(`Error fetching external catalog from ${catalog.externalMetaUrl}:`, error.message);
        }
    }

    // 2. Fetch local metas
    if (type === 'movie') {
        const movies = getMovies();
        const filteredMovies = movies.filter(m => (m.catalogId || 'vflixprime-movies') === id);
        const localMetas = filteredMovies.reverse().map(movie => ({
            id: movie.imdbId || movie.externalId || `vflix:${movie.id}`,
            type: 'movie',
            name: movie.title,
            poster: movie.poster,
            background: movie.backdrop,
            description: movie.overview,
            releaseInfo: movie.releaseDate,
            imdbRating: movie.rating
        }));
        metas = [...localMetas, ...metas]; // Local first
    } else if (type === 'series') {
        const series = getSeries();
        const filteredSeries = series.filter(s => (s.catalogId || 'vflixprime-series') === id);
        const localMetas = filteredSeries.reverse().map(serie => ({
            id: serie.imdbId || serie.externalId || `vflix:${serie.id}`,
            type: 'series',
            name: serie.title,
            poster: serie.poster,
            background: serie.backdrop,
            description: serie.overview,
            releaseInfo: serie.releaseDate,
            imdbRating: serie.rating
        }));
        metas = [...localMetas, ...metas]; // Local first
    }

    // Deduplicate by ID
    const uniqueMetas = Array.from(new Map(metas.map(item => [item.id, item])).values());

    return { metas: uniqueMetas };
});

// Meta handler
builder.defineMetaHandler(({ type, id }) => {
    const vflixId = id.replace('vflix:', '');

    if (type === 'movie') {
        const movies = getMovies();
        const movie = movies.find(m => m.id === vflixId);
        if (movie) {
            return Promise.resolve({
                meta: {
                    id: `vflix:${movie.id}`,
                    type: 'movie',
                    name: movie.title,
                    poster: movie.poster,
                    background: movie.backdrop,
                    description: movie.overview,
                    releaseInfo: movie.releaseDate,
                    imdbRating: movie.rating,
                    runtime: movie.runtime ? `${movie.runtime} min` : '',
                    cast: movie.cast || [],
                    director: movie.director || '',
                    genre: movie.genres || [],
                    trailerStreams: movie.trailer ? [{
                        title: 'Trailer',
                        ytId: movie.trailer
                    }] : []
                }
            });
        }
    }

    if (type === 'series') {
        const series = getSeries();
        const serie = series.find(s => s.id === vflixId);
        if (serie) {
            return Promise.resolve({
                meta: {
                    id: `vflix:${serie.id}`,
                    type: 'series',
                    name: serie.title,
                    poster: serie.poster,
                    background: serie.backdrop,
                    description: serie.overview,
                    releaseInfo: serie.releaseDate,
                    imdbRating: serie.rating,
                    cast: serie.cast || [],
                    director: serie.director || '',
                    genre: serie.genres || [],
                    trailerStreams: serie.trailer ? [{
                        title: 'Trailer',
                        ytId: serie.trailer
                    }] : []
                }
            });
        }
    }

    return Promise.resolve({ meta: null });
});

// Stream handler
// Stream handler
builder.defineStreamHandler(async ({ type, id }) => {
    const vflixId = id.replace('vflix:', '');
    let streams = [];

    // 1. Get enabled providers
    const providers = getProviders().filter(p => p.enabled);

    // 2. Prepare fetch promises
    const fetchPromises = providers.map(async (provider) => {
        let url = type === 'movie' ? provider.movieUrl : provider.seriesUrl;
        if (!url) return null;

        // Replace placeholders
        if (type === 'movie') {
            url = url.replace('{{id}}', vflixId);
        } else if (type === 'series') {
            // ID format: id:season:episode
            const parts = vflixId.split(':');
            const [seriesId, season, episode] = parts;
            url = url.replace('{{id}}', seriesId)
                .replace('{{season}}', season)
                .replace('{{episode}}', episode);
        }

        try {
            // 10s timeout
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 10000);

            console.log(`🔌 Fetching from ${provider.name}: ${url}`);
            const response = await axios.get(url, { signal: controller.signal });
            clearTimeout(timeoutId);

            const data = response.data;
            if (data.streams && Array.isArray(data.streams)) {
                // Add provider name to streams
                return data.streams.map(stream => ({
                    ...stream,
                    // name: `[${provider.name}] ${stream.title || stream.name || ''}` // Original logic (commented out)
                    // Keep original stream names
                }));
            }
        } catch (error) {
            console.error(`❌ Error fetching from ${provider.name}:`, error.message);
        }
        return [];
    });

    // 3. Execute in parallel
    const results = await Promise.allSettled(fetchPromises);

    // 4. Merge results
    results.forEach(result => {
        if (result.status === 'fulfilled' && result.value) {
            streams = [...streams, ...result.value];
        }
    });

    // 5. Add local streams (placeholder logic preserved/modified)
    // If you want to keep local streams as well, keep logic here. 
    // For now assuming providers replace the hardcoded "placeholder" logic, 
    // but the user said "show in VFlixPrime server which we added", implying we aggregate.

    return { streams };
});

// Export for use in main server
const router = express.Router();

router.get('/manifest.json', (req, res) => {
    // Rebuild manifest to get latest catalogs
    const manifest = buildManifest();

    // Add dynamic logo URL
    const protocol = req.headers['x-forwarded-proto'] || req.protocol;
    const host = req.headers['x-forwarded-host'] || req.get('host');
    manifest.logo = `${protocol}://${host}/img/logo.jpg`;

    res.json(manifest);
});

router.get('/catalog/:type/:id.json', async (req, res) => {
    const { type, id } = req.params;
    const catalogs = getCatalogs();
    const catalog = catalogs.find(c => c.id === id);

    if (!catalog || catalog.type !== type) {
        return res.json({ metas: [] });
    }

    // Initialize metas array
    let metas = [];

    // 1. Fetch external metas if URL exists
    if (catalog.externalMetaUrl) {
        try {
            console.log(`🌐 Fetching external catalog from: ${catalog.externalMetaUrl}`);
            const response = await axios.get(catalog.externalMetaUrl);
            const data = response.data;

            if (Array.isArray(data)) {
                metas = [...metas, ...data];
            } else if (data.metas && Array.isArray(data.metas)) {
                metas = [...metas, ...data.metas];
            }
        } catch (error) {
            console.error(`Error fetching external catalog from ${catalog.externalMetaUrl}:`, error.message);
        }
    }

    // 2. Fetch local metas
    if (type === 'movie') {
        const movies = getMovies();
        const filteredMovies = movies.filter(m => (m.catalogId || 'vflixprime-movies') === id);
        const localMetas = filteredMovies.reverse().map(movie => ({
            id: movie.imdbId || movie.externalId || `vflix:${movie.id}`,
            type: 'movie',
            name: movie.title,
            poster: movie.poster,
            background: movie.backdrop,
            description: movie.overview,
            releaseInfo: movie.releaseDate,
            imdbRating: movie.rating
        }));
        metas = [...localMetas, ...metas];
    } else if (type === 'series') {
        const series = getSeries();
        const filteredSeries = series.filter(s => (s.catalogId || 'vflixprime-series') === id);
        const localMetas = filteredSeries.reverse().map(serie => ({
            id: serie.imdbId || serie.externalId || `vflix:${serie.id}`,
            type: 'series',
            name: serie.title,
            poster: serie.poster,
            background: serie.backdrop,
            description: serie.overview,
            releaseInfo: serie.releaseDate,
            imdbRating: serie.rating
        }));
        metas = [...localMetas, ...metas];
    }

    // Deduplicate by ID
    const uniqueMetas = Array.from(new Map(metas.map(item => [item.id, item])).values());

    res.json({ metas: uniqueMetas });
});

router.get('/meta/:type/:id.json', (req, res) => {
    const { type, id } = req.params;
    console.log(`📺 Meta request - Type: ${type}, ID: ${id}`);

    const vflixId = id.replace('vflix:', '').replace('vflix%3A', '');

    if (type === 'movie') {
        const movies = getMovies();
        const movie = movies.find(m => m.id === vflixId);
        if (movie) {
            res.json({
                meta: {
                    id: `vflix:${movie.id}`,
                    type: 'movie',
                    name: movie.title,
                    poster: movie.poster,
                    background: movie.backdrop,
                    description: movie.overview,
                    releaseInfo: movie.releaseDate,
                    imdbRating: movie.rating,
                    runtime: movie.runtime ? `${movie.runtime} min` : '',
                    cast: movie.cast || [],
                    director: movie.director || '',
                    genre: movie.genres || [],
                    trailerStreams: movie.trailer ? [{
                        title: 'Trailer',
                        ytId: movie.trailer
                    }] : []
                }
            });
        } else {
            res.status(404).json({ meta: null });
        }
    } else if (type === 'series') {
        const series = getSeries();
        // Try to find by IMDB ID first, then fall back to internal ID
        const serie = series.find(s => s.imdbId === id || s.id === vflixId || `vflix:${s.id}` === id);
        if (serie) {
            // Generate videos array for seasons and episodes
            const videos = [];
            const seriesId = serie.imdbId || `vflix:${serie.id}`; // Use IMDB ID if available

            // Use detailed season data if available, otherwise generate generic episodes
            if (serie.seasonsData && serie.seasonsData.length > 0) {
                // Use actual episode data from TMDB
                serie.seasonsData.forEach(season => {
                    season.episodes.forEach(episode => {
                        videos.push({
                            id: `${seriesId}:${season.number}:${episode.number}`,
                            title: episode.name || `Episode ${episode.number}`,
                            season: season.number,
                            episode: episode.number,
                            released: episode.airDate || new Date().toISOString(),
                            overview: episode.overview,
                            thumbnail: episode.stillPath
                        });
                    });
                });
            } else {
                // Fallback: Generate generic episodes
                const numSeasons = serie.seasons || 1;
                for (let season = 1; season <= numSeasons; season++) {
                    const episodesPerSeason = serie.episodes ? Math.ceil(serie.episodes / numSeasons) : 10;
                    for (let episode = 1; episode <= episodesPerSeason; episode++) {
                        videos.push({
                            id: `${seriesId}:${season}:${episode}`,
                            title: `Episode ${episode}`,
                            season: season,
                            episode: episode,
                            released: new Date().toISOString()
                        });
                    }
                }
            }

            console.log(`✅ Series meta found - ${serie.title} (${seriesId}) with ${videos.length} episodes`);

            res.json({
                meta: {
                    id: seriesId,
                    type: 'series',
                    name: serie.title,
                    poster: serie.poster,
                    background: serie.backdrop,
                    description: serie.overview,
                    releaseInfo: serie.releaseDate,
                    imdbRating: serie.rating,
                    cast: serie.cast || [],
                    director: serie.director || '',
                    genre: serie.genres || [],
                    videos: videos,
                    trailerStreams: serie.trailer ? [{
                        title: 'Trailer',
                        ytId: serie.trailer
                    }] : []
                }
            });
        } else {
            res.status(404).json({ meta: null });
        }
    } else {
        res.status(404).json({ meta: null });
    }
});

router.get('/stream/:type/:id.json', async (req, res) => {
    const { type, id } = req.params;
    let streams = [];
    const vflixId = id.replace('vflix:', '');

    // 1. Check for custom streams (Local)
    if (type === 'movie') {
        const movies = getMovies();
        // Try all ID types
        const movie = movies.find(m => m.id === vflixId || m.imdbId === id || m.externalId == id);

        if (movie && movie.customStream && movie.customStream.url) {
            const stream = {
                title: movie.customStream.title || 'VFlixPrime - 1080p',
                url: movie.customStream.url,
                behaviorHints: { notWebReady: true }
            };
            if (movie.customStream.referer || movie.customStream.userAgent) {
                stream.behaviorHints = stream.behaviorHints || {};
                stream.behaviorHints.proxyHeaders = { request: {} };
                if (movie.customStream.referer) stream.behaviorHints.proxyHeaders.request.Referer = movie.customStream.referer;
                if (movie.customStream.userAgent) stream.behaviorHints.proxyHeaders.request['User-Agent'] = movie.customStream.userAgent;
            }
            streams.push(stream);
        }
    } else if (type === 'series') {
        const series = getSeries();
        const parts = vflixId.split(':');
        const internalId = parts[0];

        // Try simple find first
        const serie = series.find(s => s.id === internalId || s.imdbId === internalId);

        if (serie && serie.customStream && serie.customStream.url) {
            const stream = {
                title: serie.customStream.title || 'VFlixPrime - 1080p',
                url: serie.customStream.url,
                behaviorHints: { notWebReady: true }
            };
            if (serie.customStream.referer || serie.customStream.userAgent) {
                stream.behaviorHints = stream.behaviorHints || {};
                stream.behaviorHints.proxyHeaders = { request: {} };
                if (serie.customStream.referer) stream.behaviorHints.proxyHeaders.request.Referer = serie.customStream.referer;
                if (serie.customStream.userAgent) stream.behaviorHints.proxyHeaders.request['User-Agent'] = serie.customStream.userAgent;
            }
            streams.push(stream);
        }
    }

    // 2. Fetch from Providers (Parallel)
    const providers = getProviders().filter(p => p.enabled);
    if (providers.length > 0) {
        const fetchPromises = providers.map(async (provider) => {
            let url = type === 'movie' ? provider.movieUrl : provider.seriesUrl;
            if (!url) return null;

            // Simple ID for providers (usually IMDB or TMDB)
            // If vflix: ID, we need to try to resolve to remote ID if possible, otherwise send vflix ID (which might fail)
            // But usually providers expect IMDB/TMDB.
            // Let's try to get a clean ID.
            let cleanId = id;
            if (id.startsWith('vflix:')) {
                // Try to resolve to external ID
                if (type === 'movie') {
                    const m = getMovies().find(m => m.id === vflixId);
                    if (m && (m.imdbId || m.externalId)) cleanId = m.imdbId || m.externalId;
                } else {
                    const parts = vflixId.split(':'); // id:season:episode
                    const s = getSeries().find(s => s.id === parts[0]);
                    if (s && (s.imdbId || s.externalId)) {
                        // Reconstruct: externalId:season:episode
                        cleanId = `${s.imdbId || s.externalId}:${parts[1]}:${parts[2]}`;
                    }
                }
            }

            // Replace templates
            if (type === 'movie') {
                url = url.replace('{{id}}', cleanId);
            } else if (type === 'series') {
                const parts = cleanId.split(':');
                if (parts.length >= 3) {
                    url = url.replace('{{id}}', parts[0])
                        .replace('{{season}}', parts[1])
                        .replace('{{episode}}', parts[2]);
                } else {
                    return null; // Invalid series ID format for template
                }
            }

            try {
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout

                console.log(`🔌 Fetching from ${provider.name}: ${url}`);
                const response = await axios.get(url, { signal: controller.signal });
                clearTimeout(timeoutId);

                const data = response.data;
                if (data.streams && Array.isArray(data.streams)) {
                    return data.streams.map(stream => ({
                        ...stream,
                        // name: `[${provider.name}] ${stream.title || stream.name || ''}` // Original logic (commented out)
                        // Keep original stream names
                    }));
                }
            } catch (error) {
                console.error(`❌ Error fetching from ${provider.name}:`, error.message);
            }
            return [];
        });

        const results = await Promise.allSettled(fetchPromises);
        results.forEach(result => {
            if (result.status === 'fulfilled' && result.value) {
                streams = [...streams, ...result.value];
            }
        });
    }

    res.json({ streams });
});

module.exports = router;
