const { serveHTTP } = require('stremio-addon-sdk');
const express = require('express');
const fs = require('fs');
const path = require('path');
const cache = require('./cache');
const axios = require('axios');
const analytics = require('./analytics');



const DATA_DIR = path.join(__dirname, 'data');
const MOVIES_FILE = path.join(DATA_DIR, 'movies.json');
const SERIES_FILE = path.join(DATA_DIR, 'series.json');
const CATALOGS_FILE = path.join(DATA_DIR, 'catalogs.json');
const PROVIDERS_FILE = path.join(DATA_DIR, 'providers.json');
const SETTINGS_PATH = path.join(DATA_DIR, 'settings.json');

function getSettings() {
    try {
        if (fs.existsSync(SETTINGS_PATH)) {
            return JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf8'));
        }
    } catch (e) { console.error("Error reading settings:", e); }
    return { masterTimeout: 8000, cacheDuration: 3600 };
}

// Helper function to load data from file
function loadData(filePath) {
    try {
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(data);
        }
        return [];
    } catch (error) {
        console.error(`Error loading data from ${filePath}:`, error.message);
        return [];
    }
}

// Function to get current movies and series
function getMovies() {
    return loadData(MOVIES_FILE);
}

function getSeries() {
    return loadData(SERIES_FILE);
}

function getCatalogs() {
    return loadData(CATALOGS_FILE);
}

function getProviders() {
    return loadData(PROVIDERS_FILE);
}

// Build manifest with dynamic catalogs
function buildManifest(username) {
    const catalogs = getCatalogs();
    // Use timestamp-based version to force Stremio to always check for updates
    let timestamp = Date.now();
    try {
        if (fs.existsSync(CATALOGS_FILE)) {
            timestamp = fs.statSync(CATALOGS_FILE).mtimeMs;
        }
    } catch (e) { }

    const version = `1.${Math.floor(timestamp / 1000000)}.${Math.floor(timestamp % 1000000)}`;

    // Unique ID per user/teaser to prevent caching issues in Stremio
    const suffix = username ? `.${username.toLowerCase().replace(/[^a-z0-9]/g, '')}` : '.teaser';
    const id = `com.vflixprime.addon${suffix}`;

    return {
        id: id,
        version: version,
        name: `VFlixPrime${username ? ` (${username})` : ' Teaser'}`,
        description: 'Stream movies and series from VFlixPrime',
        resources: ['catalog', 'meta', 'stream'],
        types: ['movie', 'series'],
        catalogs: catalogs.map(c => ({
            type: c.type,
            id: c.id,
            name: c.name
        })),
        idPrefixes: ['vflix', 'tt'],
        behaviorHints: {
            configurable: true
        }
    };
}

// Get current manifest
const manifest = buildManifest();
// Builder removed in favor of manual router



// Catalog handler
// Builder handlers removed - see router implementation below


// Stream handler
// Builder handlers removed as we are using manual router implementation
// (Logic ported to router.get('/stream/:type/:id.json'))

// Export for use in main server
const router = express.Router({ mergeParams: true });

// Helper to check if username is a valid streaming user
function isValidStreamingUser(username) {
    if (!username) return false;
    const users = loadData(path.join(DATA_DIR, 'users.json'));
    const user = users.find(u => u.username === username);
    return user && (user.role === 'streaming' || user.role === 'admin');
}

// Improved Static Stream
const STATIC_VIDEO_STREAM = {
    name: 'VFlixPrime',
    title: 'Adoon Update Required Join Telegram Group',
    url: 'https://github.com/Gujjugaming2k/hackerrank_test/raw/refs/heads/main/VFlixPrime.mp4',
    behaviorHints: {
        notWebReady: true,
        proxyHeaders: {
            "request": {
                "User-Agent": "Stremio"
            }
        }
    }
};

router.get('/manifest.json', (req, res) => {
    // Rebuild manifest to get latest catalogs and unique ID
    let { username } = req.params;
    if (username === 'manifest.json') username = null;

    const manifest = buildManifest(username);

    // Add dynamic logo URL
    const protocol = req.headers['x-forwarded-proto'] || req.protocol;
    const host = req.headers['x-forwarded-host'] || req.get('host');
    manifest.logo = `${protocol}://${host}/img/logo.jpg`;

    res.json(manifest);
});

router.get('/catalog/:type/:id.json', async (req, res) => {
    const { type, id } = req.params;
    const catalogs = getCatalogs();
    const catalog = catalogs.find(c => c.id === id);

    if (!catalog || catalog.type !== type) {
        return res.json({ metas: [] });
    }

    // Initialize metas array
    let metas = [];

    // 1. Fetch external metas if URL exists
    if (catalog.externalMetaUrl) {
        try {
            console.log(`🌐 Fetching external catalog from: ${catalog.externalMetaUrl}`);
            const response = await axios.get(catalog.externalMetaUrl);
            const data = response.data;

            if (Array.isArray(data)) {
                metas = [...metas, ...data];
            } else if (data.metas && Array.isArray(data.metas)) {
                metas = [...metas, ...data.metas];
            }
        } catch (error) {
            console.error(`Error fetching external catalog from ${catalog.externalMetaUrl}:`, error.message);
        }
    }

    // 2. Fetch local metas
    if (type === 'movie') {
        const movies = getMovies();
        const filteredMovies = movies.filter(m => (m.catalogId || 'vflixprime-movies') === id);
        const localMetas = filteredMovies.reverse().map(movie => ({
            id: movie.imdbId || movie.externalId || `vflix:${movie.id}`,
            type: 'movie',
            name: movie.title,
            poster: movie.poster,
            background: movie.backdrop,
            description: movie.overview,
            releaseInfo: movie.releaseDate,
            imdbRating: movie.rating
        }));
        metas = [...localMetas, ...metas];
    } else if (type === 'series') {
        const series = getSeries();
        const filteredSeries = series.filter(s => (s.catalogId || 'vflixprime-series') === id);
        const localMetas = filteredSeries.reverse().map(serie => ({
            id: serie.imdbId || serie.externalId || `vflix:${serie.id}`,
            type: 'series',
            name: serie.title,
            poster: serie.poster,
            background: serie.backdrop,
            description: serie.overview,
            releaseInfo: serie.releaseDate,
            imdbRating: serie.rating
        }));
        metas = [...localMetas, ...metas];
    }

    // Deduplicate by ID
    const uniqueMetas = Array.from(new Map(metas.map(item => [item.id, item])).values());

    res.json({ metas: uniqueMetas });
});

router.get('/meta/:type/:id.json', (req, res) => {
    const { type, id } = req.params;
    console.log(`📺 Meta request - Type: ${type}, ID: ${id}`);

    const vflixId = id.replace('vflix:', '').replace('vflix%3A', '');

    if (type === 'movie') {
        const movies = getMovies();
        const movie = movies.find(m => m.id === vflixId);
        if (movie) {
            res.json({
                meta: {
                    id: `vflix:${movie.id}`,
                    type: 'movie',
                    name: movie.title,
                    poster: movie.poster,
                    background: movie.backdrop,
                    description: movie.overview,
                    releaseInfo: movie.releaseDate,
                    imdbRating: movie.rating,
                    runtime: movie.runtime ? `${movie.runtime} min` : '',
                    cast: movie.cast || [],
                    director: movie.director || '',
                    genre: movie.genres || [],
                    trailerStreams: movie.trailer ? [{
                        title: 'Trailer',
                        ytId: movie.trailer
                    }] : []
                }
            });
        } else {
            res.status(404).json({ meta: null });
        }
    } else if (type === 'series') {
        const series = getSeries();
        // Try to find by IMDB ID first, then fall back to internal ID
        const serie = series.find(s => s.imdbId === id || s.id === vflixId || `vflix:${s.id}` === id);
        if (serie) {
            // Generate videos array for seasons and episodes
            const videos = [];
            const seriesId = serie.imdbId || `vflix:${serie.id}`; // Use IMDB ID if available

            // Use detailed season data if available, otherwise generate generic episodes
            if (serie.seasonsData && serie.seasonsData.length > 0) {
                // Use actual episode data from TMDB
                serie.seasonsData.forEach(season => {
                    season.episodes.forEach(episode => {
                        videos.push({
                            id: `${seriesId}:${season.number}:${episode.number}`,
                            title: episode.name || `Episode ${episode.number}`,
                            season: season.number,
                            episode: episode.number,
                            released: episode.airDate || new Date().toISOString(),
                            overview: episode.overview,
                            thumbnail: episode.stillPath
                        });
                    });
                });
            } else {
                // Fallback: Generate generic episodes
                const numSeasons = serie.seasons || 1;
                for (let season = 1; season <= numSeasons; season++) {
                    const episodesPerSeason = serie.episodes ? Math.ceil(serie.episodes / numSeasons) : 10;
                    for (let episode = 1; episode <= episodesPerSeason; episode++) {
                        videos.push({
                            id: `${seriesId}:${season}:${episode}`,
                            title: `Episode ${episode}`,
                            season: season,
                            episode: episode,
                            released: new Date().toISOString()
                        });
                    }
                }
            }

            console.log(`✅ Series meta found - ${serie.title} (${seriesId}) with ${videos.length} episodes`);

            res.json({
                meta: {
                    id: seriesId,
                    type: 'series',
                    name: serie.title,
                    poster: serie.poster,
                    background: serie.backdrop,
                    description: serie.overview,
                    releaseInfo: serie.releaseDate,
                    imdbRating: serie.rating,
                    cast: serie.cast || [],
                    director: serie.director || '',
                    genre: serie.genres || [],
                    videos: videos,
                    trailerStreams: serie.trailer ? [{
                        title: 'Trailer',
                        ytId: serie.trailer
                    }] : []
                }
            });
        } else {
            res.status(404).json({ meta: null });
        }
    } else {
        res.status(404).json({ meta: null });
    }
});

router.get('/stream/:type/:id.json', async (req, res) => {
    const { type, id } = req.params;
    const vflixId = id.replace('vflix:', '');

    // Track analytics (Async, don't block response)
    let { username } = req.params;

    // If username is one of the reserved keywords, it means it's a default path
    if (['stream', 'catalog', 'meta', 'manifest.json'].includes(username)) {
        username = null;
    }

    const isValidUser = isValidStreamingUser(username);

    try {
        let title = id; // Default to ID if title not found
        if (type === 'movie') {
            const movie = getMovies().find(m => m.id === vflixId || m.imdbId === id || m.externalId == id);
            if (movie) title = movie.title;
        } else {
            const parts = vflixId.split(':');
            const serie = getSeries().find(s => s.id === parts[0] || s.imdbId === parts[0]);
            if (serie) title = serie.title;
        }
        analytics.trackView(type, id, title, req, username);
    } catch (e) {
        console.error('Analytics error:', e);
    }

    // IF NOT VALID USER, SHOW STATIC VIDEO
    if (!isValidUser) {
        console.log(`⚠️ Invalid or missing username: ${username}. Showing static video.`);
        return res.json({ streams: [STATIC_VIDEO_STREAM] });
    }

    let streams = [];

    // 1. Fetch Local Custom Streams (Fast, Synchronous-ish)
    let localStreams = [];
    if (type === 'movie') {
        const movies = getMovies();
        const movie = movies.find(m => m.id === vflixId || m.imdbId === id || m.externalId == id);

        if (movie && movie.customStream && movie.customStream.url) {
            const stream = {
                title: movie.customStream.title || 'VFlixPrime - 1080p',
                url: movie.customStream.url,
                behaviorHints: { notWebReady: true }
            };
            if (movie.customStream.referer || movie.customStream.userAgent) {
                stream.behaviorHints = stream.behaviorHints || {};
                stream.behaviorHints.proxyHeaders = { request: {} };
                if (movie.customStream.referer) stream.behaviorHints.proxyHeaders.request.Referer = movie.customStream.referer;
                if (movie.customStream.userAgent) stream.behaviorHints.proxyHeaders.request['User-Agent'] = movie.customStream.userAgent;
            }
            localStreams.push(stream);
        }
    } else if (type === 'series') {
        const series = getSeries();
        const parts = vflixId.split(':');
        const internalId = parts[0];
        const serie = series.find(s => s.id === internalId || s.imdbId === internalId);

        if (serie && serie.customStream && serie.customStream.url) {
            const stream = {
                title: serie.customStream.title || 'VFlixPrime - 1080p',
                url: serie.customStream.url,
                behaviorHints: { notWebReady: true }
            };
            if (serie.customStream.referer || serie.customStream.userAgent) {
                stream.behaviorHints = stream.behaviorHints || {};
                stream.behaviorHints.proxyHeaders = { request: {} };
                if (serie.customStream.referer) stream.behaviorHints.proxyHeaders.request.Referer = serie.customStream.referer;
                if (serie.customStream.userAgent) stream.behaviorHints.proxyHeaders.request['User-Agent'] = serie.customStream.userAgent;
            }
            localStreams.push(stream);
        }
    }

    // 2. Check Cache (Provider Results Only)
    const cacheKey = `stream:v2:${type}:${id}`;
    const cachedStreams = cache.get(cacheKey);
    if (cachedStreams) {
        console.log(`🚀 Serving from cache: ${cacheKey} (${cachedStreams.length} streams + ${localStreams.length} local)`);
        return res.json({ streams: [...localStreams, ...cachedStreams] });
    }

    // 3. Get enabled providers (Sorted by Priority)
    const providers = getProviders()
        .filter(p => p.enabled)
        .sort((a, b) => (a.priority || 10) - (b.priority || 10)); // Sort by priority (asc)

    console.log(`🔌 Providers order: ${providers.map(p => `${p.name} (${p.priority || 10})`).join(', ')}`);

    // 3. Prepare Provider Fetch Promises (The "Slow" Work)
    const providerPromises = providers.map(async (provider) => {
        let url = type === 'movie' ? provider.movieUrl : provider.seriesUrl;
        if (!url) return [];

        let cleanId = id;
        if (id.startsWith('vflix:')) {
            if (type === 'movie') {
                const m = getMovies().find(m => m.id === vflixId);
                if (m && (m.imdbId || m.externalId)) cleanId = m.imdbId || m.externalId;
            } else {
                const parts = vflixId.split(':');
                const s = getSeries().find(s => s.id === parts[0]);
                if (s && (s.imdbId || s.externalId)) {
                    cleanId = `${s.imdbId || s.externalId}:${parts[1]}:${parts[2]}`;
                }
            }
        }

        if (type === 'movie') {
            url = url.replace('{{id}}', cleanId);
        } else if (type === 'series') {
            const parts = cleanId.split(':');
            if (parts.length >= 3) {
                url = url.replace('{{id}}', parts[0])
                    .replace('{{season}}', parts[1])
                    .replace('{{episode}}', parts[2]);
            } else {
                return [];
            }
        }

        try {
            // Internal timeout for the provider itself
            const controller = new AbortController();
            const providerTimeout = provider.timeout || 10000;
            const timeoutId = setTimeout(() => controller.abort(), providerTimeout);

            console.log(`🔌 Fetching from ${provider.name}: ${url} (Timeout: ${providerTimeout}ms)`);
            const response = await axios.get(url, { signal: controller.signal });
            clearTimeout(timeoutId);

            const data = response.data;
            if (data.streams && Array.isArray(data.streams)) {
                return data.streams.map(stream => ({
                    ...stream,
                }));
            }
        } catch (error) {
            console.error(`❌ Error fetching from ${provider.name}: ${error.code === 'ECONNABORTED' ? 'Timeout' : error.message}`);
        }
        return [];
    });

    // 4. "Fast Return" Logic for User
    const settings = getSettings();
    const USER_WAIT_TIME = settings.masterTimeout || 8000;
    const userPromises = providerPromises.map(p => {
        // Create a race between the actual fetch and a null-returning timeout
        return Promise.race([
            p,
            new Promise(resolve => setTimeout(() => resolve(null), USER_WAIT_TIME))
        ]);
    });

    // Wait for the "Fast" batch
    const userResults = await Promise.all(userPromises);

    // Combine Local + Fast Provider Results
    streams = [...localStreams];
    userResults.forEach(res => {
        if (res) streams = [...streams, ...res]; // res is null if timed out
    });

    // 5. Background "Cache Fill" Logic
    // We let the ORIGINAL providerPromises finish (or fail) in their own time
    // and then update the cache with the COMPLETE list (Providers only).
    Promise.all(providerPromises).then(allResults => {
        let providerStreams = [];
        allResults.forEach(res => {
            if (res) providerStreams = [...providerStreams, ...res];
        });

        if (providerStreams.length > 0) {
            const ttl = settings.cacheDuration || 3600;
            console.log(`💾 Caching ${providerStreams.length} provider streams for ${cacheKey} (TTL: ${ttl}s)`);
            cache.set(cacheKey, providerStreams, ttl);
        }
    }).catch(err => console.error("Cache update failed:", err));

    res.json({ streams });
});

module.exports = router;
