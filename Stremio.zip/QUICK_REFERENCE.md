# VFlixPrime - Quick Reference Card

## 🚀 Quick Start

```bash
# Start the application
npm start

# Access the app
http://localhost:3000

# Login credentials
Username: admin
Password: admin123
```

## 🔑 API Keys Setup (One-Time)

### TMDB API Key
1. Visit: https://www.themoviedb.org/settings/api
2. Request API key (free)
3. Edit `server.js` line 79
4. Replace: `'YOUR_TMDB_API_KEY'` with your key

### OMDB API Key  
1. Visit: http://www.omdbapi.com/apikey.aspx
2. Request free key (1000/day)
3. Edit `server.js` line 113
4. Replace: `'YOUR_OMDB_API_KEY'` with your key

## 📽️ Adding Content

### Add Movie (TMDB)
1. Movies → + Add Movie
2. Source: TMDB
3. ID: Numeric (e.g., `550`)
4. Fetch & Add

### Add Movie (IMDB)
1. Movies → + Add Movie
2. Source: IMDB
3. ID: With tt prefix (e.g., `tt0137523`)
4. Fetch & Add

### Add Series (TMDB)
1. Series → + Add Series
2. Source: TMDB
3. ID: Numeric (e.g., `1399`)
4. Fetch & Add

### Add Series (IMDB)
1. Series → + Add Series
2. Source: IMDB
3. ID: With tt prefix (e.g., `tt0944947`)
4. Fetch & Add

## 🎬 Popular IDs for Testing

### Movies
| Title | TMDB | IMDB |
|-------|------|------|
| Fight Club | 550 | tt0137523 |
| The Dark Knight | 155 | tt0468569 |
| Inception | 27205 | tt1375666 |
| The Matrix | 603 | tt0133093 |
| Interstellar | 157336 | tt0816692 |

### Series
| Title | TMDB | IMDB |
|-------|------|------|
| Game of Thrones | 1399 | tt0944947 |
| Breaking Bad | 1396 | tt0903747 |
| Stranger Things | 66732 | tt4574334 |
| The Office | 2316 | tt0386676 |
| Friends | 1668 | tt0108778 |

## 🔍 Finding IDs

### TMDB
1. Search on themoviedb.org
2. Look at URL: `/movie/550-fight-club`
3. ID is: `550`

### IMDB
1. Search on imdb.com
2. Look at URL: `/title/tt0137523/`
3. ID is: `tt0137523` (include tt prefix!)

## 📺 Stremio Addon

### Install Addon
1. Dashboard → Copy addon URL
2. Open Stremio
3. Addons → Community Addons
4. Paste URL → Install

### Addon URL
```
http://localhost:3000/stremio/manifest.json
```

### Remote Access
Replace `localhost` with your IP:
```
http://192.168.1.100:3000/stremio/manifest.json
```

## ✏️ Edit Content

1. Click **Edit** button on any item
2. Modify fields:
   - Title
   - Overview
   - Rating
   - Poster URL
3. Save Changes

## 🗑️ Delete Content

1. Click **Delete** button
2. Confirm deletion
3. Content removed

## 🌐 API Endpoints

### Authentication
```
POST   /api/login
POST   /api/logout
GET    /api/check-auth
```

### Dashboard
```
GET    /api/dashboard
```

### Movies
```
GET    /api/movies
POST   /api/movies
PUT    /api/movies/:id
DELETE /api/movies/:id
```

### Series
```
GET    /api/series
POST   /api/series
PUT    /api/series/:id
DELETE /api/series/:id
```

### Stremio
```
GET    /stremio/manifest.json
GET    /stremio/catalog/:type/:id.json
GET    /stremio/meta/:type/:id.json
GET    /stremio/stream/:type/:id.json
```

## 🐛 Common Issues

### "Failed to fetch from TMDB"
- ❌ API key not configured
- ✅ Add TMDB API key to server.js

### "Failed to fetch from IMDB"
- ❌ API key not configured or wrong ID format
- ✅ Add OMDB API key and use tt prefix

### "Unauthorized"
- ❌ Not logged in
- ✅ Login with admin/admin123

### Server won't start
- ❌ Port 3000 in use
- ✅ Kill process or use different port

### Content not in Stremio
- ❌ Addon not installed or server not running
- ✅ Reinstall addon and ensure server is running

## 💻 Commands

```bash
# Install dependencies
npm install

# Start server
npm start

# Stop server
Ctrl + C

# Check port usage
netstat -ano | findstr :3000

# Kill process
taskkill /PID <PID> /F
```

## 📱 Access Points

| Page | URL |
|------|-----|
| Login | http://localhost:3000 |
| Admin | http://localhost:3000/admin |
| Dashboard | http://localhost:3000/admin (default) |
| Movies | Click Movies in nav |
| Series | Click Series in nav |
| Addon | http://localhost:3000/stremio/manifest.json |

## 🎨 Features

✅ Secure login system  
✅ Dashboard with statistics  
✅ Movies management (CRUD)  
✅ Series management (CRUD)  
✅ TMDB auto-import  
✅ IMDB auto-import  
✅ Edit existing content  
✅ Delete content  
✅ Stremio addon  
✅ Modern UI with animations  
✅ Responsive design  
✅ Glassmorphism effects  

## 📚 Documentation

- **README.md** - Full documentation
- **API_KEYS_GUIDE.md** - API setup guide
- **STREMIO_ADDON_GUIDE.md** - Addon guide
- **PROJECT_SUMMARY.md** - Project overview
- **QUICK_REFERENCE.md** - This file

## 🔐 Security Notes

⚠️ **Production Checklist**:
- [ ] Change default password
- [ ] Use environment variables for API keys
- [ ] Enable HTTPS
- [ ] Add rate limiting
- [ ] Use a real database
- [ ] Implement proper error handling
- [ ] Add logging
- [ ] Set up backups

## 🎯 Workflow

```
1. Start Server (npm start)
   ↓
2. Login (admin/admin123)
   ↓
3. Configure API Keys (one-time)
   ↓
4. Add Content (Movies/Series)
   ↓
5. Install Stremio Addon
   ↓
6. Browse in Stremio
```

## 💡 Pro Tips

1. **Batch Adding**: Add multiple items quickly by keeping the modal open
2. **Quick Edit**: Edit directly from the table view
3. **Poster URLs**: TMDB provides better quality posters
4. **Trailers**: Only TMDB imports include trailer links
5. **Seasons**: Series show season count in the table
6. **Rating**: Displayed as ⭐ with numeric value
7. **Recent Items**: Dashboard shows last 5 added items

## 📞 Support

Check documentation files for detailed help:
- Setup issues → README.md
- API problems → API_KEYS_GUIDE.md
- Addon issues → STREMIO_ADDON_GUIDE.md
- Feature overview → PROJECT_SUMMARY.md

---

**Quick Reference v1.0** | VFlixPrime Stremio
