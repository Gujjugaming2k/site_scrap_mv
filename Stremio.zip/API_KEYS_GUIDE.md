# API Keys Configuration Guide

## Getting Your API Keys

### TMDB API Key

1. **Create an Account**
   - Go to [https://www.themoviedb.org/](https://www.themoviedb.org/)
   - Click "Join TMDb" and create a free account
   - Verify your email address

2. **Request API Key**
   - Go to your account settings: [https://www.themoviedb.org/settings/api](https://www.themoviedb.org/settings/api)
   - Click "Request an API Key"
   - Choose "Developer" option
   - Fill in the application details:
     - Application Name: VFlixPrime
     - Application URL: http://localhost:3000
     - Application Summary: Personal content management system
   - Accept the terms and submit

3. **Copy Your API Key**
   - Once approved, you'll see your API Key (v3 auth)
   - Copy the key

4. **Add to Application**
   - Open `server.js`
   - Find line 79: `const TMDB_API_KEY = 'YOUR_TMDB_API_KEY';`
   - Replace `YOUR_TMDB_API_KEY` with your actual key
   - Save the file

### OMDB API Key (for IMDB)

1. **Request API Key**
   - Go to [http://www.omdbapi.com/apikey.aspx](http://www.omdbapi.com/apikey.aspx)
   - Select "FREE" plan (1,000 daily requests)
   - Enter your email address
   - Submit the form

2. **Verify Email**
   - Check your email for activation link
   - Click the link to activate your API key

3. **Copy Your API Key**
   - The API key will be shown in the email and on the website

4. **Add to Application**
   - Open `server.js`
   - Find line 113: `const OMDB_API_KEY = 'YOUR_OMDB_API_KEY';`
   - Replace `YOUR_OMDB_API_KEY` with your actual key
   - Save the file

## Example Configuration

After getting your keys, your `server.js` should look like this:

```javascript
// TMDB Fetch Function
async function fetchFromTMDB(type, id) {
    const TMDB_API_KEY = 'a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6'; // Your actual TMDB key
    // ... rest of the code
}

// IMDB Fetch Function (using OMDB API as proxy)
async function fetchFromIMDB(imdbId) {
    const OMDB_API_KEY = 'abc12345'; // Your actual OMDB key
    // ... rest of the code
}
```

## Testing Your Configuration

1. **Restart the Server**
   ```bash
   # Stop the current server (Ctrl+C)
   npm start
   ```

2. **Test TMDB Import**
   - Login to admin panel
   - Go to Movies page
   - Click "Add Movie"
   - Select "TMDB" as source
   - Enter ID: `550` (Fight Club)
   - Click "Fetch & Add"
   - Should successfully import the movie

3. **Test IMDB Import**
   - Go to Movies page
   - Click "Add Movie"
   - Select "IMDB" as source
   - Enter ID: `tt0137523` (Fight Club)
   - Click "Fetch & Add"
   - Should successfully import the movie

## Troubleshooting

### "Failed to fetch from TMDB"
- Check if your TMDB API key is correct
- Ensure the movie/series ID is valid
- Check your internet connection
- Verify you haven't exceeded rate limits

### "Failed to fetch from IMDB"
- Check if your OMDB API key is correct
- Ensure the IMDB ID includes the "tt" prefix
- Free tier has 1,000 requests per day limit
- Check if your API key is activated (check email)

### Rate Limits
- **TMDB**: 40 requests per 10 seconds
- **OMDB Free**: 1,000 requests per day

## Popular Movie/Series IDs for Testing

### TMDB Movies
- Fight Club: `550`
- The Dark Knight: `155`
- Inception: `27205`
- The Matrix: `603`
- Interstellar: `157336`

### TMDB Series
- Game of Thrones: `1399`
- Breaking Bad: `1396`
- The Office: `2316`
- Friends: `1668`
- Stranger Things: `66732`

### IMDB Movies
- Fight Club: `tt0137523`
- The Dark Knight: `tt0468569`
- Inception: `tt1375666`
- The Matrix: `tt0133093`
- Interstellar: `tt0816692`

### IMDB Series
- Game of Thrones: `tt0944947`
- Breaking Bad: `tt0903747`
- The Office: `tt0386676`
- Friends: `tt0108778`
- Stranger Things: `tt4574334`

## Security Notes

⚠️ **Important**: Never commit your API keys to version control!

1. Create a `.env` file (already in .gitignore):
   ```
   TMDB_API_KEY=your_tmdb_key_here
   OMDB_API_KEY=your_omdb_key_here
   ```

2. Install dotenv:
   ```bash
   npm install dotenv
   ```

3. Update `server.js`:
   ```javascript
   require('dotenv').config();
   
   const TMDB_API_KEY = process.env.TMDB_API_KEY;
   const OMDB_API_KEY = process.env.OMDB_API_KEY;
   ```

This keeps your keys secure and out of your code!
