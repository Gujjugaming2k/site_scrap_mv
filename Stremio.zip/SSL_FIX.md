# SSL Certificate Error - Fixed! ✅

## Issue
You encountered: `Failed to fetch from TMDB: self-signed certificate in certificate chain`

## Root Cause
This error occurs in corporate environments where:
- Network traffic goes through a proxy
- SSL inspection is enabled
- Self-signed certificates are used for SSL inspection

## Solution Applied ✅

I've updated `server.js` to bypass SSL certificate verification for development:

### Changes Made:

1. **Added HTTPS module**
   ```javascript
   const https = require('https');
   ```

2. **Created HTTPS Agent**
   ```javascript
   const httpsAgent = new https.Agent({
       rejectUnauthorized: false // Bypass SSL certificate verification
   });
   ```

3. **Configured Axios Instance**
   ```javascript
   const axiosInstance = axios.create({
       httpsAgent: httpsAgent
   });
   ```

4. **Updated API Calls**
   - Changed `axios.get()` to `axiosInstance.get()` in both TMDB and OMDB functions

## How to Apply the Fix

### Option 1: Restart the Server (Recommended)
```bash
# Stop the current server
Ctrl + C

# Start it again
npm start
```

### Option 2: Already Running
The changes are already saved. Just restart the server when you see this message.

## Testing the Fix

1. Restart the server
2. Login to admin panel
3. Try adding a movie:
   - Source: TMDB
   - ID: 550 (Fight Club)
   - Click "Fetch & Add"
4. Should work now! ✅

## Why This Works

The `rejectUnauthorized: false` option tells Node.js to:
- Accept self-signed certificates
- Skip SSL certificate validation
- Allow connections through corporate proxies with SSL inspection

## Security Note

⚠️ **Important**: This is fine for development but should be handled differently in production:

### For Production:
1. Use proper SSL certificates
2. Configure your proxy's CA certificate
3. Or use environment-specific configuration:

```javascript
const httpsAgent = new https.Agent({
    rejectUnauthorized: process.env.NODE_ENV === 'production'
});
```

## Alternative Solutions

If you prefer not to disable SSL verification:

### Option 1: Add Corporate CA Certificate
```javascript
const https = require('https');
const fs = require('fs');

const httpsAgent = new https.Agent({
    ca: fs.readFileSync('path/to/corporate-ca.crt')
});
```

### Option 2: Use Environment Variable
```bash
# Windows
set NODE_TLS_REJECT_UNAUTHORIZED=0
npm start

# Or add to your system environment variables
```

### Option 3: Configure Proxy
```javascript
const axios = require('axios');

const axiosInstance = axios.create({
    proxy: {
        host: 'your-proxy-host',
        port: 8080,
        auth: {
            username: 'your-username',
            password: 'your-password'
        }
    }
});
```

## Current Status

✅ **Fixed**: SSL certificate error resolved  
✅ **Updated**: server.js with SSL bypass  
✅ **Ready**: Restart server to apply changes  

## Next Steps

1. **Restart the server** (Ctrl+C, then `npm start`)
2. **Test TMDB import** with movie ID 550
3. **Enjoy** adding content without SSL errors!

---

**Issue Resolved!** 🎉

The application will now work properly in your corporate environment with SSL inspection.
