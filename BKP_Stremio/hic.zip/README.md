# Hicine Streams - Stremio Addon

A Stremio addon that provides streaming links for movies and series from Hicine, with multiple quality options (480p, 720p, 1080p).

## Features

- 🎬 **Movies and TV Series** - Full support for both content types
- 📊 **Multiple Qualities** - 480p, 720p, 1080p streaming options
- ⚡ **Fast Streaming** - Direct download links for quick playback
- 🔍 **IMDb Integration** - Automatic content matching via IMDb IDs
- 💾 **File Size Info** - See file sizes before streaming
- 🚀 **Easy Installation** - One-click install in Stremio

## Quick Start

### Installation

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Configure environment:**
   ```bash
   copy .env.example .env
   ```
   
   Edit `.env` and add your TMDB API key (optional but recommended):
   ```env
   TMDB_API_KEY=your_api_key_here
   ```

3. **Start the server:**
   ```bash
   npm start
   ```
   
   For development with auto-reload:
   ```bash
   npm run dev
   ```

### Install in Stremio

1. Open your browser and go to `http://localhost:3000`
2. Click the **"Install in Stremio"** button
3. Stremio will open and ask to install the addon
4. Click **"Install"** to add the addon to your Stremio

Alternatively, you can manually add the addon:
1. Copy the manifest URL: `http://localhost:3000/stremio/manifest.json`
2. In Stremio, go to **Addons** → **Community Addons**
3. Paste the manifest URL and click **"Install"**

## Usage

Once installed, the addon works automatically:

1. **Search for content** in Stremio (movies or TV series)
2. **Select an episode** (for series) or the movie
3. **Look for "Hicine" streams** in the available streams list
4. **Choose your preferred quality** (480p, 720p, or 1080p)
5. **Start streaming!**

## API Endpoints

### Stremio Addon

- **Manifest**: `GET /stremio/manifest.json`
- **Movie Streams**: `GET /stremio/stream/movie/:imdbId.json`
- **Series Streams**: `GET /stremio/stream/series/:imdbId:season:episode.json`

### Hicine API Wrapper

- **Get Content**: `GET /api/:imdbId.json`
- **Health Check**: `GET /health`
- **Clear Cache**: `POST /cache/clear`

## Configuration

Edit `.env` file to configure:

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | 3000 | Server port |
| `HICINE_API_BASE` | https://api.hicine.info/api | Hicine API base URL |
| `TMDB_API_KEY` | - | TMDB API key for IMDb ID lookup |
| `CACHE_ENABLED` | true | Enable/disable caching |
| `CACHE_TTL` | 3600 | Cache time-to-live (seconds) |
| `ADDON_NAME` | Hicine Streams | Addon name in Stremio |
| `ADDON_ID` | community.hicine | Unique addon identifier |

## Project Structure

```
hicine/
├── server.js              # Main Express server
├── addon.js               # Stremio addon definition
├── utils/
│   ├── hicineClient.js   # Hicine API client
│   ├── linkParser.js     # Movie link parsing
│   ├── seriesParser.js   # Series episode parsing
│   └── stremioFormatter.js # Stremio stream formatting
├── public/
│   └── index.html        # Landing page
├── package.json
├── .env.example
└── README.md
```

## How It Works

1. **Content Matching**: When you select content in Stremio, it sends the IMDb ID to the addon
2. **API Lookup**: The addon queries the Hicine API using TMDB to resolve IMDb IDs to titles
3. **Link Parsing**: Available streaming links are parsed and organized by quality
4. **Stream Delivery**: Links are formatted as Stremio streams and returned to the app
5. **Playback**: Stremio plays the selected stream directly

## Troubleshooting

### No streams appearing

- **Check if content exists**: Not all content may be available on Hicine
- **Verify TMDB API key**: Add a valid TMDB API key to `.env` for better IMDb ID resolution
- **Check server logs**: Look for errors in the console output

### Streams not playing

- **Network issues**: Ensure you have a stable internet connection
- **Link expiration**: Some links may expire; try a different quality
- **Firewall/VPN**: Some networks may block direct download links

### Addon not installing

- **Check server is running**: Ensure the server is running on the correct port
- **Verify URL**: Make sure you're using the correct manifest URL
- **Stremio version**: Update to the latest version of Stremio

## Development

### Testing Endpoints

Test the manifest:
```bash
curl http://localhost:3000/stremio/manifest.json
```

Test movie streams:
```bash
curl http://localhost:3000/stremio/stream/movie/tt6107548.json
```

Test series streams:
```bash
curl http://localhost:3000/stremio/stream/series/tt0944947:1:1.json
```

### Adding to Local Mapping

If TMDB lookup fails for certain content, add it to `imdb-mapping.json`:
```json
{
  "tt1234567": "Movie Title (2020)"
}
```

## License

MIT

## Credits

- Built with [Stremio Addon SDK](https://github.com/Stremio/stremio-addon-sdk)
- Powered by [Hicine API](https://hicine.info)
- IMDb data from [TMDB](https://www.themoviedb.org)
