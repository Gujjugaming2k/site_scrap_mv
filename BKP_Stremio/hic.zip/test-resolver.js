const axios = require('axios');

async function testResolution() {
    const redirectorUrl = 'https://quiet-lab-41f9.yolku.workers.dev/?vcloud=https://vcloud.zip/lb5cdkuawlka7kv';

    try {
        console.log('--- Step 1: Fetching Redirector Page ---');
        const response = await axios.get(redirectorUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
        });

        const html = response.data;
        const cookies = response.headers['set-cookie'];
        console.log('Cookies received:', cookies || 'None');

        const tokensMatch = html.match(/const tokens\s*=\s*({.*?});/s);
        const vcloudMatch = html.match(/const vcloudParam\s*=\s*"(.*?)";/);

        if (!tokensMatch || !vcloudMatch) {
            console.log('Failed to parse tokens or vcloudParam');
            return;
        }

        const tokens = JSON.parse(tokensMatch[1]);
        const vcloudParam = vcloudMatch[1];

        const type = 'fsl';
        const { ts, sig } = tokens[type];

        const urlObj = new URL(redirectorUrl);
        const goUrl = `${urlObj.origin}/go?type=${type}&vcloud=${encodeURIComponent(vcloudParam)}&ts=${ts}&sig=${sig}`;

        console.log('\n--- Step 2: Accessing /go URL ---');
        console.log('Constructed /go URL:', goUrl);

        try {
            const goResponse = await axios.get(goUrl, {
                maxRedirects: 0,
                validateStatus: (status) => status >= 200 && status < 400,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    ...(cookies ? { 'Cookie': cookies.join('; ') } : {})
                }
            });

            console.log('Response Status:', goResponse.status);
            console.log('Location Header:', goResponse.headers.location);

            if (goResponse.data && goResponse.data.includes('invalid')) {
                console.log('Response Body contains "invalid"');
            } else {
                console.log('Success! Final URL:', goResponse.headers.location || 'Direct Response');
            }
        } catch (error) {
            if (error.response) {
                console.log('Error Response Status:', error.response.status);
                console.log('Error Response Body:', error.response.data);
            } else {
                console.log('Error:', error.message);
            }
        }

    } catch (error) {
        console.error('Initial request failed:', error.message);
    }
}

testResolution();
