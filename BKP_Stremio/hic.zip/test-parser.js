// Test the series parser with actual data
const { parseEpisodeLine, parseSeason } = require('./utils/seriesParser');

// Test with actual episode line from Stranger Things
const testLine = "Episode 1 : https://wandering-cake-c634.annierane.workers.dev/?vcloud=https://vcloud.zip/vb9x19qnqiyrkys, 192.05 MB,480p : https://wandering-cake-c634.annierane.workers.dev/?vcloud=https://vcloud.zip/mtztgkgznjrspt6, 410.15 MB,720p : https://wandering-cake-c634.annierane.workers.dev/?vcloud=https://vcloud.zip/vjtvnjjzyodj5ed, 984.49 MB,1080p";

console.log('Testing episode line parser...\n');
console.log('Input:', testLine);
console.log('\n');

const result = parseEpisodeLine(testLine);
console.log('Result:', JSON.stringify(result, null, 2));

// Test with full season data
const seasonData = `Stranger Things: Season 1(2025) Dual Audio {Hindi DD5.1-English} NetFlix-Series 480p | 720p | 1080p WEB-DL | Vegamovies - Bollywood & Hollywood Movies 720p, 1080p & 2160p 4K
Episode 1 : https://wandering-cake-c634.annierane.workers.dev/?vcloud=https://vcloud.zip/vb9x19qnqiyrkys, 192.05 MB,480p : https://wandering-cake-c634.annierane.workers.dev/?vcloud=https://vcloud.zip/mtztgkgznjrspt6, 410.15 MB,720p : https://wandering-cake-c634.annierane.workers.dev/?vcloud=https://vcloud.zip/vjtvnjjzyodj5ed, 984.49 MB,1080p
Episode 2 : https://wandering-cake-c634.annierane.workers.dev/?vcloud=https://vcloud.zip/n-1qvp-tn1ecwxp, 189.64 MB,480p : https://wandering-cake-c634.annierane.workers.dev/?vcloud=https://vcloud.zip/dsdqdsloqs18ao4, 446.81 MB,720p : https://wandering-cake-c634.annierane.workers.dev/?vcloud=https://vcloud.zip/mr1r5gomsx1sgix, 862.85 MB,1080p`;

console.log('\n\nTesting season parser...\n');
const seasonResult = parseSeason(seasonData);
console.log('Season Result:', JSON.stringify(seasonResult, null, 2));
