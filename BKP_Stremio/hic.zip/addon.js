const { addonBuilder } = require('stremio-addon-sdk');
const { getContentDetails } = require('./utils/hicineClient');
const { parseLinks, getSimplifiedLinks } = require('./utils/linkParser');
const { parseSeriesSeasons } = require('./utils/seriesParser');
const { formatMovieStreams, formatSeriesStreams, parseVideoId } = require('./utils/stremioFormatter');
const { resolveAll } = require('./utils/linkResolver');

// Addon manifest
const manifest = {
    id: 'community.hicine',
    version: '1.0.0',
    name: 'Hicine Streams',
    description: 'Stream movies and series from Hicine with multiple quality options (480p, 720p, 1080p)',

    resources: ['stream'],
    types: ['movie', 'series'],

    catalogs: [],

    idPrefixes: ['tt'],

    logo: 'https://via.placeholder.com/256x256/1a1a2e/16213e?text=Hicine',
    background: 'https://via.placeholder.com/1920x1080/1a1a2e/16213e?text=Hicine+Streams',

    behaviorHints: {
        configurable: false,
        configurationRequired: false
    }
};

// Create addon builder
const builder = new addonBuilder(manifest);

// Stream handler
builder.defineStreamHandler(async ({ type, id }) => {
    try {
        console.log(`[Stremio] Stream request - Type: ${type}, ID: ${id}`);

        // Parse video ID
        const { imdbId, season, episode } = parseVideoId(id);

        if (!imdbId || !imdbId.match(/^tt\d+$/)) {
            console.log(`[Stremio] Invalid IMDb ID: ${imdbId}`);
            return { streams: [] };
        }

        // Get content details from Hicine API
        const content = await getContentDetails(imdbId);

        if (!content) {
            console.log(`[Stremio] Content not found for IMDb ID: ${imdbId}`);
            return { streams: [] };
        }

        console.log(`[Stremio] Found content: ${content.title} (${content.contentType})`);

        let streams = [];

        // Handle movies
        if (type === 'movie' && content.contentType === 'movies') {
            const organizedLinks = parseLinks(content.links);
            const initialStreams = formatMovieStreams(organizedLinks);
            console.log(`[Stremio] Found ${initialStreams.length} potential movie streams, resolving...`);
            streams = await resolveAll(initialStreams);
            console.log(`[Stremio] Returning ${streams.length} resolved movie streams`);
        }
        // Handle series
        else if (type === 'series' && content.contentType === 'series') {
            if (!season || !episode) {
                console.log(`[Stremio] Missing season/episode for series: ${imdbId}`);
                return { streams: [] };
            }

            const seasons = parseSeriesSeasons(content);
            const initialStreams = formatSeriesStreams(seasons, season, episode);
            console.log(`[Stremio] Found ${initialStreams.length} potential streams for S${season}E${episode}, resolving...`);
            streams = await resolveAll(initialStreams);
            console.log(`[Stremio] Returning ${streams.length} resolved streams`);
        }
        // Type mismatch
        else {
            console.log(`[Stremio] Type mismatch - Requested: ${type}, Found: ${content.contentType}`);
            return { streams: [] };
        }

        return { streams };

    } catch (error) {
        console.error('[Stremio] Error in stream handler:', error);
        return { streams: [] };
    }
});

module.exports = builder.getInterface();
