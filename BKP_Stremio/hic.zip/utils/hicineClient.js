const axios = require('axios');
const fs = require('fs');
const path = require('path');

const HICINE_API_BASE = process.env.HICINE_API_BASE || 'https://api.hicine.info/api';
const TMDB_API_KEY = process.env.TMDB_API_KEY || '';

// Load local IMDb mapping as fallback
let imdbMapping = {};
try {
    const mappingPath = path.join(__dirname, '..', 'imdb-mapping.json');
    if (fs.existsSync(mappingPath)) {
        imdbMapping = JSON.parse(fs.readFileSync(mappingPath, 'utf8'));
        console.log(`Loaded ${Object.keys(imdbMapping).length} IMDb mappings from local file`);
    }
} catch (error) {
    console.warn('Could not load imdb-mapping.json:', error.message);
}

/**
 * Get movie/series title from IMDb ID using TMDB API or local mapping
 * @param {string} imdbId - IMDb ID (e.g., tt6107548)
 * @returns {Promise<object|null>} Object with title and year
 */
async function getImdbInfo(imdbId) {
    try {
        // First check local mapping
        if (imdbMapping[imdbId]) {
            console.log(`Found IMDb mapping locally: ${imdbId} -> ${imdbMapping[imdbId]}`);
            return {
                title: imdbMapping[imdbId],
                year: null,
                type: null
            };
        }

        // If no API key, return null
        if (!TMDB_API_KEY) {
            console.log('No TMDB API key configured');
            return null;
        }

        // Use TMDB Find API to get movie/series info by IMDb ID
        const url = `https://api.themoviedb.org/3/find/${imdbId}?api_key=${TMDB_API_KEY}&external_source=imdb_id`;
        const response = await axios.get(url, { timeout: 5000 });

        if (response.data) {
            // Check movie results
            if (response.data.movie_results && response.data.movie_results.length > 0) {
                const movie = response.data.movie_results[0];
                return {
                    title: movie.title,
                    year: movie.release_date ? movie.release_date.split('-')[0] : null,
                    type: 'movie'
                };
            }

            // Check TV results
            if (response.data.tv_results && response.data.tv_results.length > 0) {
                const tv = response.data.tv_results[0];
                return {
                    title: tv.name,
                    year: tv.first_air_date ? tv.first_air_date.split('-')[0] : null,
                    type: 'series'
                };
            }
        }

        return null;
    } catch (error) {
        console.error('Error fetching IMDb info from TMDB:', error.message);
        return null;
    }
}

/**
 * Search for content on hicine API
 * @param {string} query - Search query (title or IMDb ID)
 * @returns {Promise<Array>} Array of search results
 */
async function searchContent(query) {
    try {
        const url = `${HICINE_API_BASE}/search/${encodeURIComponent(query)}`;
        const response = await axios.get(url, {
            timeout: 10000,
            headers: {
                'User-Agent': 'HicineAPIWrapper/1.0'
            }
        });

        return response.data || [];
    } catch (error) {
        console.error('Error searching hicine API:', error.message);
        throw new Error(`Failed to search hicine API: ${error.message}`);
    }
}

/**
 * Find content by IMDb ID
 * First gets title from IMDb ID, then searches hicine API
 * @param {string} imdbId - IMDb ID (e.g., tt6107548)
 * @returns {Promise<object|null>} Content object or null if not found
 */
async function findByImdbId(imdbId) {
    try {
        // First, try to get the title from IMDb ID
        const imdbInfo = await getImdbInfo(imdbId);

        let searchQuery = imdbId;
        if (imdbInfo && imdbInfo.title) {
            // Use the title for better search results
            searchQuery = imdbInfo.title;
            console.log(`Searching hicine for: ${searchQuery} (${imdbInfo.year})`);
        } else {
            console.log(`No IMDb info found, searching directly for: ${imdbId}`);
        }

        // Search hicine API
        const results = await searchContent(searchQuery);

        if (!results || results.length === 0) {
            return null;
        }

        // If we have IMDb info, try to match by title and year
        if (imdbInfo && imdbInfo.title && imdbInfo.year) {
            const yearStr = imdbInfo.year.split('–')[0]; // Handle series with year ranges
            const match = results.find(item => {
                return item.title && item.title.includes(yearStr);
            });

            if (match) {
                return match;
            }
        }

        // Return first result as fallback
        return results[0];
    } catch (error) {
        console.error('Error finding content by IMDb ID:', error.message);
        return null;
    }
}

/**
 * Get content details with additional metadata
 * @param {string} imdbId - IMDb ID
 * @returns {Promise<object|null>} Formatted content object
 */
async function getContentDetails(imdbId) {
    const content = await findByImdbId(imdbId);

    if (!content) {
        return null;
    }

    const details = {
        imdbId,
        title: content.title,
        featuredImage: content.featured_image,
        poster: content.poster,
        categories: content.categories ? content.categories.split(',').map(c => c.trim()) : [],
        contentType: content.contentType || 'unknown',
        links: content.links,
        urlSlug: content.url_slug,
        date: content.date,
        excerpt: content.excerpt
    };

    // Add season data for series
    if (content.contentType === 'series') {
        for (let i = 1; i <= 10; i++) {
            const seasonKey = `season_${i}`;
            if (content[seasonKey]) {
                details[seasonKey] = content[seasonKey];
            }
        }
        // Also include season_zip if available
        if (content.season_zip) {
            details.season_zip = content.season_zip;
        }
    }

    return details;
}

module.exports = {
    searchContent,
    findByImdbId,
    getContentDetails,
    getImdbInfo
};
