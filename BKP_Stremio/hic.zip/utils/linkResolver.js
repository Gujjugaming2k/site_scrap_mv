const axios = require('axios');

/**
 * Utility to resolve redirector pages into final streaming URLs
 */

/**
 * Resolve a single redirector URL into the final streaming URL
 * @param {string} redirectorUrl - The URL of the redirector page
 * @param {string} preferredType - Preferred server type (default: 'fsl')
 * @returns {Promise<string|null>} The final streaming URL or null
 */
async function resolveLink(redirectorUrl, preferredType = 'fsl') {
    try {
        console.log(`[Resolver] Resolving: ${redirectorUrl}`);

        const response = await axios.get(redirectorUrl, {
            timeout: 5000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
        });

        const html = response.data;
        if (typeof html !== 'string') return null;

        // 1. Extract tokens object
        // Format: const tokens={"fsl":{"ts":"...","sig":"..."},...};
        const tokensMatch = html.match(/const tokens\s*=\s*({.*?});/s);
        if (!tokensMatch) {
            console.log('[Resolver] Tokens not found in HTML');
            return null;
        }

        let tokens;
        try {
            tokens = JSON.parse(tokensMatch[1]);
        } catch (e) {
            console.error('[Resolver] Failed to parse tokens JSON:', e.message);
            return null;
        }

        // 2. Extract vcloudParam
        // Format: const vcloudParam="https://vcloud.zip/s-xxoem4p11-1ne";
        const vcloudMatch = html.match(/const vcloudParam\s*=\s*"(.*?)";/);
        if (!vcloudMatch) {
            console.log('[Resolver] vcloudParam not found in HTML');
            return null;
        }
        const vcloudParam = vcloudMatch[1];

        // 3. Determine server type
        // Priority: preferredType, fsl, fsl2
        let type = (preferredType === 'pixel' || preferredType === 'ten') ? 'fsl' : preferredType;
        if (!tokens[type]) {
            const priorities = ['fsl', 'fsl2'];
            type = priorities.find(p => tokens[p]) || Object.keys(tokens).find(k => k !== 'pixel' && k !== 'ten');
        }

        if (!type || !tokens[type]) {
            console.log('[Resolver] No suitable server type found');
            return null;
        }

        const { ts, sig } = tokens[type];

        // 4. Construct /go URL
        const urlObj = new URL(redirectorUrl);
        const goUrl = `${urlObj.origin}/go?type=${type}&vcloud=${encodeURIComponent(vcloudParam)}&ts=${ts}&sig=${sig}`;

        console.log(`[Resolver] Formed goUrl for type ${type}: ${goUrl}`);

        // 5. Follow the redirect to get the FINAL streaming URL
        const goResponse = await axios.get(goUrl, {
            maxRedirects: 0,
            validateStatus: (status) => status >= 200 && status < 400,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Referer': redirectorUrl
            }
        });

        const finalUrl = goResponse.headers.location || goUrl;

        // Final safety check to filter hubcdn.fans
        if (finalUrl.includes('hubcdn.fans')) {
            console.log(`[Resolver] Skipping hubcdn.fans link: ${finalUrl}`);
            return null;
        }

        console.log(`[Resolver] Final Resolved URL: ${finalUrl}`);
        return finalUrl;

    } catch (error) {
        console.error(`[Resolver] Error resolving ${redirectorUrl}:`, error.message);
        return null;
    }
}

/**
 * Resolve all links in a stream list
 * @param {Array} streams - Array of stream objects with url property
 * @returns {Promise<Array>} Array of resolved stream objects
 */
async function resolveAll(streams) {
    if (!streams || streams.length === 0) return [];

    const resolvedResults = await Promise.all(
        streams.map(async (stream) => {
            const resolvedUrl = await resolveLink(stream.url);
            if (resolvedUrl) {
                return {
                    ...stream,
                    url: resolvedUrl
                };
            }
            return null;
        })
    );

    return resolvedResults.filter(s => s !== null);
}

module.exports = {
    resolveLink,
    resolveAll
};
