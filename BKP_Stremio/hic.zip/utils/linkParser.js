/**
 * Parse the links field from hicine API response
 * Extracts URLs organized by quality (480p, 720p, 1080p)
 */

/**
 * Parse a single link line from the hicine API
 * Format: "URL, Link2, Link3, ..., Title, Size"
 * @param {string} line - Single line from links field
 * @returns {object} Parsed link object with url, title, size, quality
 */
function parseLinkLine(line) {
  if (!line || !line.trim()) return null;

  const parts = line.split(',').map(p => p.trim());

  if (parts.length < 2) return null;

  const url = parts[0];

  // Skip problematic redirect links
  if (url.includes('pixeldrain.com') || url.includes('hubcdn.fans')) return null;

  const title = parts[parts.length - 2] || '';
  const size = parts[parts.length - 1] || '';

  // Extract quality from title
  let quality = 'unknown';
  if (title.includes('480p')) quality = '480p';
  else if (title.includes('720p')) quality = '720p';
  else if (title.includes('1080p')) quality = '1080p';
  else if (title.includes('2160p') || title.includes('4K')) quality = '2160p';

  return {
    url,
    title,
    size,
    quality
  };
}

/**
 * Parse the entire links field from hicine API
 * @param {string} linksString - Multi-line string containing all links
 * @returns {object} Organized links by quality
 */
function parseLinks(linksString) {
  if (!linksString) {
    return {
      '480p': [],
      '720p': [],
      '1080p': [],
      '2160p': [],
      'other': []
    };
  }

  const lines = linksString.split('\n').filter(line => line.trim());
  const organized = {
    '480p': [],
    '720p': [],
    '1080p': [],
    '2160p': [],
    'other': []
  };

  lines.forEach(line => {
    const parsed = parseLinkLine(line);
    if (parsed) {
      const quality = parsed.quality === 'unknown' ? 'other' : parsed.quality;
      organized[quality].push(parsed);
    }
  });

  return organized;
}

/**
 * Get a simplified response with only the main download URLs
 * @param {object} organizedLinks - Links organized by quality
 * @returns {object} Simplified links with just URLs by quality
 */
function getSimplifiedLinks(organizedLinks) {
  const simplified = {};

  Object.keys(organizedLinks).forEach(quality => {
    if (organizedLinks[quality].length > 0) {
      simplified[quality] = organizedLinks[quality].map(link => ({
        url: link.url,
        size: link.size
      }));
    }
  });

  return simplified;
}

module.exports = {
  parseLinks,
  parseLinkLine,
  getSimplifiedLinks
};
