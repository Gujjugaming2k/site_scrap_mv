/**
 * Parse series episode data from season fields
 * Format: "Episode 1 : URL, SIZE,QUALITY : URL, SIZE,QUALITY"
 */

/**
 * Parse a single episode line
 * Format: "Episode 1 : https://..., 192.05 MB,480p : https://..., 410.15 MB,720p : https://..., 984.49 MB,1080p"
 * @param {string} line - Single episode line
 * @returns {object} Parsed episode with links by quality
 */
function parseEpisodeLine(line) {
    if (!line || !line.trim()) return null;

    // Extract episode number
    const episodeMatch = line.match(/Episode\s+(\d+)\s*:\s*/i);
    if (!episodeMatch) return null;

    const episodeNumber = parseInt(episodeMatch[1]);

    // Remove the "Episode X :" part
    const contentAfterEpisode = line.substring(episodeMatch[0].length).trim();

    // Split by " : " (with spaces!) to avoid breaking URLs
    const parts = contentAfterEpisode.split(' : ');

    const links = {
        '480p': null,
        '720p': null,
        '1080p': null,
        '2160p': null
    };

    // Parse each quality section
    // Format: "URL, SIZE,QUALITY"
    parts.forEach(part => {
        const trimmed = part.trim();
        if (!trimmed) return;

        // Check if this part contains a quality indicator
        const qualityMatch = trimmed.match(/(480p|720p|1080p|2160p)/i);
        if (!qualityMatch) return;

        const quality = qualityMatch[1].toLowerCase();

        // Extract URL (everything before the first comma)
        const urlMatch = trimmed.match(/^(https?:\/\/[^,\s]+)/);

        if (urlMatch) {
            const url = urlMatch[1].trim();

            // Extract size (between first comma and quality)
            // Format: "URL, SIZE,QUALITY"
            const sizeMatch = trimmed.match(/,\s*([^,]+?)\s*,\s*(480p|720p|1080p|2160p)/i);

            links[quality] = {
                url: url,
                size: sizeMatch ? sizeMatch[1].trim() : null
            };
        }
    });

    return {
        episode: episodeNumber,
        links
    };
}

/**
 * Parse a season field
 * @param {string} seasonData - Season data string with multiple episodes
 * @returns {Array} Array of parsed episodes
 */
function parseSeason(seasonData) {
    if (!seasonData) return [];

    const lines = seasonData.split('\n').filter(line => line.trim());
    const episodes = [];

    lines.forEach(line => {
        // Skip title lines
        if (!line.match(/Episode\s+\d+/i)) return;

        const episode = parseEpisodeLine(line);
        if (episode) {
            episodes.push(episode);
        }
    });

    return episodes;
}

/**
 * Parse all seasons from series data
 * @param {object} seriesData - Series data from hicine API
 * @returns {object} Organized seasons and episodes
 */
function parseSeriesSeasons(seriesData) {
    const seasons = {};

    // Parse season_1 through season_10
    for (let i = 1; i <= 10; i++) {
        const seasonKey = `season_${i}`;
        if (seriesData[seasonKey]) {
            const episodes = parseSeason(seriesData[seasonKey]);
            if (episodes.length > 0) {
                seasons[i] = episodes;
            }
        }
    }

    return seasons;
}

/**
 * Get series summary with episode counts by quality
 * @param {object} seasons - Parsed seasons data
 * @returns {object} Summary statistics
 */
function getSeriesSummary(seasons) {
    const summary = {
        totalSeasons: Object.keys(seasons).length,
        totalEpisodes: 0,
        qualityAvailability: {
            '480p': 0,
            '720p': 0,
            '1080p': 0,
            '2160p': 0
        }
    };

    Object.values(seasons).forEach(episodes => {
        summary.totalEpisodes += episodes.length;

        episodes.forEach(episode => {
            Object.keys(episode.links).forEach(quality => {
                if (episode.links[quality] && episode.links[quality].url) {
                    summary.qualityAvailability[quality]++;
                }
            });
        });
    });

    return summary;
}

module.exports = {
    parseEpisodeLine,
    parseSeason,
    parseSeriesSeasons,
    getSeriesSummary
};
