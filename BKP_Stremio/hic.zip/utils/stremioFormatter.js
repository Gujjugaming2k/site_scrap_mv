/**
 * Format Hicine API responses into Stremio stream format
 */

/**
 * Create a Stremio stream object
 * @param {string} url - Stream URL
 * @param {string} quality - Quality (480p, 720p, 1080p, etc.)
 * @param {string} size - File size
 * @returns {object} Stremio stream object
 */
function createStreamObject(url, quality, size) {
    return {
        name: `Hicine ${quality}`,
        title: size ? `${quality} • ${size}` : quality,
        url: url,
        behaviorHints: {
            notWebReady: true,
            bingeGroup: `hicine-${quality}`
        }
    };
}

/**
 * Format movie links into Stremio streams
 * @param {object} links - Organized links from linkParser
 * @returns {Array} Array of Stremio stream objects
 */
function formatMovieStreams(links) {
    const streams = [];
    const qualities = ['2160p', '1080p', '720p', '480p']; // Highest quality first

    qualities.forEach(quality => {
        if (links[quality] && links[quality].length > 0) {
            links[quality].forEach(link => {
                if (link.url) {
                    streams.push(createStreamObject(link.url, quality, link.size));
                }
            });
        }
    });

    // Add 'other' quality links at the end
    if (links.other && links.other.length > 0) {
        links.other.forEach(link => {
            if (link.url) {
                streams.push(createStreamObject(link.url, 'Unknown', link.size));
            }
        });
    }

    return streams;
}

/**
 * Format series episode links into Stremio streams
 * @param {object} seasons - Parsed seasons data from seriesParser
 * @param {number} seasonNum - Season number
 * @param {number} episodeNum - Episode number
 * @returns {Array} Array of Stremio stream objects
 */
function formatSeriesStreams(seasons, seasonNum, episodeNum) {
    const streams = [];

    // Check if season exists
    if (!seasons[seasonNum]) {
        return streams;
    }

    // Find the episode
    const episode = seasons[seasonNum].find(ep => ep.episode === episodeNum);
    if (!episode) {
        return streams;
    }

    // Format links by quality (highest first)
    const qualities = ['2160p', '1080p', '720p', '480p'];

    qualities.forEach(quality => {
        if (episode.links[quality] && episode.links[quality].url) {
            streams.push(
                createStreamObject(
                    episode.links[quality].url,
                    quality,
                    episode.links[quality].size
                )
            );
        }
    });

    return streams;
}

/**
 * Parse video ID to extract IMDb ID, season, and episode
 * Stremio format: "tt1234567:1:1" (imdbId:season:episode)
 * @param {string} videoId - Stremio video ID
 * @returns {object} Parsed ID components
 */
function parseVideoId(videoId) {
    const parts = videoId.split(':');

    return {
        imdbId: parts[0],
        season: parts[1] ? parseInt(parts[1]) : null,
        episode: parts[2] ? parseInt(parts[2]) : null
    };
}

module.exports = {
    createStreamObject,
    formatMovieStreams,
    formatSeriesStreams,
    parseVideoId
};
