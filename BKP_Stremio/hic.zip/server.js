require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const { getContentDetails } = require('./utils/hicineClient');
const { parseLinks, getSimplifiedLinks } = require('./utils/linkParser');
const { parseSeriesSeasons, getSeriesSummary } = require('./utils/seriesParser');

const app = express();
const PORT = process.env.PORT || 3000;

// Import Stremio addon
const addonInterface = require('./addon');

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// In-memory cache
const cache = new Map();
const CACHE_TTL = parseInt(process.env.CACHE_TTL) || 3600; // 1 hour default
const CACHE_ENABLED = process.env.CACHE_ENABLED !== 'false';

/**
 * Get cached data or fetch new data
 */
async function getCachedOrFetch(key, fetchFn) {
    if (CACHE_ENABLED && cache.has(key)) {
        const cached = cache.get(key);
        if (Date.now() - cached.timestamp < CACHE_TTL * 1000) {
            console.log(`Cache hit for: ${key}`);
            return cached.data;
        } else {
            cache.delete(key);
        }
    }

    const data = await fetchFn();

    if (CACHE_ENABLED && data) {
        cache.set(key, {
            data,
            timestamp: Date.now()
        });
    }

    return data;
}

/**
 * Main API endpoint - Get content by IMDb ID
 * GET /api/:imdbId.json
 */
app.get('/api/:imdbId.json', async (req, res) => {
    try {
        const { imdbId } = req.params;

        // Validate IMDb ID format
        if (!imdbId || !imdbId.match(/^tt\d+$/)) {
            return res.status(400).json({
                error: 'Invalid IMDb ID format. Expected format: tt1234567'
            });
        }

        console.log(`Fetching content for IMDb ID: ${imdbId}`);

        // Get content details (with caching)
        const content = await getCachedOrFetch(`content:${imdbId}`, async () => {
            return await getContentDetails(imdbId);
        });

        if (!content) {
            return res.status(404).json({
                error: 'Content not found',
                imdbId
            });
        }

        // Build response based on content type
        let response = {
            imdbId,
            title: content.title,
            contentType: content.contentType,
            poster: content.featuredImage || content.poster,
            categories: content.categories,
            metadata: {
                urlSlug: content.urlSlug,
                date: content.date,
                excerpt: content.excerpt
            }
        };

        // Handle movies
        if (content.contentType === 'movies') {
            const organizedLinks = parseLinks(content.links);
            const simplifiedLinks = getSimplifiedLinks(organizedLinks);

            response.links = {
                organized: organizedLinks,
                simple: simplifiedLinks
            };
        }
        // Handle series
        else if (content.contentType === 'series') {
            const seasons = parseSeriesSeasons(content);
            const summary = getSeriesSummary(seasons);

            response.seasons = seasons;
            response.summary = summary;
        }
        // Unknown content type - try to parse as movie
        else {
            const organizedLinks = parseLinks(content.links);
            const simplifiedLinks = getSimplifiedLinks(organizedLinks);

            response.links = {
                organized: organizedLinks,
                simple: simplifiedLinks
            };
        }

        res.json(response);
    } catch (error) {
        console.error('Error in /api/:imdbId.json:', error);
        res.status(500).json({
            error: 'Internal server error',
            message: error.message
        });
    }
});

/**
 * Health check endpoint
 */
app.get('/health', (req, res) => {
    res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        cache: {
            enabled: CACHE_ENABLED,
            ttl: CACHE_TTL,
            entries: cache.size
        }
    });
});

/**
 * Clear cache endpoint
 */
app.post('/cache/clear', (req, res) => {
    const size = cache.size;
    cache.clear();
    res.json({
        message: 'Cache cleared',
        entriesCleared: size
    });
});

/**
 * Stremio Addon Routes
 */
const { serveHTTP, getRouter } = require('stremio-addon-sdk');

// Use getRouter for synchronous mounting
app.use('/stremio', getRouter(addonInterface));

/**
 * Root endpoint - Serve landing page
 */
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Hicine API Wrapper running on port ${PORT}`);
    console.log(`📝 Cache: ${CACHE_ENABLED ? 'enabled' : 'disabled'} (TTL: ${CACHE_TTL}s)`);
    console.log(`🔗 API endpoint: http://localhost:${PORT}/api/:imdbId.json`);
    console.log(`🎬 Stremio addon: http://localhost:${PORT}/stremio/manifest.json`);
    console.log(`🌐 Landing page: http://localhost:${PORT}/`);
});

module.exports = app;
