const { addonBuilder } = require('stremio-addon-sdk');
const axios = require('axios');
const express = require('express');

const TMDB_API_KEY = 'ea7b1fc3807d8a53d4227a80a15aeed1';
const WORKER_BASE_URL = 'https://frosty-lab-f40b.vflixprime.workers.dev';

const manifest = {
    id: 'org.moviebox.addon',
    version: '1.0.0',
    name: 'MovieBox Addon',
    description: 'Streams from MovieBox via Cloudflare Worker',
    resources: ['stream'],
    types: ['movie', 'series'],
    idPrefixes: ['tt'],
    catalogs: []
};

const builder = new addonBuilder(manifest);

// Simple In-Memory Cache
const cache = new Map();
const CACHE_TTL = 300000; // 5 minutes

function getCache(key) {
    const entry = cache.get(key);
    if (entry && (Date.now() - entry.timestamp) < CACHE_TTL) {
        return entry.data;
    }
    return null;
}

function setCache(key, data) {
    cache.set(key, { data, timestamp: Date.now() });
}

async function getMetadata(imdbId, type) {
    const cacheKey = `meta:${imdbId}:${type}`;
    const cached = getCache(cacheKey);
    if (cached) return cached;

    try {
        const response = await axios.get(`https://api.themoviedb.org/3/find/${imdbId}`, {
            params: {
                api_key: TMDB_API_KEY,
                external_source: 'imdb_id'
            }
        });

        const results = type === 'movie' ? response.data.movie_results : response.data.tv_results;
        if (results && results.length > 0) {
            const item = results[0];
            const meta = {
                title: item.title || item.name,
                year: (item.release_date || item.first_air_date || '').split('-')[0]
            };
            setCache(cacheKey, meta);
            return meta;
        }
    } catch (error) {
        console.error('TMDB Metadata Error:', error.message);
    }
    return null;
}

async function searchWorker(query) {
    const cacheKey = `search:${query}`;
    const cached = getCache(cacheKey);
    if (cached) return cached;

    try {
        const response = await axios.get(`${WORKER_BASE_URL}/api/search/${encodeURIComponent(query)}`);
        if (response.data.status === 'success' && response.data.data.items) {
            const items = response.data.data.items;
            setCache(cacheKey, items);
            return items;
        }
    } catch (error) {
        console.error(`Worker Search Error (${query}):`, error.message);
    }
    return [];
}

async function fetchSourcesWithResilience(subjectId, season, episode) {
    const params = new URLSearchParams();
    if (season) params.append('season', season);
    if (episode) params.append('episode', episode);

    const url = `${WORKER_BASE_URL}/api/sources/${subjectId}${params.toString() ? '?' + params.toString() : ''}`;

    // Performance optimization: fast attempt with 3 parallel requests
    try {
        const requests = Array(3).fill(null).map(() => axios.get(url, { timeout: 8000 }));
        const firstSuccess = await Promise.any(requests.map(p => p.then(res => {
            if (res.data.status === 'success' && res.data.data && res.data.data.processedSources) {
                return res.data;
            }
            throw new Error(res.data.message || 'Invalid response');
        })));
        if (firstSuccess) return firstSuccess;
    } catch (e) {
        // Fallback to single retry if all 3 parallel fail (only if needed)
        try {
            const res = await axios.get(url, { timeout: 10000 });
            if (res.data.status === 'success' && res.data.data && res.data.data.processedSources) {
                return res.data;
            }
        } catch (error) {
            console.error(`Fetch failed for ${subjectId}:`, error.message);
        }
    }
    return null;
}

builder.defineStreamHandler(async ({ type, id }) => {
    const parts = id.split(':');
    const imdbId = parts[0];
    const season = parts[1];
    const episode = parts[2];

    const metadata = await getMetadata(imdbId, type);
    if (!metadata) return { streams: [] };

    // Search variants in parallel
    const searchQueries = [
        metadata.title,
        `${metadata.title} Hindi`,
        `${metadata.title} Tamil`
    ];

    const searchResults = await Promise.all(searchQueries.map(q => searchWorker(q)));
    const allItems = [].concat(...searchResults);

    const cleanTitle = (t) => t.toLowerCase()
        .replace(/\[.*?\]/g, '') // Remove bracketed info like [Hindi]
        .replace(/\(.*?\)/g, '') // Remove parenthesized info like (2024)
        .replace(/[^a-z0-9\s]/g, '') // Remove special characters
        .replace(/\s+/g, ' ') // Normalize spaces
        .trim();

    const metaTitleClean = cleanTitle(metadata.title);
    const seenIds = new Set();

    const matchedSubjects = allItems.filter(item => {
        if (seenIds.has(item.subjectId)) return false;

        const itemTitleClean = cleanTitle(item.title);
        const itemYear = (item.releaseDate || '').split('-')[0];

        // Match if titles are identical OR if the item title starts with the meta title + a space (handles variants)
        const isTitleMatch = itemTitleClean === metaTitleClean || itemTitleClean.startsWith(metaTitleClean + ' ');

        // Year match: Allow +/- 1 year tolerance
        const isYearMatch = !metadata.year || !itemYear || Math.abs(parseInt(itemYear) - parseInt(metadata.year)) <= 1;

        if (isTitleMatch && isYearMatch) {
            seenIds.add(item.subjectId);
            return true;
        }
        return false;
    });

    if (matchedSubjects.length === 0) return { streams: [] };

    const allStreams = [];

    // Performance: Fetch sources for ALL matched subjects in parallel
    const sourcePromises = matchedSubjects.map(subject =>
        fetchSourcesWithResilience(subject.subjectId, season, episode).then(data => ({ subject, data }))
    );

    const results = await Promise.all(sourcePromises);

    for (const { subject, data } of results) {
        if (data && data.data && data.data.processedSources) {
            data.data.processedSources.forEach(source => {
                allStreams.push({
                    title: `🎥 ${subject.title} | ${source.quality || 'HD'} | 💾 ${(source.size / (1024 * 1024 * 1024)).toFixed(2)} GB`,
                    url: source.streamUrl,
                    behaviorHints: {
                        notPeered: true
                    }
                });
            });
        }
    }

    return { streams: allStreams };
});

const { serveHTTP } = require('stremio-addon-sdk');
serveHTTP(builder.getInterface(), { port: process.env.PORT || 7005 });
