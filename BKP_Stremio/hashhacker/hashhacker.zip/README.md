# HashHackers Stremio Provider

A Stremio addon that fetches streaming content from the HashHackers API.

## Features

- ✅ **IMDB ID Resolution**: Automatically resolves IMDB IDs to titles using TMDB API
- ✅ **Movie Support**: Search and stream movies
- ✅ **Series Support**: Search and stream TV series with season/episode detection
- ✅ **Smart Search**: Automatically appends S01E01 format for series episodes
- ✅ **Smart Filtering**: Automatically excludes multi-part files (part001, part002, etc.)
- ✅ **Multiple Results**: Returns up to 5 streaming options per request
- ✅ **File Information**: Displays filename and file size for each stream
- ⚡ **High Performance**: 
  - In-memory caching for TMDB lookups (1 hour TTL)
  - Parallel link generation using Promise.all
  - Optimized for ~1-2 second response times
  - SSL/HTTPS handling configured

## Installation

1. Install dependencies:
```bash
npm install
```

2. Start the server:
```bash
node index.js
```

The addon will run on `http://localhost:7000`

## Endpoints

### 1. Manifest
```
GET /manifest.json
```
Returns the addon manifest with metadata and capabilities.

### 2. Stream
```
GET /stream/:type/:id.json
```
Returns available streams for a given IMDB ID.

**Parameters:**
- `type`: Either `movie` or `series`
- `id`: IMDB ID (e.g., `tt1234567`) or IMDB ID with season/episode (e.g., `tt1234567:1:5` for S01E05)

**Example:**
```
GET /stream/movie/tt0111161.json
GET /stream/series/tt0944947:1:1.json
```

### 3. TMDB Keys
```
GET /IMDB.json
```
Returns the list of TMDB API keys used by the addon.

## How It Works

1. **ID Resolution**: When a request comes in with an IMDB ID, the addon queries TMDB to get the title and metadata
2. **Smart Search**: For series, it appends the season/episode (e.g., "Breaking Bad S01E01") to improve search accuracy
3. **File Search**: Searches the HashHackers API for matching files
4. **Smart Filtering**: Automatically filters out multi-part files (e.g., `part001.mkv`, `part002.mkv`) that won't play properly
5. **Link Generation**: Generates streaming links for each complete file found (in parallel for speed)
6. **Stream Response**: Returns formatted streams compatible with Stremio

## Adding to Stremio

1. Make sure the addon is running on your local machine or deployed to a server
2. Open Stremio
3. Go to Addons
4. Click "Community Addons" or use the addon URL directly
5. Enter: `http://localhost:7000/manifest.json` (or your deployed URL)
6. Click Install

## Deployment

### Using a Public URL (Required for Stremio)

Stremio requires a publicly accessible URL. You can deploy this addon to:

- **Heroku**: Free tier available
- **Railway**: Easy deployment
- **Vercel**: Serverless deployment
- **Your own VPS**: Full control

### Environment Variables

You can optionally set:
```bash
PORT=7000  # Default port
```

## API Sources

- **HashHackers Search API**: `https://tga-hd.api.hashhackers.com/files/search`
- **HashHackers Link API**: `https://tga-hd.api.hashhackers.com/genLink`
- **TMDB API**: Used for IMDB ID to title resolution

## Example Response

When you request `/stream/movie/tt0111161.json`, you'll get:

```json
{
  "streams": [
    {
      "name": "HashHackers",
      "title": "The Shawshank Redemption 1994 1080p BluRay x265.mkv\nSize: 2.45 GB",
      "url": "https://backup-cdn.indexer.eu.org/dl/..."
    }
  ]
}
```

## Testing

Run the included test script to verify the addon is working:

```bash
node test.js
```

This will test the addon with sample movies and series, showing response times and results.

## Performance Optimizations

The addon includes several optimizations for speed:

1. **TMDB Caching**: IMDB-to-title lookups are cached for 1 hour to avoid redundant API calls
2. **Parallel Processing**: All link generation requests run simultaneously using `Promise.all`
3. **Smart Filtering**: Excludes multi-part files before processing to avoid wasted API calls
4. **Limited Results**: Returns top 5 complete files instead of all matches for faster response
5. **Timeout Configuration**: 10-second timeout on all HTTP requests to prevent hanging
6. **SSL Optimization**: Configured HTTPS agent for faster secure connections

**Typical Response Times:**
- First request (cold cache): ~2-3 seconds
- Subsequent requests (cached): ~1-2 seconds

## Troubleshooting

### No streams found
- Check if the title exists in the HashHackers database
- Try searching manually at: `https://tga-hd.api.hashhackers.com/files/search?q=YOUR_TITLE`

### TMDB API errors
- The addon uses multiple TMDB keys and rotates between them
- If all keys are rate-limited, wait a few minutes

### Stremio not connecting
- Ensure the addon is publicly accessible (not just localhost)
- Check that CORS is enabled (already configured in the code)

## License

MIT
