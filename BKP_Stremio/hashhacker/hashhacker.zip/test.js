const axios = require('axios');

async function testAddon() {
    console.log('🧪 Testing Stremio Addon Performance...\n');

    const tests = [
        { type: 'movie', id: 'tt0111161', name: 'The Shawshank Redemption' },
        { type: 'movie', id: 'tt0468569', name: 'The Dark Knight' },
        { type: 'series', id: 'tt0944947:1:1', name: 'Game of Thrones S01E01' }
    ];

    for (const test of tests) {
        console.log(`Testing: ${test.name} (${test.type})`);
        const startTime = Date.now();

        try {
            const response = await axios.get(`http://localhost:7000/stream/${test.type}/${test.id}.json`);
            const duration = Date.now() - startTime;

            console.log(`✅ Success in ${duration}ms`);
            console.log(`   Found ${response.data.streams.length} streams`);
            if (response.data.streams.length > 0) {
                console.log(`   First stream: ${response.data.streams[0].title.split('\n')[0]}`);
            }
        } catch (error) {
            const duration = Date.now() - startTime;
            console.log(`❌ Failed in ${duration}ms: ${error.message}`);
        }
        console.log('');
    }

    console.log('🏁 Testing complete!');
}

testAddon();
