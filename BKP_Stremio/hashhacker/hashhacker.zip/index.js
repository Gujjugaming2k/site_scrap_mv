const express = require('express');
const axios = require('axios');
const cors = require('cors');
const https = require('https');

const app = express();
app.use(cors());

// Configure axios to handle SSL
const axiosInstance = axios.create({
    httpsAgent: new https.Agent({
        rejectUnauthorized: false
    }),
    timeout: 10000
});

// Configuration
const TMDB_KEYS = [
    "e3c47f86a8cecb8721f9cc45a1e1ba8f",
    "ea7b1fc3807d8a53d4227a80a15aeed1",
    "abf4d0f9cf2c7ad4990823215af63543",
    "83aa53347a84d73e55c6ada9e5d537fe"
];

const SEARCH_API = 'https://tga-hd.api.hashhackers.com/files/search';
const LINK_API = 'https://tga-hd.api.hashhackers.com/genLink';

// In-memory cache for TMDB results (expires after 1 hour)
const tmdbCache = new Map();
const CACHE_DURATION = 60 * 60 * 1000; // 1 hour

// Helper: Get random TMDB key
function getTmdbKey() {
    return TMDB_KEYS[Math.floor(Math.random() * TMDB_KEYS.length)];
}

// Helper: Get Metadata from TMDB
async function getMetaFromTmdb(imdbId) {
    // Check cache first
    const cached = tmdbCache.get(imdbId);
    if (cached && (Date.now() - cached.timestamp < CACHE_DURATION)) {
        console.log(`Cache hit for ${imdbId}`);
        return cached.data;
    }

    const key = getTmdbKey();
    try {
        const url = `https://api.themoviedb.org/3/find/${imdbId}?api_key=${key}&external_source=imdb_id`;
        const response = await axiosInstance.get(url);
        const data = response.data;

        let result = null;
        if (data.movie_results && data.movie_results.length > 0) {
            result = data.movie_results[0];
            result.type = 'movie';
        } else if (data.tv_results && data.tv_results.length > 0) {
            result = data.tv_results[0];
            result.type = 'series';
        }

        // Store in cache
        tmdbCache.set(imdbId, {
            data: result,
            timestamp: Date.now()
        });

        return result;
    } catch (error) {
        console.error('Error fetching TMDB meta:', error.message);
        if (error.response) {
            console.error('TMDB Response:', error.response.status, error.response.data);
        }
        return null;
    }
}

// 1. Manifest Endpoint
app.get('/manifest.json', (req, res) => {
    const manifest = {
        id: 'org.hashhackers.stremio',
        version: '1.0.0',
        name: 'HashHackers Provider',
        description: 'Fetches streams from HashHackers API',
        resources: ['stream'],
        types: ['movie', 'series'],
        idPrefixes: ['tt'],
        catalogs: []
    };
    res.json(manifest);
});

// 2. Stream Endpoint
app.get('/stream/:type/:id.json', async (req, res) => {
    const { type, id } = req.params;
    let imdbId = id;
    let season = null;
    let episode = null;

    // Stremio sends IDs like tt1234567:1:1 for episodes
    if (id.includes(':') && type === 'series') {
        const parts = id.split(':');
        imdbId = parts[0];
        season = parts[1];
        episode = parts[2];
    } else if (id.includes(':')) {
        // Fallback for movies if they somehow have colons (rare)
        imdbId = id.split(':')[0];
    }

    console.log(`Received request for stream: ${type} ${id} (IMDB: ${imdbId})`);

    try {
        // Step 1: Resolve IMDB ID to Title using TMDB
        const meta = await getMetaFromTmdb(imdbId);
        if (!meta) {
            console.log('No metadata found for ID:', imdbId);
            return res.json({ streams: [] });
        }

        let title = meta.name || meta.title || meta.original_title;
        const year = meta.release_date ? meta.release_date.split('-')[0] : (meta.first_air_date ? meta.first_air_date.split('-')[0] : '');

        console.log(`Resolved ${imdbId} to "${title}" (${year})`);

        // Refine search query for Series
        let searchQuery = title;
        if (type === 'series' && season && episode) {
            // Pad with zero if needed, e.g., S01E01
            const s = season.toString().padStart(2, '0');
            const e = episode.toString().padStart(2, '0');
            searchQuery += ` S${s}E${e}`;
        }

        console.log(`Searching for: ${searchQuery}`);

        // Step 2: Search HashHackers API
        const searchUrl = `${SEARCH_API}?q=${encodeURIComponent(searchQuery)}`;
        const searchResponse = await axiosInstance.get(searchUrl);
        const searchData = searchResponse.data;

        if (!searchData || !searchData.files || searchData.files.length === 0) {
            console.log('No files found in search.');
            return res.json({ streams: [] });
        }

        // Step 3: Filter out multi-part files (part001, part002, etc.)
        // These are incomplete and won't play properly
        const completeFiles = searchData.files.filter(file => {
            const fileName = file.file_name.toLowerCase();
            // Exclude files with part001, part002, etc. (must start with part0)
            // This allows part1, link1, etc. to pass through
            return !fileName.match(/part0\d+/i);
        });

        const filteredCount = searchData.files.length - completeFiles.length;
        if (filteredCount > 0) {
            console.log(`Filtered out ${filteredCount} multi-part file(s)`);
        }

        if (completeFiles.length === 0) {
            console.log('No complete files found (all are multi-part).');
            return res.json({ streams: [] });
        }

        // Step 4: Generate Links for results (PARALLEL for speed)
        // Limit to 20 files for faster response (increased from 5)
        const filesToProcess = completeFiles.slice(0, 50);

        // Fetch all links in parallel
        const linkPromises = filesToProcess.map(async (file) => {
            try {
                const linkResponse = await axiosInstance.get(`${LINK_API}?type=files&id=${file.id}`);
                if (linkResponse.data && linkResponse.data.success && linkResponse.data.url) {
                    return {
                        name: 'HashHackers',
                        title: `${file.file_name}\nSize: ${(file.file_size / 1024 / 1024 / 1024).toFixed(2)} GB`,
                        url: linkResponse.data.url
                    };
                }
            } catch (linkError) {
                console.error(`Error generating link for file ${file.id}:`, linkError.message);
            }
            return null;
        });

        // Wait for all promises and filter out nulls
        const streamResults = await Promise.all(linkPromises);
        const streams = streamResults.filter(s => s !== null);

        res.json({ streams });

    } catch (error) {
        console.error('Error handling stream request:', error);
        res.json({ streams: [] });
    }
});

// 3. IMDB.json Route
app.get('/IMDB.json', (req, res) => {
    res.json(TMDB_KEYS);
});

// Start Server
const PORT = process.env.PORT || 7000;
app.listen(PORT, () => {
    console.log(`Stremio Addon running on http://localhost:${PORT}`);
    console.log(`Manifest: http://localhost:${PORT}/manifest.json`);
});
