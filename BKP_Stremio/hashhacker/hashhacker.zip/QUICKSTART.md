# 🚀 Quick Start Guide

## Get Started in 3 Steps

### 1️⃣ Start the Server
```bash
node index.js
```

You should see:
```
Stremio Addon running on http://localhost:7000
Manifest: http://localhost:7000/manifest.json
```

### 2️⃣ Test It Works
Open a new terminal and run:
```bash
node test.js
```

You should see successful responses with stream URLs!

### 3️⃣ Add to Stremio

**Option A: Local Testing (Development)**
1. Open Stremio
2. Go to **Addons** → **Community Addons**
3. Enter: `http://localhost:7000/manifest.json`
4. Click **Install**

**Option B: Public Deployment (Production)**
Deploy to a hosting service first, then use your public URL:
- Heroku: `https://your-app.herokuapp.com/manifest.json`
- Railway: `https://your-app.railway.app/manifest.json`
- Your VPS: `https://yourdomain.com/manifest.json`

## 🎬 Using the Addon

1. Open any movie or series in Stremio
2. Look for **HashHackers** in the sources list
3. Click to see available streams
4. Select your preferred quality/file
5. Enjoy! 🍿

## 📊 What to Expect

### Response Times
- **First request**: 2-3 seconds (fetching from APIs)
- **Cached request**: 1-2 seconds (using cache)
- **Same content again**: ~0.1 seconds (instant!)

### Stream Quality
You'll see streams with information like:
```
HashHackers
Movie.Name.2024.1080p.WEB-DL.x265.mkv
Size: 2.45 GB
```

## 🔧 Troubleshooting

### "No streams found"
- The content might not be in the HashHackers database
- Try searching manually: https://tga-hd.api.hashhackers.com/files/search?q=YOUR_TITLE

### "Cannot connect to addon"
- Make sure `node index.js` is running
- Check the URL is correct
- For production, ensure your server is publicly accessible

### Slow responses
- First request is always slower (cold cache)
- Check your internet connection
- The HashHackers API might be slow

## 📁 Project Files

```
EDU/
├── index.js           # Main addon server
├── test.js            # Test script
├── package.json       # Dependencies
├── README.md          # Full documentation
├── PERFORMANCE.md     # Optimization details
└── .gitignore        # Git ignore rules
```

## 🎯 Next Steps

1. **Deploy to Production**: Use Heroku, Railway, or your own VPS
2. **Customize**: Modify the number of results, cache duration, etc.
3. **Monitor**: Check logs to see what content is being requested
4. **Share**: Give the manifest URL to friends!

## 💡 Pro Tips

- The addon caches TMDB lookups for 1 hour - popular content loads instantly
- It processes 5 files in parallel for optimal speed
- All HTTPS/SSL issues are handled automatically
- Logs show exactly what's happening for debugging

---

**Need help?** Check the full [README.md](README.md) or [PERFORMANCE.md](PERFORMANCE.md) for details!
