# Multi-Part File Filtering

## Problem

Some files in the HashHackers database are split into multiple parts:
```
Die My Love 2025 1080p WEB-DL.part001.mkv
Die My Love 2025 1080p WEB-DL.part002.mkv
Die My Love 2025 1080p WEB-DL.part003.mkv
```

These files **won't play properly** in Stremio because:
- They're incomplete (need all parts to play)
- Stremio expects a single, complete file
- Users would see errors or partial playback

## Solution

The addon automatically filters out these multi-part files before showing them to users.

### Filtering Logic

The addon excludes files matching these patterns:

1. **`.partXXX.` pattern**: Files with `.part001.`, `.part002.`, etc.
   ```
   ❌ Movie.2024.1080p.part001.mkv
   ❌ Movie.2024.1080p.part002.mkv
   ✅ Movie.2024.1080p.mkv
   ```

2. **`partXXX` pattern**: Files with `part001`, `part002`, etc. (3+ digits)
   ```
   ❌ Movie.2024.part001.mkv
   ❌ Movie.2024.part002.mkv
   ✅ Movie.2024.mkv
   ```

### Code Implementation

```javascript
const completeFiles = searchData.files.filter(file => {
    const fileName = file.file_name.toLowerCase();
    // Exclude files with part001, part002, part1, part2, etc.
    return !fileName.match(/\.part\d+\./i) && 
           !fileName.match(/part\d{3,}/i);
});
```

### Examples

#### ✅ **Allowed Files** (Will Show in Stremio)
```
The Dark Knight 2008 1080p BluRay x265.mkv
Breaking Bad S01E01 1080p WEB-DL.mkv
Inception 2010 2160p UHD HDR.mkv
Game of Thrones S08E06 FINAL.mkv
```

#### ❌ **Filtered Files** (Won't Show)
```
Die My Love 2025 1080p.part001.mkv
Die My Love 2025 1080p.part002.mkv
Movie.2024.1080p.part1.mkv
Series.S01E01.part001.mkv
BigFile.part0001.mkv
```

## Logging

When files are filtered, you'll see a log message:
```
Filtered out 2 multi-part file(s)
```

If all files are multi-part:
```
No complete files found (all are multi-part).
```

## Benefits

✅ **Better UX**: Users only see playable files  
✅ **Faster**: Avoids generating links for unusable files  
✅ **Cleaner**: No confusing partial files in the list  
✅ **Automatic**: No user configuration needed  

## Edge Cases

The filter is designed to be conservative:

- **`part1` or `part2`** (1-2 digits): Not filtered (might be legitimate naming)
- **`part001`** (3+ digits): Filtered (clearly a multi-part file)
- **Case insensitive**: Works with `PART001`, `Part001`, etc.

This ensures we don't accidentally filter legitimate files while catching all multi-part splits.
