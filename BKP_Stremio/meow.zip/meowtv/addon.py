import asyncio
import os
import re
from typing import Any, Optional
from flask import Flask, jsonify, request
from flask_cors import CORS
import httpx

from meowtv.providers import register_providers, get_provider
from meowtv.models import VideoResponse
from meowtv.config import get_config
from meowtv.providers.proxy import set_proxy_url

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Register all providers
register_providers()

# Constants
CINEMETA_URL = "https://v3-cinemeta.strem.io"

MANIFEST = {
    "id": "org.meowtv.addon",
    "version": "1.1.0",
    "name": "MeowTV Addon",
    "description": "Streams from MeowTV (Castle)",
    "logo": "https://img.icons8.com/bubbles/100/cat.png",
    "resources": ["stream"],
    "types": ["movie", "series"],
    "catalogs": [],
    "idPrefixes": ["tt"]
}

async def fetch_meta(imdb_id: str, content_type: str) -> dict:
    """Fetch metadata from Cinemeta."""
    async with httpx.AsyncClient(timeout=10, follow_redirects=True) as client:
        try:
            url = f"{CINEMETA_URL}/meta/{content_type}/{imdb_id}.json"
            res = await client.get(url)
            if res.status_code == 200:
                data = res.json()
                return data.get("meta", {})
        except Exception as e:
            print(f"[Addon] Cinemeta error for {imdb_id}: {e}")
    return {}


async def get_streams_from_meowtv(title: str, year: Optional[int], type_str: str, season: int = 1, episode: int = 1) -> list:
    """Fetch streams from MeowTV (Castle) by searching for title."""
    prov = get_provider("meowtv")
    if not prov or not title:
        return []

    try:
        # 1. Search for title
        print(f"[Addon] Searching MeowTV for: {title}")
        results = await prov.search(title)
        if not results:
            print("[Addon] MeowTV: No search results")
            return []

        # 2. Find best match
        target = None
        for res in results:
            print(f"[Addon] MeowTV check: {res.title} ({res.type})")
            # Check type match
            res_type = "series" if res.type == "series" else "movie"
            if res_type != type_str:
                continue
                
            # Basic title match
            if title.lower() in res.title.lower() or res.title.lower() in title.lower():
                target = res
                print(f"[Addon] MeowTV match found: {res.title} (ID: {res.id})")
                break
        
        if not target:
            return []

        # 3. Fetch details to get episode IDs if series
        movie_id = target.id
        episode_id = movie_id # Default for movies
        
        if type_str == "series":
            details = await prov.fetch_details(movie_id)
            if not details or not details.episodes:
                return []
            
            # Find specific episode
            for ep in details.episodes:
                if ep.season == season and ep.number == episode:
                    episode_id = ep.id
                    break
        
        # 4. Fetch stream
        response = await prov.fetch_stream(movie_id, episode_id)
        if not response:
            return []

        streams = []
        name_prefix = "🏰 MeowTV"
        
        # Add primary URL
        streams.append(build_stremio_stream(response, f"{name_prefix} [Auto]"))
        
        # Add quality variants
        if response.qualities:
            for q in response.qualities:
                if q.quality.lower() == "auto": continue
                streams.append(build_stremio_stream(response, f"{name_prefix} [{q.quality}]", override_url=q.url))
                
        return streams
    except Exception as e:
        print(f"[Addon] MeowTV error: {e}")
        return []

def build_stremio_stream(res: VideoResponse, name: str, override_url: Optional[str] = None) -> dict:
    """Convert VideoResponse to Stremio stream object."""
    url = override_url or res.video_url
    
    # Process headers for players that support them in URL
    # Stremio (ExoPlayer/VLC/mpv) support varies, but behaviorHints can help
    
    stream = {
        "name": name,
        "url": url,
        "description": f"Quality: {name.split('[')[-1].rstrip(']') if '[' in name else 'Auto'}",
        "behaviorHints": {
            "notWeb": True,
        }
    }
    
    # Subtitles
    if res.subtitles:
        stream["subtitles"] = [
            {"id": s.url, "url": s.url, "lang": s.language}
            for s in res.subtitles
        ]
        
    return stream

@app.route("/manifest.json")
def manifest():
    return jsonify(MANIFEST)

@app.route("/stream/<content_type>/<content_id>.json")
def stream_handler(content_type, content_id):
    async def do_work():
        # content_id can be tt... or tt...:1:1
        imdb_id = content_id
        season = 1
        episode = 1
        
        if ":" in content_id:
            parts = content_id.split(":")
            imdb_id = parts[0]
            if len(parts) >= 2: season = int(parts[1])
            if len(parts) >= 3: episode = int(parts[2])

        print(f"[Addon] Request: {content_type} {imdb_id} S{season}E{episode}")
        
        # 1. Fetch metadata
        meta = await fetch_meta(imdb_id, content_type)
        title = meta.get("name")
        print(f"[Addon] Resolved Title: {title}")
        year = None
        if meta.get("releaseInfo"):
            try:
                year = int(meta.get("releaseInfo")[:4])
            except: pass

        # 2. Fetch streams
        name = content_type if content_type == "movie" else "series"
        
        # Initialize config to get proxy setting
        config = get_config()
        if config.proxy_url:
            set_proxy_url(config.proxy_url)

        all_streams = await get_streams_from_meowtv(title, year, name, season, episode)
            
        print(f"[Addon] Found {len(all_streams)} streams")
        return {"streams": all_streams}

    return jsonify(asyncio.run(do_work()))


if __name__ == "__main__":
    import sys
    port = 7008
    if len(sys.argv) > 1:
        port = int(sys.argv[1])
    
    print(f"MeowTV Stremio Addon running on http://127.0.0.1:{port}")
    print(f"Manifest URL: http://127.0.0.1:{port}/manifest.json")
    app.run(host="0.0.0.0", port=port, debug=True)
