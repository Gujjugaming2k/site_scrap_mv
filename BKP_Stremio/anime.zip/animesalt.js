const axios = require('axios');
const cheerio = require('cheerio');
const qs = require('qs');
const m3u8Parser = require('m3u8-parser');

class Animesalt {
    constructor() {
        this.baseUrl = 'https://animesalt.top';
        this.client = axios.create({
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
                'Referer': this.baseUrl,
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
    }

    async search(query) {
        try {
            const formData = {
                action: 'torofilm_infinite_scroll',
                page: '1',
                per_page: '12',
                query_type: 'search',
                'query_args[s]': query
            };

            const res = await this.client.post(`${this.baseUrl}/wp-admin/admin-ajax.php`, qs.stringify(formData));
            if (!res.data || !res.data.success || !res.data.data.content) return [];

            const $ = cheerio.load(res.data.data.content);
            const results = [];

            $('article').each((i, el) => {
                const title = $(el).find('header h2').text().trim();
                const href = $(el).find('a').attr('href');
                if (!title || !href) return;

                results.push({
                    name: title,
                    url: href,
                    identifier: href
                });
            });

            return results;
        } catch (error) {
            console.error('Error in Animesalt search:', error);
            return [];
        }
    }

    async getEpisodes(url) {
        try {
            const res = await this.client.get(url);
            const $ = cheerio.load(res.data);

            const tvType = url.includes('movies') ? 'movie' : 'series';
            if (tvType === 'movie') {
                return [{ number: 1, url: url, name: 'Movie' }];
            }

            const seasonButtons = $('div.season-buttons a');
            const episodes = [];

            for (const btn of seasonButtons.toArray()) {
                const postId = $(btn).attr('data-post');
                const dataSeason = $(btn).attr('data-season');

                const seasonRes = await this.client.post(`${this.baseUrl}/wp-admin/admin-ajax.php`, qs.stringify({
                    action: 'action_select_season',
                    season: dataSeason,
                    post: postId
                }));

                const $epPage = cheerio.load(seasonRes.data);
                $epPage('li article').each((index, ep) => {
                    const href = $(ep).find('a').attr('href');
                    const title = $(ep).find('h2.entry-title').text().trim();
                    const seasonNum = parseInt(dataSeason);
                    const epNum = index + 1;

                    episodes.push({
                        number: epNum,
                        season: seasonNum,
                        url: href,
                        name: title
                    });
                });
            }

            return episodes;
        } catch (error) {
            console.error('Error in Animesalt getEpisodes:', error);
            return [];
        }
    }

    async getStreams(url) {
        try {
            const res = await this.client.get(url);
            const $ = cheerio.load(res.data);
            const streams = [];

            for (const el of $('#options-0 iframe').toArray()) {
                const src = $(el).attr('data-src') || $(el).attr('src');
                if (!src) continue;

                if (src.includes('play.zephyrflick.top')) {
                    try {
                        const videoId = src.split('/').pop().split('?')[0];
                        const apiUrl = `https://play.zephyrflick.top/player/index.php?data=${videoId}&do=getVideo`;

                        const apiRes = await this.client.post(apiUrl, null, {
                            headers: {
                                'X-Requested-With': 'XMLHttpRequest',
                                'Referer': src
                            }
                        });

                        if (apiRes.data && apiRes.data.videoSource) {
                            const masterUrl = apiRes.data.videoSource;

                            // Always add the master URL first as it contains all audio tracks and resolutions
                            streams.push({
                                url: masterUrl,
                                resolution: 'Multi',
                                server: 'ZephyrFlick (Master)',
                                isIframe: false
                            });

                            // We can still add individual resolutions, but they may lack audio in some players
                            // if the Manifest specifies separate audio tracks. For now, let's just 
                            // keep the master for best compatibility with audio.
                            /*
                            try {
                                const m3u8Res = await this.client.get(masterUrl);
                                const parser = new m3u8Parser.Parser();
                                parser.push(m3u8Res.data);
                                parser.end();

                                if (parser.manifest.playlists && parser.manifest.playlists.length > 0) {
                                    for (const playlist of parser.manifest.playlists) {
                                        const resolution = playlist.attributes.RESOLUTION ? playlist.attributes.RESOLUTION.height : 'Unknown';
                                        streams.push({
                                            url: new URL(playlist.uri, masterUrl).href,
                                            resolution: resolution,
                                            server: 'ZephyrFlick',
                                            isIframe: false
                                        });
                                    }
                                } else {
                                    streams.push({
                                        url: masterUrl,
                                        resolution: 'Auto',
                                        server: 'ZephyrFlick',
                                        isIframe: false
                                    });
                                }
                            } catch (e) {
                                // Ignore parsing errors for individual resolutions
                            }
                            */
                        }
                    } catch (err) {
                        console.error('Error resolving ZephyrFlick m3u8:', err.message);
                        streams.push({ url: src, resolution: 'Unknown', server: 'Iframe', isIframe: true });
                    }
                } else {
                    streams.push({
                        url: src,
                        resolution: 'Unknown',
                        server: 'Iframe',
                        isIframe: true
                    });
                }
            }

            return streams;
        } catch (error) {
            console.error('Error in Animesalt getStreams:', error);
            return [];
        }
    }
}

module.exports = Animesalt;

/*
// Quick Test
(async () => {
    ...
})();
*/
