const axios = require('axios');
const cheerio = require('cheerio');
const m3u8Parser = require('m3u8-parser');

class AnimeKai {
    constructor() {
        this.baseUrl = 'https://anikai.to';
        this.decApi = 'https://enc-dec.app/api';
        this.client = axios.create({
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36'
            }
        });
    }

    async generateToken(text) {
        try {
            const res = await this.client.get(`${this.decApi}/enc-kai`, { params: { text } });
            return res.data.result;
        } catch (error) {
            console.error('Error generating token:', error);
            return null;
        }
    }

    async decodeIframeData(text) {
        try {
            const res = await this.client.get(`${this.decApi}/dec-kai`, { params: { text } });
            return res.data.result;
        } catch (error) {
            console.error('Error decoding iframe data:', error);
            return null;
        }
    }

    async decodeMega(text) {
        try {
            const res = await this.client.post(`${this.decApi}/dec-mega`, {
                text: text,
                agent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36'
            });
            return res.data.result;
        } catch (error) {
            console.error('Error decoding mega:', error);
            return null;
        }
    }

    async search(query) {
        try {
            const searchUrl = `${this.baseUrl}/browser`;
            const res = await this.client.get(searchUrl, { params: { keyword: query } });
            const $ = cheerio.load(res.data);
            const results = [];

            $('.aitem').each((i, el) => {
                const titleEl = $(el).find('a.title');
                const title = titleEl.attr('title');
                const href = $(el).find('a.poster').attr('href');
                if (!href) return;
                const identifier = href.split('/').pop();
                const languages = ['sub'];
                if ($(el).find('span.dub').length > 0) {
                    languages.push('dub');
                }

                results.push({
                    identifier,
                    name: title,
                    languages
                });
            });

            return results;
        } catch (error) {
            console.error('Error in search:', error);
            return [];
        }
    }

    async getEpisodes(identifier) {
        try {
            const watchUrl = `${this.baseUrl}/watch/${identifier}`;
            const watchRes = await this.client.get(watchUrl);
            const $watch = cheerio.load(watchRes.data);
            const aniId = $watch('.rate-box').attr('data-id');

            const token = await this.generateToken(aniId);
            const res = await this.client.get(`${this.baseUrl}/ajax/episodes/list`, {
                params: { ani_id: aniId, _: token }
            });

            const $ep = cheerio.load(res.data.result);
            const episodes = [];

            $ep('a[num]').each((i, el) => {
                const num = $ep(el).attr('num');
                const langs = $ep(el).attr('langs'); // 1 = sub, 3 = sub & dub
                episodes.push({
                    number: parseInt(num),
                    langs: langs === '3' ? ['sub', 'dub'] : ['sub'],
                    token: $ep(el).attr('token')
                });
            });

            return episodes;
        } catch (error) {
            console.error('Error in getEpisodes:', error);
            return [];
        }
    }

    async getStreams(identifier, episodeNumber, lang = 'sub') {
        try {
            const episodes = await this.getEpisodes(identifier);
            const episode = episodes.find(e => e.number === episodeNumber);
            if (!episode) return [];

            const token = await this.generateToken(episode.token);
            const linksRes = await this.client.get(`${this.baseUrl}/ajax/links/list`, {
                params: { token: episode.token, _: token }
            });

            const $links = cheerio.load(linksRes.data.result);
            const serverGroup = $links(`.server-items.lang-group[data-id="${lang === 'dub' ? 'dub' : 'sub'}"]`);
            if (serverGroup.length === 0) return [];

            const streams = [];

            for (const serverEl of serverGroup.find('.server').toArray()) {
                const serverId = $links(serverEl).attr('data-lid');
                const serverToken = await this.generateToken(serverId);

                const viewRes = await this.client.get(`${this.baseUrl}/ajax/links/view`, {
                    params: { id: serverId, _: serverToken }
                });

                const decodedIframe = await this.decodeIframeData(viewRes.data.result);
                if (!decodedIframe || !decodedIframe.url) continue;

                const megaUrl = decodedIframe.url.replace('/e/', '/media/');
                const megaRes = await this.client.get(megaUrl);
                const decodedMega = await this.decodeMega(megaRes.data.result);

                if (decodedMega && decodedMega.sources && decodedMega.sources[0]) {
                    const masterUrl = decodedMega.sources[0].file;
                    const subtitles = (decodedMega.tracks || [])
                        .filter(t => t.kind === 'captions')
                        .map(t => ({
                            url: t.file,
                            label: t.label
                        }));

                    // Fetch master m3u8 to get resolutions
                    try {
                        const m3u8Res = await this.client.get(masterUrl);
                        const parser = new m3u8Parser.Parser();
                        parser.push(m3u8Res.data);
                        parser.end();

                        if (parser.manifest.playlists && parser.manifest.playlists.length > 0) {
                            // Add Master manifest for better audio/compatibility
                            streams.push({
                                url: masterUrl,
                                resolution: 'Multi',
                                subtitles: subtitles,
                                server: $links(serverEl).text().trim() + ' (Master)'
                            });

                            for (const playlist of parser.manifest.playlists) {
                                const resolution = playlist.attributes.RESOLUTION ? playlist.attributes.RESOLUTION.height : 'unknown';
                                if (resolution === 1080 || resolution === 720) {
                                    streams.push({
                                        url: new URL(playlist.uri, masterUrl).href,
                                        resolution: resolution,
                                        subtitles: subtitles,
                                        server: $links(serverEl).text().trim()
                                    });
                                }
                            }
                        } else {
                            streams.push({
                                url: masterUrl,
                                resolution: '1080',
                                subtitles: subtitles,
                                server: $links(serverEl).text().trim()
                            });
                        }
                    } catch (m3u8Error) {
                        console.error('Error parsing m3u8:', m3u8Error);
                        streams.push({
                            url: masterUrl,
                            resolution: '1080',
                            subtitles: subtitles,
                            server: $links(serverEl).text().trim()
                        });
                    }
                }
            }

            return streams;
        } catch (error) {
            console.error('Error in getStreams:', error);
            return [];
        }
    }
}

module.exports = AnimeKai;

/*
// Quick Test
(async () => {
    const provider = new AnimeKai();
...
})();
*/
