const { addonBuilder, serveHTTP } = require('stremio-addon-sdk');
const AnimeKai = require('./animekai');
const Animesalt = require('./animesalt');
const axios = require('axios');

const animeKai = new AnimeKai();
const animeSalt = new Animesalt();

const manifest = {
    id: 'community.multianime',
    version: '1.0.1',
    name: 'AnimeKai & Animesalt',
    description: 'Anime from AnimeKai.to and Animesalt.top',
    resources: ['stream'],
    types: ['movie', 'series', 'anime'],
    idPrefixes: ['tt', 'kitsu:'],
    catalogs: []
};

const builder = new addonBuilder(manifest);

const TMDB_API_KEY = 'ea7b1fc3807d8a53d4227a80a15aeed1';

async function getKitsuMeta(kitsuId) {
    try {
        const id = kitsuId.replace('kitsu:', '');
        const res = await axios.get(`https://kitsu.io/api/edge/anime/${id}`);
        return res.data.data.attributes;
    } catch (error) {
        console.error('Error fetching Kitsu meta:', error);
        return null;
    }
}

async function getImdbMeta(imdbId) {
    try {
        const res = await axios.get(`https://api.themoviedb.org/3/find/${imdbId}`, {
            params: {
                api_key: TMDB_API_KEY,
                external_source: 'imdb_id'
            }
        });
        const result = res.data.movie_results[0] || res.data.tv_results[0];
        return result ? (result.title || result.name) : null;
    } catch (error) {
        console.error('Error fetching IMDB meta from TMDB:', error);
        return null;
    }
}

builder.defineStreamHandler(async (args) => {
    console.log('Stream request:', args);
    const { id } = args;
    let title = '';
    let episode = 1;

    if (id.startsWith('kitsu:')) {
        const parts = id.split(':');
        const kitsuId = parts[1];
        episode = parts[2] ? parseInt(parts[2]) : 1;
        const meta = await getKitsuMeta(kitsuId);
        if (meta) {
            title = meta.en || meta.en_jp || meta.canonicalTitle;
        }
    } else if (id.startsWith('tt')) {
        const parts = id.split(':');
        const imdbId = parts[0];
        episode = parts[1] ? parseInt(parts[1]) : (parts[2] ? parseInt(parts[2]) : 1);
        title = await getImdbMeta(imdbId);
    }

    if (!title) return { streams: [] };

    console.log(`Searching for: ${title}, Episode: ${episode}`);

    const [kaiResults, saltResults] = await Promise.all([
        animeKai.search(title).catch(() => []),
        animeSalt.search(title).catch(() => [])
    ]);

    const streams = [];

    // Process AnimeKai
    if (kaiResults.length > 0) {
        const anime = kaiResults[0]; // Best match
        const [sub, dub] = await Promise.all([
            animeKai.getStreams(anime.identifier, episode, 'sub').catch(() => []),
            anime.languages.includes('dub') ? animeKai.getStreams(anime.identifier, episode, 'dub').catch(() => []) : []
        ]);

        [...sub, ...dub].forEach(s => {
            streams.push({
                url: s.url,
                title: `AnimeKai - ${s.resolution}p - ${s.server} [${s.url.includes('dub') || dub.includes(s) ? 'DUB' : 'SUB'}]`,
                behaviorHints: {
                    notInteractivity: true,
                    proxyHeaders: { "Referer": "https://anikai.to/" }
                }
            });
        });
    }

    // Process Animesalt
    if (saltResults.length > 0) {
        const anime = saltResults[0];
        const saltEpisodes = await animeSalt.getEpisodes(anime.url).catch(() => []);
        const ep = saltEpisodes.find(e => e.number === episode);
        if (ep) {
            const saltStreams = await animeSalt.getStreams(ep.url).catch(() => []);
            saltStreams.forEach(s => {
                streams.push({
                    url: s.url,
                    title: `Animesalt - ${s.resolution}${s.resolution !== 'Unknown' ? 'p' : ''} - ${s.server} [HI/EN]`,
                    behaviorHints: {
                        notInteractivity: true,
                        proxyHeaders: { "Referer": "https://animesalt.top/" }
                    }
                });
            });
        }
    }

    return { streams };
});

serveHTTP(builder.getInterface(), { port: 7004 });
console.log('Addon active at http://localhost:7000/manifest.json');
