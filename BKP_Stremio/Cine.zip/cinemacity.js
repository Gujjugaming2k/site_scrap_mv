const axios = require('axios');
const cheerio = require('cheerio');
const stringSimilarity = require('string-similarity');

const BASE_URL = 'https://cinemacity.cc';
const CINEMETA_URL = 'https://v3-cinemeta.strem.io/meta';

// Headers from Kotlin source (Base64 decoded)
const HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Cookie': 'dle_user_id=32729; dle_password=894171c6a8dab18ee594d5c652009a35;'
};

const client = axios.create({
    headers: HEADERS
});

async function resolveImdb(imdbId, type) {
    try {
        const url = `${CINEMETA_URL}/${type}/${imdbId}.json`;
        const { data } = await axios.get(url);
        if (data && data.meta) {
            return {
                title: data.meta.name,
                year: data.meta.year,
                type: type
            };
        }
    } catch (error) {
        console.error('Error resolving IMDb ID:', error.message);
    }
    return null;
}

async function search(query) {
    try {
        const searchUrl = `${BASE_URL}/index.php?do=search&subaction=search&search_start=1&full_search=0&story=${encodeURIComponent(query)}`;
        const { data } = await client.get(searchUrl);
        const $ = cheerio.load(data);
        const results = [];

        $('div.dar-short_item').each((i, el) => {
            // Title extraction: Kotlin uses `it.children().firstOrNull { it.tagName() == "a" }`
            // JS: Find direct child 'a'
            const titleElement = $(el).children('a').first();
            let title = titleElement.text().trim();
            // Clean title like Kotlin: substringBefore("(")
            if (title.includes('(')) {
                title = title.split('(')[0].trim();
            }

            const href = titleElement.attr('href');

            if (href && title) {
                results.push({
                    title: title,
                    url: href
                });
            }
        });

        return results;
    } catch (error) {
        console.error('Search failed:', error.message);
        return [];
    }
}

function decodePlayerJs(html) {
    const $ = cheerio.load(html);
    let playerConfig = null;
    $('script').each((i, el) => {
        if (playerConfig) return; // Found already
        const content = $(el).html();
        if (content && content.includes('atob("')) {
            try {
                const encoded = content.split('atob("')[1].split('")')[0];
                const decoded = Buffer.from(encoded, 'base64').toString('utf-8');

                if (decoded.includes('new Playerjs(')) {
                    // JS literal, not JSON. Use Regex.
                    // Look for file: '...' or file: "..."
                    const fileMatch = /file\s*:\s*(['"])((?:[^\\]|\\.)*?)\1/.exec(decoded);
                    if (fileMatch) {
                        playerConfig = { file: fileMatch[2] };
                    }
                }
            } catch (e) {
                // Ignore errors, try next script
            }
        }
    });

    if (!playerConfig) {
        throw new Error('PlayerJS script not found');
    }

    return playerConfig;
}

async function getStream(url, season, episode) {
    let data = '';
    try {
        const response = await client.get(url);
        data = response.data;

        let playerConfig = null;
        try {
            playerConfig = decodePlayerJs(data);
        } catch (e) {
            console.error('PlayerJS extraction failed:', e.message);
            return null;
        }

        if (!playerConfig || !playerConfig.file) {
            console.error('No file found in player config');
            return null;
        }

        let fileData = playerConfig.file;
        // Parse 'file' if it's a string resembling JSON/Array
        if (typeof fileData === 'string') {
            if (fileData.startsWith('[') || fileData.startsWith('{')) {
                try {
                    fileData = JSON.parse(fileData);
                } catch (e) {
                    // It might be a simple URL string? Kotlin handles this.
                    // If not JSON, wrapped in object
                    if (fileData.trim().startsWith('http')) {
                        fileData = [{ file: fileData }];
                    }
                }
            } else {
                // Simple string URL?
                fileData = [{ file: fileData }];
            }
        }

        // Normalize to array
        if (!Array.isArray(fileData)) {
            fileData = [fileData];
        }

        if (season && episode) {
            // TV Series Logic
            // Kotlin: Loop fileArray -> match "Season X" in title -> Loop folder -> match "Episode Y" in title
            const seasonRegex = new RegExp(`Season\\s*${season}\\b`, 'i');
            const episodeRegex = new RegExp(`Episode\\s*${episode}\\b`, 'i');

            for (const sItem of fileData) {
                if (seasonRegex.test(sItem.title || '')) {
                    if (sItem.folder) {
                        for (const eItem of sItem.folder) {
                            if (episodeRegex.test(eItem.title || '')) {
                                return {
                                    streamUrl: eItem.file,
                                    subtitles: eItem.subtitle
                                };
                            }
                        }
                    }
                }
            }
            console.log(`Stream not found for S${season}E${episode}`);
        } else {
            // Movie Logic: First item plain file
            const movieItem = fileData[0];
            if (movieItem && movieItem.file) {
                return {
                    streamUrl: movieItem.file,
                    subtitles: movieItem.subtitle
                };
            }
        }

    } catch (error) {
        console.error('Error getting stream:', error.message);
    }
    return null;
}

// Helper to parse subtitles similarly to Kotlin if needed?
// Kotlin parseSubtitles parses `[Lang]Url,[Lang2]Url2` format if raw string.
// Let's leave raw for now unless formatted required.

// Helper to find best match
function findBestMatch(results, title) {
    let bestMatch = null;
    let bestScore = 0;

    results.forEach(res => {
        const sim = stringSimilarity.compareTwoStrings(res.title.toLowerCase(), title.toLowerCase());
        if (sim > bestScore) {
            bestScore = sim;
            bestMatch = res;
        }
    });

    if (!bestMatch || bestScore < 0.4) {
        return null;
    }
    return bestMatch;
}

async function extractStreams(imdbId, type, season, episode) {
    try {
        console.log(`Extracting streams for ${type} ${imdbId}...`);
        const meta = await resolveImdb(imdbId, type);
        if (!meta) {
            console.error('Could not resolve IMDb ID');
            return [];
        }

        console.log(`Resolved: ${meta.title} (${meta.year})`);
        const results = await search(meta.title);

        if (results.length === 0) {
            console.log('No results found on Cinemacity');
            return [];
        }

        const match = findBestMatch(results, meta.title);
        if (!match) {
            console.log('No good match found');
            return [];
        }

        console.log(`Matched: ${match.title}`);
        const streamData = await getStream(match.url, season, episode);

        if (streamData && streamData.streamUrl) {
            let title = `${meta.title} (${meta.year})`;
            if (season && episode) title += ` S${season}E${episode}`;
            title += ` [Cinemacity]`;

            return [{
                title: title,
                url: streamData.streamUrl,
                subtitles: [] // TODO: Parse subtitles if needed from streamData.subtitles
            }];
        }
    } catch (e) {
        console.error('Extract error:', e.message);
    }
    return [];
}

async function main() {
    const args = process.argv.slice(2);
    if (args.length < 1) {
        console.log('Usage: node cinemacity.js <imdbId> [season] [episode]');
        process.exit(1);
    }

    const imdbId = args[0];
    const season = args[1]; // optional
    const episode = args[2]; // optional
    const type = (season && episode) ? 'series' : 'movie';

    const streams = await extractStreams(imdbId, type, season, episode);
    console.log(JSON.stringify(streams, null, 2));
}

if (require.main === module) {
    main();
}

module.exports = {
    resolveImdb,
    search,
    getStream,
    extractStreams
};
