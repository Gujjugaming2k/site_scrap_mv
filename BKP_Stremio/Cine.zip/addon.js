const { addonBuilder, serveHTTP } = require('stremio-addon-sdk');
const cinemacity = require('./cinemacity');

const manifest = {
    id: 'org.cinemacity.addon',
    version: '1.0.0',
    name: 'Cinemacity',
    description: 'Stremio addon for Cinemacity',
    types: ['movie', 'series'],
    catalogs: [],
    resources: ['stream'],
    idPrefixes: ['tt']
};

const builder = new addonBuilder(manifest);

builder.defineStreamHandler(async ({ type, id }) => {
    let imdbId = id;
    let season = null;
    let episode = null;

    if (type === 'series') {
        const parts = id.split(':');
        imdbId = parts[0];
        season = parts[1];
        episode = parts[2];
    }

    console.log(`Request: ${type} ${imdbId} S${season}E${episode}`);
    const streams = await cinemacity.extractStreams(imdbId, type, season, episode);

    return { streams: streams };
});

serveHTTP(builder.getInterface(), { port: 7009 });
console.log('Addon running on http://127.0.0.1:7009');
