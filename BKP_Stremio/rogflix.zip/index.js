require('dotenv').config();
const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
const port = process.env.PORT || 7003;

app.use(cors());

const TMDB_API_KEY = process.env.TMDB_API_KEY;
const ROGFLIX_BASE_URL = 'https://api.madplay.site/api/rogflix';

// Helper to map IMDb ID to TMDB ID
async function imdbToTmdb(id, type) {
    try {
        const url = `https://api.themoviedb.org/3/find/${id}?api_key=${TMDB_API_KEY}&external_source=imdb_id`;
        const response = await axios.get(url);

        if (type === 'movie' && response.data.movie_results.length > 0) {
            return response.data.movie_results[0].id;
        } else if (type === 'series' && response.data.tv_results.length > 0) {
            return response.data.tv_results[0].id;
        }
        return null;
    } catch (error) {
        console.error('Error mapping IMDb to TMDB:', error.message);
        return null;
    }
}

// Helper to fetch streams from Rogflix
async function fetchRogflixStreams(tmdbId, type, season, episode) {
    try {
        let url = `${ROGFLIX_BASE_URL}?id=${tmdbId}&type=${type}`;
        if (type === 'series') {
            url += `&season=${season}&episode=${episode}`;
        }

        const response = await axios.get(url);
        return response.data;
    } catch (error) {
        console.error('Error fetching from Rogflix:', error.message);
        return [];
    }
}

// Manifest
app.get('/manifest.json', (req, res) => {
    res.json({
        id: 'org.rogflix.stremio',
        version: '1.0.0',
        name: 'Rogflix Addon',
        description: 'Fetch streams from Rogflix',
        resources: ['stream'],
        types: ['movie', 'series'],
        idPrefixes: ['tt'],
        catalogs: []
    });
});

// Stream handler
app.get('/stremio/stream/:type/:id.json', async (req, res) => {
    try {
        const { type, id } = req.params;
        console.log(`Received stream request for ${type} with ID: ${id}`);

        let imdbId = id;
        let season, episode;

        if (type === 'series') {
            const parts = id.split(':');
            imdbId = parts[0];
            season = parts[1];
            episode = parts[2];
        }

        const tmdbId = await imdbToTmdb(imdbId, type);
        if (!tmdbId) {
            console.log(`Could not find TMDB ID for ${imdbId}`);
            return res.json({ streams: [] });
        }

        console.log(`Mapped ${imdbId} to TMDB ${tmdbId}`);

        const rogflixData = await fetchRogflixStreams(tmdbId, type, season, episode);
        console.log(`Rogflix API returned ${Array.isArray(rogflixData) ? rogflixData.length : 'non-array'} items`);

        if (!Array.isArray(rogflixData)) {
            console.log('Rogflix data is not an array:', rogflixData);
            return res.json({ streams: [] });
        }

        const streams = rogflixData.map(item => ({
            name: `Rogflix\n${item.title || 'Unknown'}`,
            title: `${item.title || 'Stream'} (${item.translator == '1' ? 'ENG' : (item.translator == '5' ? 'HIN' : 'Other')})`,
            url: item.file
        }));

        res.json({ streams });
    } catch (error) {
        console.error('Unhandled error in stream handler:', error);
        res.status(500).json({ streams: [], error: error.message });
    }
});

app.listen(port, () => {
    console.log(`Rogflix addon running at http://localhost:${port}`);
    console.log(`Manifest URL: http://localhost:${port}/manifest.json`);
});
